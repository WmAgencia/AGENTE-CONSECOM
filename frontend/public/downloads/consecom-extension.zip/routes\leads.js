import { getLogger } from '../utils/logger.js';
import { getSupabaseProspeccaoConfig } from '../config/env.js';
import { sendText } from '../services/evolution.service.js';
import { getUserConnection, getWorkspaceAndUser, } from '../services/evolution.connections.js';
function sup() {
    const cfg = getSupabaseProspeccaoConfig();
    return cfg.url && cfg.serviceRoleKey ? cfg : null;
}
function supHeaders(key, json = false) {
    return json
        ? { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }
        : { apikey: key, Authorization: `Bearer ${key}` };
}
export function registerLeadsRoutes(app) {
    const log = getLogger();
    app.post('/api/leads/:id/reply', async (req, reply) => {
        const { workspaceId, userId } = getWorkspaceAndUser(req);
        const identifier = workspaceId ?? userId;
        if (!identifier) {
            return reply.status(401).send({ error: 'unauthorized' });
        }
        const params = req.params;
        const leadId = params.id;
        const body = req.body;
        const text = typeof body?.text === 'string' ? body.text.trim() : '';
        if (!leadId)
            return reply.status(400).send({ error: 'lead_id_required' });
        if (!text)
            return reply.status(400).send({ error: 'text_required' });
        const s = sup();
        if (!s) {
            return reply.status(503).send({ error: 'server_misconfigured' });
        }
        try {
            // 1) Load the lead (phone) server-side via service role.
            const leadRes = await fetch(`${s.url}/rest/v1/leads?select=id,name,phone&id=eq.${encodeURIComponent(leadId)}&limit=1`, { headers: supHeaders(s.serviceRoleKey) });
            if (!leadRes.ok)
                return reply.status(502).send({ error: 'lead_lookup_failed' });
            const leads = (await leadRes.json());
            const lead = leads[0];
            if (!lead)
                return reply.status(404).send({ error: 'lead_not_found' });
            if (!lead.phone)
                return reply.status(400).send({ error: 'lead_no_phone' });
            // 2) Resolve the caller's connected WhatsApp instance.
            const conn = await getUserConnection(identifier);
            if (!conn || conn.status !== 'connected') {
                return reply.status(400).send({
                    error: 'no_connection',
                    message: 'WhatsApp não está conectado para esta conta.',
                });
            }
            // 3) Send the message through the user's instance.
            const result = await sendText({ to: lead.phone, text, instance: conn.instance_name });
            if (!result.ok) {
                log.warn({ leadId, status: result.status, err: result.error }, 'leads: manual reply send failed');
                return reply.status(502).send({
                    error: 'send_failed',
                    message: result.error ?? 'Falha ao enviar a mensagem.',
                });
            }
            // 4) Record the turn as a human reply so the chat UI can tag it.
            await fetch(`${s.url}/rest/v1/consecom_conversations`, {
                method: 'POST',
                headers: supHeaders(s.serviceRoleKey, true),
                body: JSON.stringify({
                    lead_id: leadId,
                    role: 'assistant',
                    content: text,
                    agent_model: 'HUMAN_REPLY',
                }),
            });
            // 5) Touch last_message_sent (best-effort).
            await fetch(`${s.url}/rest/v1/leads?id=eq.${encodeURIComponent(leadId)}`, {
                method: 'PATCH',
                headers: supHeaders(s.serviceRoleKey, true),
                body: JSON.stringify({ last_message_sent: new Date().toISOString() }),
            });
            log.info({ leadId, mock: result.mock === true }, 'leads: manual reply sent');
            return reply.send({ ok: true, mock: result.mock === true });
        }
        catch (err) {
            const em = err instanceof Error ? err.message : 'unknown';
            log.error({ errMessage: em, leadId }, 'leads: reply handler failed');
            return reply.status(502).send({ error: 'reply_failed', message: 'Erro interno ao enviar.' });
        }
    });
    log.info('leads: routes registered');
}
//# sourceMappingURL=leads.js.map