/**
 * Tool framework: registry, base interface, and permission model.
 *
 * Tools are pluggable units the agent loop can invoke. Each tool declares:
 *  - a stable name (mapped to OpenAI-style function schema sent to the model)
 *  - a permission category (for the security gate)
 *  - a JSON-Schema-ish parameter descriptor for the model
 *  - an executor function
 *
 * The registry is constructed at boot and frozen for the process lifetime.
 * New tools can be added by pushing to `defaultRegistry` without touching
 * the agent loop itself.
 */
/**
 * Registry enforces uniqueness by tool.name and exposes the JSON schema
 * array in the format NVIDIA NIM / OpenAI-compatible chat.completions
 * expect for the `tools` field.
 */
export class ToolRegistry {
    tools = new Map();
    enabled;
    allowedPerms;
    constructor(opts) {
        this.enabled = opts.enabled;
        this.allowedPerms = new Set(opts.allowedPerms);
    }
    register(tool) {
        if (this.tools.has(tool.definition.name)) {
            throw new Error(`Tool already registered: ${tool.definition.name}`);
        }
        this.tools.set(tool.definition.name, tool);
    }
    get(name) {
        return this.tools.get(name);
    }
    list() {
        return Array.from(this.tools.values());
    }
    isEnabled() {
        return this.enabled;
    }
    isAllowed(perm) {
        return this.allowedPerms.has(perm);
    }
    /**
     * Returns the `tools` array to pass to chat.completions when tool-calling
     * is active. Returns `[]` when tools are disabled globally, so the model
     * never sees tool affordances it cannot use.
     */
    toOpenAITools() {
        if (!this.enabled)
            return [];
        return this.list().map((t) => ({
            type: 'function',
            function: {
                name: t.definition.name,
                description: t.definition.description,
                parameters: t.definition.parameters,
            },
        }));
    }
    /**
     * Runs a tool by name after checking enabled + permission gate.
     * Never throws: errors are returned as ToolResult with ok=false.
     */
    async run(name, args, ctx) {
        if (!this.enabled) {
            return {
                ok: false,
                output: 'Tools are disabled on this server.',
                error: 'tool_disabled',
            };
        }
        const tool = this.get(name);
        if (!tool) {
            return {
                ok: false,
                output: `Unknown tool: ${name}`,
                error: 'unknown',
            };
        }
        if (!this.isAllowed(tool.permission)) {
            return {
                ok: false,
                output: `Permission denied for ${tool.permission} (${name}).`,
                error: 'permission_denied',
            };
        }
        try {
            return await tool.execute(args, ctx);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : 'unknown error';
            return {
                ok: false,
                output: `Tool ${name} crashed: ${message}`,
                error: 'unknown',
            };
        }
    }
}
/** Process-wide default registry; built once in src/tools/index.ts */
let defaultRegistry = null;
export function setDefaultRegistry(reg) {
    if (defaultRegistry) {
        throw new Error('Default registry already initialized');
    }
    defaultRegistry = reg;
}
export function getDefaultRegistry() {
    if (!defaultRegistry) {
        throw new Error('Default registry not initialized');
    }
    return defaultRegistry;
}
//# sourceMappingURL=registry.js.map