export function registerHealthRoutes(app) {
    const startedAt = Date.now();
    app.get('/health', { config: { rateLimit: false } }, async (_req, _reply) => {
        const body = {
            status: 'ok',
            uptime: Math.floor((Date.now() - startedAt) / 1000),
        };
        return body;
    });
}
//# sourceMappingURL=health.js.map