/**
 * Zod schemas for Evolution API webhook payloads (MVP subset).
 *
 * Reference: Evolution API v2 emits POST payloads with shape:
 *   { event, instance, data: { key, message, pushName, ... }, ... }
 *
 * Only fields used by this MVP are typed strictly. Unknown extra fields
 * (sent by Evolution) are ignored via .passthrough() so we don't break on
 * forward-compatible additions.
 *
 * Security note: contents of `message` are sensitive (WhatsApp text) and
 * MUST NOT be logged. Only structural metadata is logged elsewhere.
 */
import { z } from 'zod';
export const evolutionMessageKeySchema = z.object({
    id: z.string().optional(),
    remoteJid: z.string().optional(),
    fromMe: z.boolean().optional(),
    participant: z.string().optional(),
}).passthrough();
export const evolutionMessageBodySchema = z.object({
    conversation: z.string().optional(),
    extendedTextMessage: z
        .object({ text: z.string().optional() })
        .passthrough()
        .optional(),
}).passthrough();
export const evolutionDataSchema = z.object({
    key: evolutionMessageKeySchema.optional(),
    message: evolutionMessageBodySchema.optional(),
    pushName: z.string().optional(),
    messageType: z.string().optional(),
}).passthrough();
export const evolutionWebhookPayloadSchema = z.object({
    event: z.string(),
    instance: z.string().optional(),
    data: evolutionDataSchema.optional(),
    destination: z.string().optional(),
    date_time: z.string().optional(),
    sender: z.string().optional(),
}).passthrough();
export function extractMessage(payload) {
    const data = payload.data;
    if (!data)
        return null;
    const key = data.key ?? {};
    const message = data.message ?? {};
    const text = message.conversation ??
        message.extendedTextMessage?.text ??
        '';
    const from = key.remoteJid ?? '';
    const fromMe = key.fromMe === true;
    const messageKeyId = key.id;
    if (!text || !from)
        return null;
    if (fromMe)
        return null; // anti-loop: never process own outgoing messages
    const isGroup = from.endsWith('@g.us');
    const instance = payload.instance;
    // Evolution v2 puts mentioned JIDs at message.extendedTextMessage.mentionedJid
    // (string array). We don't strictly type this since it's optional and
    // missing in many payloads; passthrough already keeps the raw field.
    const mentionedJids = [];
    const rawMentions = message
        .extendedTextMessage?.mentionedJid;
    if (Array.isArray(rawMentions)) {
        for (const jid of rawMentions) {
            if (typeof jid === 'string')
                mentionedJids.push(jid);
        }
    }
    return {
        text,
        from,
        fromMe,
        messageKeyId,
        pushName: data.pushName,
        isGroup,
        instance,
        mentionedJids,
    };
}
//# sourceMappingURL=webhook.js.map