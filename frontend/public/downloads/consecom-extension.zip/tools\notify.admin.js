import { getEnv, hasEvolutionConfig } from '../config/env.js';
import { isEvolutionMockMode, sendGroupText } from '../services/evolution.service.js';
import { resolveNotificationGroupJid } from '../services/evolution.connections.js';
export function createNotifyAdminGroupTool() {
    return {
        definition: {
            name: 'notify_admin_group',
            description: 'Sends a WhatsApp message to the internal admin group to report that a ' +
                'client is waiting for a reply from Samira. Pass the client name/number ' +
                'and the reason in the message. Use only when you could not resolve the ' +
                'request and need the team to handle it.',
            parameters: {
                type: 'object',
                properties: {
                    message: {
                        type: 'string',
                        description: 'The notification text for the admin group, e.g. "Cliente Maria (55 11 99999-9999) aguardando resposta sobre horário de 07/08 15h."',
                    },
                },
                required: ['message'],
            },
        },
        permission: 'WHATSAPP',
        async execute(args, ctx) {
            const message = typeof args.message === 'string' ? args.message.trim() : '';
            if (!message) {
                return { ok: false, output: 'message is required.', error: 'invalid_args' };
            }
            const groupJid = (ctx.instance ? await resolveNotificationGroupJid(ctx.instance) : null) ??
                getEnv().AGENT_ADMIN_GROUP_JID;
            if (!groupJid) {
                return {
                    ok: false,
                    output: 'No notification group is configured on the server.',
                    error: 'tool_disabled',
                };
            }
            if (!hasEvolutionConfig() || isEvolutionMockMode()) {
                return {
                    ok: false,
                    output: 'Evolution API is not configured for this agent service.',
                    error: 'tool_disabled',
                };
            }
            const result = await sendGroupText(groupJid, message, ctx.instance);
            if (!result.ok) {
                return {
                    ok: false,
                    output: `Falha ao notificar o grupo: ${result.error ?? 'unknown error'}`,
                    error: 'io_error',
                };
            }
            return { ok: true, output: 'Grupo de administração notificado com sucesso.' };
        },
    };
}
//# sourceMappingURL=notify.admin.js.map