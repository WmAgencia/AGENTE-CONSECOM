import { isEvolutionMockMode, checkEvolutionHealth, } from '../services/evolution.service.js';
export function registerEvolutionRoutes(app) {
    app.get('/api/evolution/health', { config: { rateLimit: false } }, async (_req, reply) => {
        const result = await checkEvolutionHealth();
        const statusCode = result.ok ? 200 : 502;
        return reply.status(statusCode).send(result);
    });
    // mark mock mode is reachable for diagnostics; safe export.
    void isEvolutionMockMode;
}
//# sourceMappingURL=evolution.js.map