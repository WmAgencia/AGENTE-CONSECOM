const n={wepsy:{title:"Bem-vindo ao Vyntra",tagline:"Cada conexão começa com um nome. Vamos encontrar os seus.",subtitle:"Você está prospectando no",siteName:"Wepsy",emoji:"💜"},webmotors:{title:"Olá, prospector",tagline:"A próxima loja que fecha é só um clique de distância.",subtitle:"Você está prospectando no",siteName:"WebMotors",emoji:"🚗"},airbnb:{title:"Bem-vindo ao Vyntra",tagline:"Onde tem anfitrião, tem oportunidade. Bora caçar.",subtitle:"Você está prospectando no",siteName:"Airbnb",emoji:"🏠"},google:{title:"Bem-vindo ao Vyntra",tagline:"A cidade está cheia de leads. Vamos mapeá-los.",subtitle:"Você está prospectando no",siteName:"Google Maps",emoji:"📍"},global:{title:"Pronto pra prospectar",tagline:"Sua próxima lista de leads está nessa página.",subtitle:"Você está prospectando em",siteName:"qualquer página",emoji:"🎯"}};function r(t){return`consecom-welcome-${t}`}const c=`
.vy-welcome {
  position: fixed; inset: 0; z-index: 2147483647;
  display: flex; align-items: center; justify-content: center;
  background: rgba(12,8,24,0.86);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  will-change: opacity;
  animation: vy-fade-in 0.45s ease-out;
  font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
}
.vy-welcome.leaving { animation: vy-fade-out 0.45s ease-out forwards; }
@keyframes vy-fade-in { from { opacity: 0; } to { opacity: 1; } }
@keyframes vy-fade-out { from { opacity: 1; } to { opacity: 0; } }

.vy-welcome__card {
  position: relative;
  background: linear-gradient(135deg, rgba(5,150,105,0.18), rgba(16,185,129,0.08));
  border: 1px solid rgba(5,150,105,0.35);
  border-radius: 24px;
  padding: 38px 42px 30px;
  max-width: 460px;
  width: calc(100% - 40px);
  text-align: center;
  color: #ecfdf5;
  box-shadow: 0 30px 80px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08);
  animation: vy-card-in 0.65s cubic-bezier(0.16, 1, 0.3, 1);
  will-change: transform, opacity;
  overflow: hidden;
}
.vy-welcome.leaving .vy-welcome__card { animation: vy-card-out 0.4s ease-in forwards; }
@keyframes vy-card-in {
  0% { opacity: 0; transform: translateY(42px) scale(0.9); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
@keyframes vy-card-out {
  to { opacity: 0; transform: translateY(-24px) scale(0.95); }
}

.vy-welcome__logo {
  width: 76px; height: 76px;
  margin: 0 auto 20px;
  border-radius: 22px;
  display: flex; align-items: center; justify-content: center;
  font-weight: 800; font-size: 38px; font-style: italic; color: #fff;
  background: linear-gradient(135deg, #047857, #059669, #10b981);
  box-shadow: 0 16px 40px rgba(4,120,87,0.5);
  animation: vy-logo-pop 0.85s 0.15s cubic-bezier(0.16, 1, 0.3, 1) backwards, vy-logo-glow 2.6s 1.2s ease-in-out infinite;
  will-change: transform, box-shadow;
}
@keyframes vy-logo-pop {
  0% { transform: scale(0.4) rotate(-22deg); opacity: 0; }
  55% { transform: scale(1.12) rotate(6deg); }
  100% { transform: scale(1) rotate(0); }
}
@keyframes vy-logo-glow {
  0%, 100% { box-shadow: 0 16px 40px rgba(4,120,87,0.5); }
  50% { box-shadow: 0 16px 62px rgba(5,150,105,0.9), 0 0 34px rgba(16,185,129,0.45); }
}

.vy-welcome__title {
  font-size: 26px; font-weight: 800; letter-spacing: -0.02em; margin-bottom: 14px;
  background: linear-gradient(135deg, #fff, #a7f3d0);
  -webkit-background-clip: text; background-clip: text;
  -webkit-text-fill-color: transparent; color: transparent;
  animation: vy-text-up 0.5s 0.4s backwards;
}
.vy-welcome__site {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 6px 16px; background: rgba(255,255,255,0.08); border-radius: 999px;
  font-size: 13px; font-weight: 600; color: #6ee7b7; margin-bottom: 18px;
  animation: vy-text-up 0.5s 0.55s backwards;
}
.vy-welcome__site b { color: #fff; font-weight: 700; }
.vy-welcome__emoji { font-size: 16px; }
.vy-welcome__tagline {
  font-size: 14px; color: #b7d6c8; line-height: 1.6; margin-bottom: 24px; font-style: italic;
  animation: vy-text-up 0.5s 0.7s backwards;
}
@keyframes vy-text-up {
  from { opacity: 0; transform: translateY(14px); }
  to { opacity: 1; transform: translateY(0); }
}

.vy-welcome__cta {
  background: linear-gradient(135deg, #047857, #059669);
  border: none; color: #fff; font-weight: 700;
  padding: 12px 30px; border-radius: 999px; font-size: 14px; cursor: pointer;
  letter-spacing: 0.02em; box-shadow: 0 12px 28px rgba(4,120,87,0.5);
  transition: transform 0.15s, box-shadow 0.2s, filter 0.15s;
  animation: vy-text-up 0.5s 0.85s backwards;
}
.vy-welcome__cta:hover { transform: translateY(-2px); box-shadow: 0 16px 38px rgba(4,120,87,0.75); filter: brightness(1.08); }
.vy-welcome__cta:active { transform: translateY(0); }

.vy-welcome__particles { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
.vy-welcome__particles span {
  position: absolute; width: 6px; height: 6px;
  background: rgba(16,185,129,0.65); border-radius: 50%;
  bottom: -10px;
  animation: vy-particle var(--t) var(--d) linear infinite;
}
@keyframes vy-particle {
  0% { transform: translateY(0) scale(0); opacity: 0; }
  10% { opacity: 1; }
  100% { transform: translateY(-120vh) scale(1); opacity: 0; }
}
@media (prefers-reduced-motion: reduce) {
  .vy-welcome, .vy-welcome__card, .vy-welcome__logo,
  .vy-welcome__title, .vy-welcome__site, .vy-welcome__tagline,
  .vy-welcome__cta, .vy-welcome__particles span { animation: none !important; }
}
`;function l(t){var s;try{if(sessionStorage.getItem(r(t)))return;sessionStorage.setItem(r(t),"1")}catch{}if(!document.getElementById("vy-welcome-css")){const a=document.createElement("style");a.id="vy-welcome-css",a.textContent=c,document.head.appendChild(a)}const o=n[t],e=document.createElement("div");e.className="vy-welcome",e.innerHTML=`
    <div class="vy-welcome__card">
      <div class="vy-welcome__particles">${Array.from({length:12},()=>`<span style="left:${(Math.random()*100).toFixed(2)}%;--d:${(Math.random()*1.5).toFixed(2)}s;--t:${(2.2+Math.random()*3).toFixed(2)}s"></span>`).join("")}</div>
      <div class="vy-welcome__logo">V</div>
      <div class="vy-welcome__title">${o.title}</div>
      <div class="vy-welcome__site"><span class="vy-welcome__emoji">${o.emoji}</span><span>${o.subtitle} <b>${o.siteName}</b></span></div>
      <div class="vy-welcome__tagline">${o.tagline}</div>
      <button class="vy-welcome__cta">Vamos lá →</button>
    </div>
  `,document.body.appendChild(e);const i=()=>e.classList.add("leaving");e.addEventListener("click",a=>{a.target===e&&i()}),(s=e.querySelector(".vy-welcome__cta"))==null||s.addEventListener("click",i),setTimeout(i,6e3),setTimeout(()=>e.remove(),6800)}function m(t,o){const e=t.toLowerCase();return/(^|\.)wepsy\.com\.br$/.test(e)?"wepsy":/(^|\.)webmotors\.com\.br$/.test(e)?"webmotors":/(^|\.)airbnb\.com(\.br)?$/.test(e)?"airbnb":/(^|\.)google\.(com|com\.br|[a-z.]+)\/maps\//.test(o)||e.startsWith("maps.google")?"google":"global"}export{m as detectWelcomeSite,l as showWelcome};
