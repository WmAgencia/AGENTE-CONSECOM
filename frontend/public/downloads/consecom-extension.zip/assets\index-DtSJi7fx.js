const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/global-WbbZDocz.js","assets/config-SYaVBN7W.js"])))=>i.map(i=>d[i]);
import{g as y}from"./config-SYaVBN7W.js";const Y="modulepreload",G=function(o){return"/"+o},q={},T=function(e,t,n){let a=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const r=document.querySelector("meta[property=csp-nonce]"),i=(r==null?void 0:r.nonce)||(r==null?void 0:r.getAttribute("nonce"));a=Promise.allSettled(t.map(l=>{if(l=G(l),l in q)return;q[l]=!0;const p=l.endsWith(".css"),m=p?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${m}`))return;const c=document.createElement("link");if(c.rel=p?"stylesheet":Y,p||(c.as="script"),c.crossOrigin="",c.href=l,i&&c.setAttribute("nonce",i),document.head.appendChild(c),p)return new Promise((d,u)=>{c.addEventListener("load",d),c.addEventListener("error",()=>u(new Error(`Unable to preload CSS for ${l}`)))})}))}function s(r){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=r,window.dispatchEvent(i),!i.defaultPrevented)throw r}return a.then(r=>{for(const i of r||[])i.status==="rejected"&&s(i.reason);return e().catch(s)})},Q={maps:!0,webmotors:!0,wepsy:!0};async function K(){try{const o=await chrome.runtime.sendMessage({type:"consecom:api",path:"/api/extension/sites",method:"GET"}),e=(o==null?void 0:o.data)??{};return{maps:e.maps!==!1,webmotors:e.webmotors!==!1,wepsy:e.wepsy!==!1}}catch{return{...Q}}}async function N(o,e,t={}){const n=await y(),a=await chrome.runtime.sendMessage({type:"consecom:api",path:o,method:"POST",headers:t,body:e,extensionKey:n.extensionKey});return(a==null?void 0:a.ok)===!1&&(a==null?void 0:a.status)===403?{ok:!1,status:403,data:{message:"Extensão não vinculada. Baixe novamente a extensão no painel Vyntra."}}:a??{ok:!1,status:0,data:{message:"Sem resposta do background."}}}async function U(o,e){if(e.length===0)return{ok:0,failed:0};const t=await N("/api/extension/delete",{placeIds:e,ownerUserId:o.ownerUserId});if(!t.ok)return{ok:0,failed:e.length};const n=t.data??{};return{ok:Number(n.ok??0),failed:Number(n.failed??0)}}async function X(o){if(!o.extensionKey||!o.ownerUserId)return null;const e=await N("/api/extension/plan",{ownerUserId:o.ownerUserId});if(!e.ok)return null;const t=e.data??{};return typeof t.limited!="boolean"?null:{limited:t.limited,used:Number(t.used??0),limit:Number(t.limit??0),remaining:t.remaining==null?null:Number(t.remaining)}}async function $(o,e,t,n){var p,m,c,d;if(!o.extensionKey||!o.ownerUserId)return{ok:0,failed:e.length,firstError:"Extensão não vinculada a uma conta Vyntra. Baixe novamente a extensão no painel.",errors:[]};const a=e.map(u=>({name:u.name,phone:u.phone??"",category:u.category,website:u.website,address:u.address,city:u.city,state:u.state,rating:u.rating,reviews:u.reviews,latitude:u.latitude,longitude:u.longitude,place_id:u.place_id,instagram:u.instagram,facebook:u.facebook})),s=await N("/api/extension/import-leads",{ownerUserId:o.ownerUserId,leads:a,listName:`Importação ${new Date().toISOString().slice(0,10)}`,source:(n==null?void 0:n.source)??"google_maps",sourceDetail:(n==null?void 0:n.sourceDetail)??"vyntra_prospector",tags:n==null?void 0:n.tags,prospectFilters:n==null?void 0:n.prospectFilters,score:n==null?void 0:n.score,serviceInterest:n==null?void 0:n.serviceInterest,prospectedAt:(n==null?void 0:n.prospectedAt)??new Date().toISOString()});if(!s.ok){const u=s.data??{},h=u.message??u.error??`HTTP ${s.status}`;return console.error("[IMPORT] Backend import failed:",{status:s.status,message:h}),{ok:0,failed:e.length,firstError:h,errors:[],quota:u.quota??null}}const r=s.data??{},i=Number(((p=r.summary)==null?void 0:p.created)??0),l=Number(((m=r.summary)==null?void 0:m.errors)??0);return console.log("[IMPORT] Backend import response:",{status:s.status,ok:i,failed:l}),e.forEach((u,h)=>t==null?void 0:t(h+1,e.length)),{ok:i,failed:l,firstError:typeof((c=r.firstError)==null?void 0:c.body)=="string"?r.firstError.body:void 0,errors:[],quotaCut:Number(((d=r.summary)==null?void 0:d.quotaCut)??0),quota:r.quota??null}}async function V(o,e){if(e.length===0)return{used:[],noInterest:{}};const t=await N("/api/extension/known",{placeIds:e});if(!t.ok)return{used:[],noInterest:{}};const n=t.data??{};return{used:Array.isArray(n.used)?n.used:[],noInterest:n.noInterest??{}}}const J=Object.freeze(Object.defineProperty({__proto__:null,deleteLeads:U,getExtensionSites:K,getPlanQuota:X,importLeads:$,knownPlaceIds:V},Symbol.toStringTag,{value:"Module"}));function z(o){let e=0;o.rating!=null&&o.rating>0&&(e=Math.min(45,Math.round(o.rating/5*45)));let t=0;o.reviews!=null&&o.reviews>0&&(t=Math.min(30,Math.round(Math.log10(o.reviews+1)/Math.log10(1e4)*30)));const n=o.website?10:0,a=o.phone?10:0,s=o.category?5:0,r=Math.max(0,Math.min(100,e+t+n+a+s)),i=ee(r);return{total:r,band:i,label:Z[i],parts:{rating:e,reviews:t,website:n,phone:a,category:s}}}const Z={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Oportunidade média",baixa:"Baixa oportunidade",nenhuma:"Sem dados"};function ee(o){return o>=90?"alta":o>=70?"boa":o>=50?"media":o>=1?"baixa":"nenhuma"}function te(o){return"cs-band-"+o}function Se(o,e){return!(e.has("com_whatsapp")&&o.whatsapp===!1||e.has("sem_site")&&o.website||e.has("nota_baixa")&&o.rating!=null&&o.rating>=3.5)}const ne=[{id:"sem_site",label:"Sem site",cat:"site",value:"sem_site",accent:"#f87171"},{id:"alta",label:"Alta oportunidade",cat:"score",value:"alta",accent:"#10b981"},{id:"site_ruim",label:"Site ruim",cat:"site",value:"site_ruim",accent:"#f59e0b"},{id:"poucas_avaliacoes",label:"Poucas avaliações",cat:"qualify",value:"poucas_avaliacoes",accent:"#a855f7"},{id:"nota_baixa",label:"Nota baixa",cat:"qualify",value:"nota_baixa",accent:"#f87171"},{id:"sem_presenca_digital",label:"Sem presença digital",cat:"digital",value:"sem_presenca_digital",accent:"#64748b"},{id:"tem_telefone",label:"Tem telefone",cat:"qualify",value:"tem_telefone",accent:"#22c55e"},{id:"sem_instagram",label:"Sem Instagram",cat:"digital",value:"sem_instagram",accent:"#ec4899"},{id:"sem_whatsapp",label:"Sem WhatsApp",cat:"digital",value:"sem_whatsapp",accent:"#f87171"},{id:"tem_whatsapp",label:"Tem WhatsApp",cat:"digital",value:"tem_whatsapp",accent:"#22c55e"},{id:"tem_site",label:"Tem site",cat:"site",value:"site_bom",accent:"#22c55e"},{id:"boa",label:"Boa oportunidade",cat:"score",value:"boa",accent:"#84cc16"},{id:"media",label:"Média oportunidade",cat:"score",value:"media",accent:"#f59e0b"},{id:"baixa",label:"Baixa oportunidade",cat:"score",value:"baixa",accent:"#f87171"}],ae={site:[],digital:[],qualify:[],minRating:null,minReviews:null,scoreBands:[],service:"todos",activeChips:new Set};function F(o,e){if(e.site.length>0&&!se(o,e.site)||e.digital.length>0&&!oe(o,e.digital)||e.qualify.length>0&&!re(o,e.qualify)||e.minRating!=null&&e.minRating>0&&(o.rating==null||o.rating<e.minRating)||e.minReviews!=null&&e.minReviews>0&&(o.reviews==null||o.reviews<e.minReviews))return!1;if(e.scoreBands.length>0){const t=z(o);if(t.band==="nenhuma"||!e.scoreBands.includes(t.band))return!1}return!0}function se(o,e){const t=!!o.website;for(const n of e)switch(n){case"sem_site":if(!t)return!0;break;case"site_bom":case"site_profissional":case"site_ruim":case"site_desatualizado":case"site_nao_responsivo":case"site_lento":case"site_amador":case"site_quebrado":case"site_problemas":if(t)return!0;break}return!1}function oe(o,e){const t=!!o.instagram,n=!!o.facebook,a=!!o.phone;for(const s of e)switch(s){case"sem_instagram":if(!t)return!0;break;case"instagram_encontrado":if(t)return!0;break;case"sem_facebook":if(!n)return!0;break;case"sem_presenca_digital":if(!t&&!n&&!a)return!0;break;case"sem_whatsapp":if(!a)return!0;break;case"tem_whatsapp":if(a)return!0;break;case"instagram_pouco_ativo":case"instagram_sem_link_site":if(t)return!0;break}return!1}function re(o,e){for(const t of e)switch(t){case"tem_telefone":if(o.phone)return!0;break;case"tem_site":if(o.website)return!0;break;case"poucas_avaliacoes":if(o.reviews==null||o.reviews<10)return!0;break;case"muitas_avaliacoes":if(o.reviews!=null&&o.reviews>=100)return!0;break;case"nota_baixa":if(o.rating==null||o.rating<4)return!0;break}return!1}function ie(o){const e=[],t={sem_site:"Sem site",site_ruim:"Site ruim",site_desatualizado:"Site desatualizado",site_nao_responsivo:"Site não responsivo",site_lento:"Site lento",site_amador:"Site amador",site_quebrado:"Site quebrado",site_problemas:"Site com problemas",site_bom:"Site bom",site_profissional:"Site profissional"},n={sem_instagram:"Sem Instagram",instagram_encontrado:"Instagram encontrado",instagram_pouco_ativo:"Instagram pouco ativo",instagram_sem_link_site:"Instagram sem link para site",sem_facebook:"Sem Facebook",sem_presenca_digital:"Sem presença digital",sem_whatsapp:"Sem WhatsApp",tem_whatsapp:"Tem WhatsApp"},a={tem_telefone:"Tem telefone",poucas_avaliacoes:"Poucas avaliações",nota_baixa:"Nota baixa",muitas_avaliacoes:"Muitas avaliações",tem_site:"Tem site"};for(const r of o.site)e.push(t[r]);for(const r of o.digital)e.push(n[r]);for(const r of o.qualify)e.push(a[r]);o.minRating!=null&&o.minRating>0&&e.push(`${o.minRating.toFixed(1)}+ estrelas`),o.minReviews!=null&&o.minReviews>0&&e.push(`${o.minReviews}+ avaliações`);const s={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Média oportunidade",baixa:"Baixa oportunidade"};for(const r of o.scoreBands)e.push(s[r]);return e}const ce=`/* ===== Vyntra Prospector — identidade visual do sistema (tema claro, Inter, verde WhatsApp) ===== */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {
  --vy-font: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
  --vy-bg: #ffffff;
  --vy-app: #eef3f1;
  --vy-panel: #ffffff;
  --vy-card: rgba(4, 120, 87, 0.04);
  --vy-card-hover: rgba(4, 120, 87, 0.07);
  --vy-line: #e3e8e6;
  --vy-line-2: #d5ddd9;
  --vy-line-strong: #c3cec9;
  --vy-fg: #10231c;
  --vy-secondary: #1f2b26;
  --vy-muted: #5b6b64;
  --vy-faint: #8a9a93;
  --vy-accent: #059669;
  --vy-accent-600: #047857;
  --vy-accent-700: #065f46;
  --vy-accent-soft: rgba(4, 120, 87, 0.1);
  --vy-danger: #dc2626;
  --vy-danger-soft: rgba(220, 38, 38, 0.08);
  --vy-warn: #d97706;
  --vy-shadow: 0 8px 28px rgba(15, 23, 42, 0.1), 0 2px 6px rgba(15, 23, 42, 0.05);
  --vy-shadow-strong: 0 16px 44px rgba(15, 23, 42, 0.16), 0 4px 10px rgba(15, 23, 42, 0.07);
}

/* ===== Botão flutuante Vyntra (quando painel minimizado) ===== */
.consecom-floatbtn {
  position: fixed;
  z-index: 2147483647;
  width: 48px;
  height: 48px;
  border-radius: 15px;
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  color: #fff;
  cursor: grab;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 12px 32px rgba(4, 120, 87, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.22);
  user-select: none;
  touch-action: none;
  font-family: var(--vy-font);
  font-size: 22px;
  font-weight: 800;
  font-style: italic;
  line-height: 1;
  border: none;
  transition: transform 0.12s, filter 0.15s;
  padding: 0;
}
.consecom-floatbtn:active { cursor: grabbing; }
.consecom-floatbtn:hover { filter: brightness(1.08); transform: translateY(-1px) scale(1.03); }
.consecom-floatbtn {
  opacity: 0;
  transform: scale(0.85);
  transition: opacity 0.16s ease, transform 0.18s ease, filter 0.12s;
  pointer-events: none;
}
.consecom-floatbtn.open {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}

/* ===== Painel flutuante Vyntra (arrastável) ===== */
.consecom-balloon {
  position: fixed;
  z-index: 2147483647;
  top: 20px;
  right: 20px;
  width: 230px;
  max-width: calc(100vw - 24px);
  height: min(660px, calc(100vh - 24px));
  max-height: calc(100vh - 24px);
  min-height: 60px;
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 18px;
  box-shadow: var(--vy-shadow-strong);
  display: flex;
  flex-direction: column;
  opacity: 0;
  transform: translateX(calc(110% + 20px)) scale(0.96);
  pointer-events: none;
  transition: transform 0.18s ease, opacity 0.16s ease;
  font-family: var(--vy-font);
  overflow: hidden;
  color: var(--vy-fg);
}
.consecom-balloon.open {
  opacity: 1;
  transform: translateX(0) scale(1);
  pointer-events: auto;
}

/* ===== Header (grip + logo + título + Conta + fechar) ===== */
.cs-balloon-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 11px;
  border-bottom: 1px solid var(--vy-line);
  cursor: grab;
  flex-shrink: 0;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  background:
    radial-gradient(120% 160% at 100% -20%, rgba(16, 185, 129, 0.16), transparent 55%),
    linear-gradient(135deg, #ffffff, #eef7f2);
  position: relative;
}
.cs-balloon-header::after {
  content: "";
  position: absolute;
  left: 0; right: 0; bottom: -1px;
  height: 2px;
  background: linear-gradient(90deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
}
.cs-balloon-header:active { cursor: grabbing; }
.cs-grip {
  cursor: grab;
  color: var(--vy-faint);
  font-size: 16px;
  letter-spacing: -2px;
  line-height: 1;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  padding: 0 2px;
}
.cs-grip:active { cursor: grabbing; }
.cs-logo {
  width: 26px;
  height: 26px;
  border-radius: 9px;
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 800;
  font-size: 13px;
  font-style: italic;
  box-shadow: 0 4px 12px rgba(4, 120, 87, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.25);
}
.cs-title {
  font-size: 13px;
  font-weight: 800;
  letter-spacing: 0.02em;
  color: var(--vy-fg);
  flex: 1;
  min-width: 0;
}
.cs-head-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}
.cs-icon-btn {
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: transparent;
  border: 1px solid transparent;
  color: var(--vy-muted);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.12s, color 0.12s, border-color 0.12s;
  padding: 0;
}
.cs-icon-btn:hover {
  background: var(--vy-accent-soft);
  color: var(--vy-accent);
  border-color: var(--vy-line-2);
}
.cs-icon-btn svg { width: 14px; height: 14px; fill: currentColor; }

/* ===== Body com scroll interno ===== */
.cs-balloon-body {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  min-height: 0;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: linear-gradient(180deg, #f4f9f6, var(--vy-app));
}
.cs-balloon-body::-webkit-scrollbar { width: 6px; }
.cs-balloon-body::-webkit-scrollbar-thumb { background: var(--vy-line-strong); border-radius: 999px; }

/* ===== Bloco/seção padronizado (header + conteúdo) ===== */
.cs-block {
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 14px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.03);
}
.cs-block__title {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--vy-muted);
}

/* ===== Busca ===== */
.cs-search {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cs-search__fields { display: flex; gap: 6px; }
.cs-search__field { flex: 1; display: flex; flex-direction: column; gap: 3px; }
.cs-search__field--sm { flex: 0 0 56px; }
.cs-search__field > span {
  font-size: 9px;
  font-weight: 700;
  letter-spacing: 0.08em;
  color: var(--vy-muted);
}
.cs-search__input {
  width: 100%;
  box-sizing: border-box;
  padding: 8px 10px;
  background: var(--vy-panel);
  border: 1px solid var(--vy-line-2);
  border-radius: 10px;
  color: var(--vy-fg);
  font-size: 12px;
  font-family: var(--vy-font);
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
}
.cs-search__input::placeholder { color: var(--vy-faint); }
.cs-search__input:focus {
  border-color: var(--vy-accent);
  box-shadow: 0 0 0 3px var(--vy-accent-soft);
}
.cs-search__btn {
  width: 100%;
  padding: 9px 0;
  border: 1px solid var(--vy-line-2);
  border-radius: 999px;
  background: var(--vy-panel);
  color: var(--vy-fg);
  font-family: var(--vy-font);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s, box-shadow 0.15s;
}
.cs-search__btn:hover {
  background: var(--vy-accent-soft);
  border-color: var(--vy-accent);
  color: var(--vy-accent);
  box-shadow: 0 4px 12px rgba(4, 120, 87, 0.12);
}

/* Status de localização (linha auxiliar na busca) */
.cs-loc {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  font-size: 11px;
  color: var(--vy-muted);
  text-align: center;
  padding: 2px 0;
}
.cs-loc svg { width: 12px; height: 12px; fill: currentColor; }

/* ===== Filtros (chips) ===== */
.cs-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}
.cs-chip {
  font-family: var(--vy-font);
  font-size: 10.5px;
  font-weight: 600;
  padding: 5px 9px;
  border-radius: 999px;
  background: var(--vy-panel);
  color: var(--vy-secondary);
  border: 1px solid var(--vy-line-2);
  cursor: pointer;
  transition: background 0.12s, color 0.12s, border-color 0.12s;
  white-space: nowrap;
}
.cs-chip:hover {
  border-color: var(--vy-accent);
  color: var(--vy-accent);
}
.cs-chip--on {
  background: var(--vy-accent) !important;
  color: #fff !important;
  border-color: var(--vy-accent) !important;
}

/* ===== PROSPECTAR (CTA principal) ===== */
.cs-prospect {
  padding: 13px 0;
  border: none;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  color: #fff;
  font-family: var(--vy-font);
  font-size: 14px;
  font-weight: 800;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  cursor: pointer;
  transition: filter 0.15s, transform 0.12s, box-shadow 0.15s;
  box-shadow: 0 6px 18px rgba(4, 120, 87, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.22);
}
.cs-prospect:hover:not(:disabled) {
  filter: brightness(1.06);
  transform: translateY(-1px);
  box-shadow: 0 10px 24px rgba(4, 120, 87, 0.34);
}
.cs-prospect:disabled { opacity: 0.6; cursor: default; transform: none; box-shadow: none; }

/* Ações lado a lado: PROSPECTAR + PARAR */
.cs-prospect-actions {
  display: flex;
  flex-direction: row;
  gap: 6px;
}
.cs-prospect-actions .cs-stop {
  flex: 0 0 auto;
}

/* ===== Área de leads com scroll ===== */
.cs-leads {
  flex: 1;
  min-height: 140px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cs-list {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-right: 2px;
}
.cs-list::-webkit-scrollbar { width: 5px; }
.cs-list::-webkit-scrollbar-thumb { background: var(--vy-line-strong); border-radius: 999px; }

/* Card de lead */
.cs-card,
.cs-pcard {
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 10px;
  padding: 9px 10px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  transition: border-color 0.15s, background 0.15s;
}
.cs-card:hover,
.cs-pcard:hover { border-color: var(--vy-line-strong); }
.cs-card__top,
.cs-pcard__top {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.cs-card__name,
.cs-pcard__name {
  flex: 1;
  min-width: 0;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--vy-fg);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cs-card__badge,
.cs-pcard__badge {
  font-size: 9.5px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 999px;
  letter-spacing: 0.02em;
  white-space: nowrap;
  flex: 0 0 auto;
}
.cs-band-alta { color: var(--vy-accent-700); background: rgba(4, 120, 87, 0.12); border: 1px solid rgba(4, 120, 87, 0.25); }
.cs-band-boa { color: var(--vy-accent-600); background: rgba(4, 120, 87, 0.08); border: 1px solid rgba(4, 120, 87, 0.2); }
.cs-band-media { color: var(--vy-warn); background: rgba(217, 119, 6, 0.1); border: 1px solid rgba(217, 119, 6, 0.25); }
.cs-band-baixa { color: var(--vy-danger); background: var(--vy-danger-soft); border: 1px solid rgba(220, 38, 38, 0.2); }
.cs-band-nenhuma { color: var(--vy-muted); background: rgba(91, 107, 100, 0.08); border: 1px solid var(--vy-line-strong); }

.cs-card__meta,
.cs-pcard__meta {
  font-size: 11px;
  color: var(--vy-muted);
  display: flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cs-card__rating,
.cs-pcard__rating {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 11px;
  color: var(--vy-warn);
  font-weight: 700;
}
.cs-card__rating svg,
.cs-pcard__rating svg { width: 11px; height: 11px; fill: currentColor; }

/* Barra de score */
.cs-card__bar,
.cs-pcard__scorebar {
  display: flex;
  align-items: center;
  gap: 8px;
}
.cs-card__btrack,
.cs-pcard__bar {
  flex: 1;
  height: 5px;
  border-radius: 999px;
  background: var(--vy-line);
  overflow: hidden;
}
.cs-card__bfill,
.cs-pcard__barfill {
  height: 100%;
  border-radius: 999px;
  background: var(--vy-accent);
  transition: width 0.4s ease;
}
.cs-card__score,
.cs-pcard__score {
  font-size: 10.5px;
  font-weight: 800;
  color: var(--vy-fg);
  flex: 0 0 auto;
}
.cs-card__score small,
.cs-pcard__score small { color: var(--vy-muted); font-weight: 600; }

/* Ações do card (botão de selecionar como lead) */
.cs-card__actions,
.cs-pcard__actions { display: flex; gap: 6px; margin-top: 1px; }
.cs-card__btn,
.cs-pcard__btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 7px 8px;
  border: none;
  border-radius: 9px;
  font-family: var(--vy-font);
  font-size: 11.5px;
  font-weight: 700;
  cursor: pointer;
  transition: filter 0.12s, background 0.12s;
}
.cs-card__btn svg,
.cs-pcard__btn svg { width: 12px; height: 12px; fill: currentColor; }
.cs-card__lead,
.cs-pcard__lead {
  background: var(--vy-accent);
  color: #fff;
}
.cs-card__lead:hover:not(:disabled),
.cs-pcard__lead:hover:not(:disabled) { filter: brightness(1.06); }
.cs-card__lead.on,
.cs-pcard__lead.on { background: var(--vy-accent-700); }
.cs-card__lead.used,
.cs-pcard__lead.used { background: var(--vy-line); color: var(--vy-muted); cursor: default; }
.cs-card__lead.nointerest,
.cs-pcard__lead.nointerest { background: var(--vy-danger-soft); color: var(--vy-danger); }
.cs-card__site,
.cs-pcard__site {
  background: var(--vy-card);
  color: var(--vy-fg);
}
.cs-card__site:hover:not(:disabled),
.cs-pcard__site:hover:not(:disabled) { background: var(--vy-card-hover); }
.cs-card__site:disabled,
.cs-pcard__site:disabled { opacity: 0.4; cursor: default; }

/* ===== Mini-card CONTA (toggle no header) ===== */
.cs-account {
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 12px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  animation: cs-fadein 0.18s ease;
}
@keyframes cs-fadein { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: none; } }
.cs-account__head {
  display: flex;
  align-items: center;
  gap: 8px;
}
.cs-account__avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--vy-accent-soft);
  color: var(--vy-accent-700);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 14px;
}
.cs-account__head-text { flex: 1; min-width: 0; }
.cs-account__title {
  font-size: 12px;
  font-weight: 700;
  color: var(--vy-fg);
}
.cs-account__sub {
  font-size: 10.5px;
  color: var(--vy-muted);
}
.cs-account__quota {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: var(--vy-muted);
  padding-top: 8px;
  border-top: 1px dashed var(--vy-line);
}
.cs-account__quota strong { color: var(--vy-fg); font-weight: 700; }
.cs-account__progress {
  height: 6px;
  border-radius: 999px;
  background: var(--vy-line);
  overflow: hidden;
}
.cs-account__progress-fill {
  height: 100%;
  background: var(--vy-accent);
  border-radius: 999px;
  transition: width 0.4s ease;
}
.cs-account__progress-fill--full { background: var(--vy-danger); }
.cs-account__badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 999px;
  background: var(--vy-accent-soft);
  color: var(--vy-accent-700);
}
.cs-account__badge--off { background: var(--vy-danger-soft); color: var(--vy-danger); }

/* ===== Rodapé do painel ===== */
.cs-balloon-footer {
  border-top: 1px solid var(--vy-line);
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  background: var(--vy-panel);
}
.cs-foot-row { display: flex; gap: 6px; }
.cs-btn {
  border: 1px solid var(--vy-line-2);
  background: var(--vy-panel);
  color: var(--vy-secondary);
  border-radius: 10px;
  padding: 8px 10px;
  font-family: var(--vy-font);
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s, color 0.12s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  flex: 1;
}
.cs-btn svg { width: 13px; height: 13px; fill: currentColor; }
.cs-btn:hover:not(:disabled) {
  background: var(--vy-accent-soft);
  border-color: var(--vy-accent);
  color: var(--vy-accent);
}
.cs-btn:disabled { opacity: 0.5; cursor: default; }
.cs-btn--primary {
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  color: #fff;
  border-color: transparent;
  font-weight: 700;
  letter-spacing: 0.03em;
  text-transform: uppercase;
  padding: 11px 12px;
  font-size: 12px;
  box-shadow: 0 6px 18px rgba(4, 120, 87, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.2);
}
.cs-btn--primary:hover:not(:disabled) {
  background: var(--vy-accent-600);
  border-color: var(--vy-accent-600);
  color: #fff;
  filter: brightness(1.02);
}
.cs-btn--danger:hover:not(:disabled) {
  background: var(--vy-danger-soft);
  border-color: var(--vy-danger);
  color: var(--vy-danger);
}

/* ===== Modal de confirmação (Limpar leads) ===== */
.cs-modal {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(15, 23, 42, 0.4);
  backdrop-filter: blur(2px);
  opacity: 0;
  transition: opacity 0.16s ease;
  font-family: var(--vy-font);
}
.cs-modal.cs-open { opacity: 1; }
.cs-modal__card {
  width: min(340px, calc(100vw - 32px));
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 14px;
  padding: 18px 16px;
  box-shadow: var(--vy-shadow);
  color: var(--vy-fg);
  transform: translateY(6px);
  transition: transform 0.16s ease;
}
.cs-modal.cs-open .cs-modal__card { transform: translateY(0); }
.cs-modal__title {
  font-size: 14px;
  font-weight: 700;
  color: var(--vy-fg);
  margin-bottom: 6px;
}
.cs-modal__text {
  font-size: 12.5px;
  line-height: 1.55;
  color: var(--vy-muted);
  margin-bottom: 14px;
}
.cs-modal__actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}
.cs-modal__btn {
  border: 1px solid var(--vy-line-2);
  background: var(--vy-panel);
  border-radius: 9px;
  padding: 8px 14px;
  font-family: var(--vy-font);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s;
}
.cs-modal__btn:hover { background: var(--vy-accent-soft); border-color: var(--vy-accent); color: var(--vy-accent); }
.cs-modal__btn--danger { background: var(--vy-accent); color: #fff; border-color: var(--vy-accent); }
.cs-modal__btn--danger:hover { background: var(--vy-accent-600); border-color: var(--vy-accent-600); color: #fff; }

/* ===== Empty state ===== */
.cs-empty {
  text-align: center;
  color: var(--vy-muted);
  font-size: 12px;
  padding: 28px 8px;
  line-height: 1.6;
}
.cs-empty b { color: var(--vy-fg); font-weight: 700; }

/* ===== Toast ===== */
.consecom-toast {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%) translateY(-18px);
  z-index: 2147483647;
  padding: 10px 16px;
  background: var(--vy-panel);
  color: var(--vy-fg);
  border: 1px solid var(--vy-line);
  border-radius: 12px;
  box-shadow: var(--vy-shadow);
  font-family: var(--vy-font);
  font-size: 13px;
  font-weight: 600;
  opacity: 0;
  transition: opacity 0.25s, transform 0.25s;
  pointer-events: none;
}
.consecom-toast.cs-warn { border-color: var(--vy-warn); color: var(--vy-warn); }
.consecom-toast.cs-show { opacity: 1; transform: translateX(-50%) translateY(0); }

/* ===== Cards nativos enxutos (controles dentro dos cards do Maps) ===== */
.consecom-host {
  position: relative !important;
  min-width: 0 !important;
}
.consecom-host > *:not(.consecom-control) {
  opacity: 0 !important;
  pointer-events: none !important;
  height: 0 !important;
  overflow: hidden !important;
}
.consecom-control {
  position: relative !important;
  z-index: 30 !important;
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  padding: 5px 8px !important;
  background: var(--vy-panel) !important;
  border: 1px solid var(--vy-line) !important;
  border-radius: 8px !important;
  box-sizing: border-box !important;
  min-height: 34px !important;
  font-family: var(--vy-font) !important;
}
.consecom-control .cs-name {
  flex: 1 !important;
  min-width: 0 !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  color: var(--vy-fg) !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}
.consecom-control .cs-actions {
  display: flex !important;
  gap: 4px !important;
  flex: 0 0 auto !important;
}
.consecom-control .cs-round {
  width: 26px !important;
  height: 26px !important;
  border-radius: 50% !important;
  border: none !important;
  cursor: pointer !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 0 !important;
  background: var(--vy-accent) !important;
  color: #fff !important;
  box-shadow: 0 1px 4px rgba(4, 120, 87, 0.3) !important;
  transition: transform 0.1s, background 0.15s !important;
}
.consecom-control .cs-round svg { width: 13px; height: 13px; fill: #fff; }
.consecom-control .cs-round:hover:not(:disabled) { filter: brightness(1.06); transform: scale(1.08); }
.consecom-control .cs-round:disabled { background: var(--vy-line) !important; box-shadow: none !important; cursor: default !important; opacity: 0.6 !important; }
.consecom-control .cs-round:disabled svg { fill: var(--vy-muted); }
.consecom-control .cs-select { background: transparent !important; border: 2px solid var(--vy-accent) !important; color: var(--vy-accent) !important; }
.consecom-control .cs-select svg { fill: var(--vy-accent) !important; }
.consecom-control .cs-select.on { background: var(--vy-accent) !important; color: #fff !important; }
.consecom-control .cs-select.on svg { fill: #fff !important; }
.consecom-control .cs-select.used { background: var(--vy-line) !important; border-color: var(--vy-line) !important; color: var(--vy-muted) !important; }
.consecom-control .cs-select.used svg { fill: var(--vy-muted) !important; }
.consecom-control .cs-select.nointerest { background: var(--vy-danger-soft) !important; border-color: var(--vy-danger) !important; color: var(--vy-danger) !important; font-weight: 700 !important; }
.consecom-control .cs-badge {
  position: absolute !important;
  top: -8px !important;
  right: -6px !important;
  background: var(--vy-accent) !important;
  color: #fff !important;
  font-size: 9px !important;
  font-weight: 700 !important;
  padding: 1px 5px !important;
  border-radius: 999px !important;
  white-space: nowrap !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15) !important;
}

/* ===== Helpers legados (mantidos para não quebrar nada) ===== */
.cs-panel__list {
  flex: 1;
  overflow-y: auto;
  padding: 4px 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.cs-panel__list::-webkit-scrollbar { width: 6px; }
.cs-panel__list::-webkit-scrollbar-thumb { background: var(--vy-line-strong); border-radius: 999px; }
.cs-footer__count {
  font-size: 11px;
  color: var(--vy-muted);
  text-align: center;
  padding-bottom: 2px;
  font-family: var(--vy-font);
}
.cs-footer__count b { color: var(--vy-fg); font-weight: 700; }
`;class le{constructor(){this.cfg=null,this.found=[],this.selected=new Set,this.used=new Set,this.noInterest=new Set,this.scanning=!1,this.clearedSession=!1,this.bubble=null,this.balloon=null,this.floatBtn=null,this.headerEl=null,this.listEl=null,this.locEl=null,this.countEl=null,this.lastQuery="",this.filters={...ae},this.filtersPanel=null,this.resultPanel=null,this.prospecting=!1,this.prospectCancel=!1,this.lastMatched=[],this.debounceScan=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.scan()},350))}})()}async init(){this.cfg=await y(),_e(),this.observeDom(),this.scan("force"),window.addEventListener("click",e=>{var t,n;(t=this.balloon)!=null&&t.classList.contains("open")&&(this.balloon.contains(e.target)||(n=this.floatBtn)!=null&&n.contains(e.target)||this.toggleBalloon(!1))}),chrome.runtime.onMessage.addListener(e=>{((e==null?void 0:e.type)==="consecom:open"||(e==null?void 0:e.type)==="consecom:ping")&&this.toggleBalloon(!0)}),window.addEventListener("resize",()=>{var e;(e=this.balloon)!=null&&e.classList.contains("open")&&this.clampElement(this.balloon),this.floatBtn&&document.body.contains(this.floatBtn)&&this.clampElement(this.floatBtn)}),this.ensureLauncher()}ensureLauncher(){if(this.balloon&&this.balloon.classList.contains("open")||this.floatBtn&&document.body.contains(this.floatBtn))return;(!this.floatBtn||!document.body.contains(this.floatBtn))&&(this.floatBtn=this.buildFloatBtn(),document.body.appendChild(this.floatBtn));const e=this.readPosition();this.floatBtn.style.right=`${e.right}px`,this.floatBtn.style.top=`${e.top}px`,requestAnimationFrame(()=>{var t;return(t=this.floatBtn)==null?void 0:t.classList.add("open")})}observeDom(){new MutationObserver(()=>this.debounceScan()).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("scroll",()=>this.debounceScan(),{passive:!0})}scan(e="scan"){if(!(this.scanning&&e!=="force")){this.scanning=!0;try{this.syncArea(),this.refreshCards(),this.prune(),this.renderControls(),this.renderBalloonList()}finally{this.scanning=!1}}}syncArea(){var n;const e=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]'),t=((e==null?void 0:e.value)||"").trim();t&&t!==this.lastQuery&&(this.lastQuery=t,this.clearedSession=!1,this.selected.clear(),this.found=[],this.locEl&&(this.locEl.textContent=t),(n=this.balloon)!=null&&n.classList.contains("open")&&this.renderCardList()),t&&(this.lastQuery=t)}renderControls(){}makeHostSlim(e){e.classList.contains("consecom-host")||e.classList.add("consecom-host")}toggleSelected(e){this.used.has(e)||this.noInterest.has(e)||(this.selected.has(e)?this.selected.delete(e):this.selected.add(e),this.syncAll())}toggleControl(e){this.toggleSelected(e)}selectAllAvailable(){const e=this.found.filter(a=>!this.used.has(a.key)&&!this.noInterest.has(a.key)),t=Math.min(50,e.length),n=new Set;for(let a=0;a<t;a++)n.add(e[a].key);this.selected=n,this.syncAll(),b(`✅ ${this.selected.size} selecionado(s) (máx. 50 por importação)`)}clearSelection(){this.selected.clear(),this.syncAll()}buildControl(e){const t=document.createElement("div");t.className="consecom-control",t.title=e.lead.name;const n=document.createElement("button");n.type="button",n.className="cs-round cs-select",n.title="Selecionar",n.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),this.toggleControl(e.key)});const a=document.createElement("span");a.className="cs-name",a.textContent=e.lead.name,a.title=e.lead.name;const s=document.createElement("div");s.className="cs-actions";const r=document.createElement("button");r.type="button",r.className="cs-round",r.title="Abrir site",r.innerHTML=H,e.lead.website?r.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):r.disabled=!0;const i=document.createElement("button");i.type="button",i.className="cs-round",i.title="Chamar",i.innerHTML=we,e.lead.phone?i.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),window.location.href=`tel:${e.lead.phone.replace(/\s+/g,"")}`}):i.disabled=!0,s.append(r,i);const l=document.createElement("span");return l.className="cs-badge",l.textContent="Sem interesse",l.style.display="none",t.append(n,a,s,l),t}updateControl(e){var s,r;const t=(s=e.control)==null?void 0:s.querySelector(".cs-select");if(!t)return;const n=this.noInterest.has(e.key);t.classList.toggle("nointerest",n);const a=(r=e.control)==null?void 0:r.querySelector(".cs-badge");if(a&&(a.style.display=n?"block":"none"),n){t.disabled=!0,t.title="Sem interesse — não importar (6 meses)",t.innerHTML="✕";return}this.used.has(e.key)?(t.classList.add("used"),t.disabled=!0,t.title="Já importado anteriormente",t.innerHTML=L):(t.disabled=!1,t.classList.toggle("on",this.selected.has(e.key)),t.title=this.selected.has(e.key)?"Remover seleção":"Selecionar",t.innerHTML=this.selected.has(e.key)?L:R)}ensureBalloon(){if(this.balloon&&document.body.contains(this.balloon)){const t=this.readPosition();this.balloon.style.right=`${t.right}px`,this.balloon.style.top=`${t.top}px`,requestAnimationFrame(()=>{var n;return(n=this.balloon)==null?void 0:n.classList.add("open")});return}this.balloon=this.buildBalloon();const e=this.readPosition();this.balloon.style.right=`${e.right}px`,this.balloon.style.top=`${e.top}px`,document.body.appendChild(this.balloon),this.positionBalloon(),requestAnimationFrame(()=>{var t;return(t=this.balloon)==null?void 0:t.classList.add("open")})}minimizeBalloon(){if(!this.balloon||!this.headerEl)return;this.balloon.classList.remove("open"),this.balloon.style.display="none",this.balloon.dataset.minimized="true",(!this.floatBtn||!document.body.contains(this.floatBtn))&&(this.floatBtn=this.buildFloatBtn(),document.body.appendChild(this.floatBtn));const e=this.readPosition();this.floatBtn.style.right=`${e.right}px`,this.floatBtn.style.top=`${e.top}px`,requestAnimationFrame(()=>{var t;return(t=this.floatBtn)==null?void 0:t.classList.add("open")})}buildFloatBtn(){const e=document.createElement("button");return e.type="button",e.className="consecom-floatbtn",e.title="Abrir Vyntra",e.textContent="V",e.addEventListener("click",()=>{if(e.dataset.dragged==="true"){e.dataset.dragged="false";return}this.restoreBalloon()}),this.enableDrag(e,e),e}restoreBalloon(){this.balloon||(this.balloon=this.buildBalloon(),document.body.appendChild(this.balloon)),this.balloon.style.display="flex",this.balloon.dataset.minimized="false";const e=this.floatBtn?{right:parseFloat(this.floatBtn.style.right)||20,top:parseFloat(this.floatBtn.style.top)||20}:this.readPosition();this.balloon.style.right=`${e.right}px`,this.balloon.style.top=`${e.top}px`,this.clampElement(this.balloon),requestAnimationFrame(()=>{var t;return(t=this.balloon)==null?void 0:t.classList.add("open")}),this.floatBtn&&(this.floatBtn.classList.remove("open"),this.floatBtn.remove(),this.floatBtn=null),this.renderBalloonList()}readPosition(){const e=parseFloat(localStorage.getItem("consecom-float-right")||"20"),t=parseFloat(localStorage.getItem("consecom-float-top")||"20");return{right:Math.max(12,Number.isFinite(e)?e:20),top:Math.max(12,Number.isFinite(t)?t:20)}}savePosition(e){const t=parseFloat(e.style.right)||20,n=parseFloat(e.style.top)||20;localStorage.setItem("consecom-float-right",String(Math.max(12,t))),localStorage.setItem("consecom-float-top",String(Math.max(12,n)))}enableDrag(e,t){let a=!1,s=!1,r=0,i=0,l=0,p=0;const m=u=>{if(u.button!==0||a)return;const h=u.target;if(!(h&&h!==e&&h.closest("button, input, select, textarea, a, .cs-panel__controls, [data-no-drag]"))){u.preventDefault(),a=!0,s=!1,t.dataset.dragged="false",r=u.clientX,i=u.clientY,l=parseFloat(t.style.right)||20,p=parseFloat(t.style.top)||20;try{e.setPointerCapture(u.pointerId)}catch{}}},c=u=>{if(!a)return;const h=u.clientX-r,v=u.clientY-i;Math.abs(h)+Math.abs(v)>3&&(s=!0);const f=Math.max(0,window.innerWidth-12-t.offsetWidth),x=Math.max(0,window.innerHeight-12-t.offsetHeight),k=Math.min(Math.max(0,l-h),f),C=Math.min(Math.max(0,p+v),x);t.style.right=`${k}px`,t.style.top=`${C}px`,t.style.left="",t.style.bottom=""},d=u=>{if(a){a=!1;try{e.hasPointerCapture(u.pointerId)&&e.releasePointerCapture(u.pointerId)}catch{}s&&(t.dataset.dragged="true",this.savePosition(t))}};e.addEventListener("pointerdown",m),e.addEventListener("pointermove",c),e.addEventListener("pointerup",d),e.addEventListener("pointercancel",d),e.addEventListener("lostpointercapture",()=>{a=!1})}doMapsSearch(e){var n;const t=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]');if(t){const a=(n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:n.set;a==null||a.call(t,e),t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.focus(),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0}))}else this.lastQuery=e,this.selected.clear(),this.found=[],this.scan("force")}buildBalloon(){const e=document.createElement("aside");e.className="consecom-balloon";const t=document.createElement("div");t.className="cs-panel__header cs-panel__header--slim",this.headerEl=t;const n=document.createElement("div");n.className="cs-panel__grip",n.title="Arrastar painel",n.innerHTML="&#8942;&#8942;";const a=document.createElement("div");a.className="cs-panel__controls";const s=document.createElement("button");s.type="button",s.className="cs-panel__btn",s.title="Minimizar",s.innerHTML='<svg viewBox="0 0 24 24" width="12" height="12"><path fill="currentColor" d="M19 13h-4v4h-2v-4H5v-2h4V7h2v4h4z"/></svg>',s.addEventListener("click",g=>{g.stopPropagation(),this.minimizeBalloon()});const r=document.createElement("button");r.type="button",r.className="cs-panel__btn",r.title="Fechar",r.innerHTML='<svg viewBox="0 0 24 24" width="12" height="12"><path fill="currentColor" d="M18.3 5.71 12 12l6.3 6.29-1 1L12 14l-6.3 6.3-1-1L10.8 12 4.5 5.7l1-1L12 10.8l6.3-6.3z"/></svg>',r.addEventListener("click",g=>{g.stopPropagation(),this.toggleBalloon(!1)}),a.append(s,r),t.append(n,a),this.enableDrag(t,e);const i=document.createElement("div");i.className="cs-panel__body";const l=document.createElement("div");l.className="cs-sites";const p=[{key:"maps",label:"GOOGLE MAPS",active:!0},{key:"webmotors",label:"WEBMOTORS",active:!1},{key:"wepsy",label:"WEPSY",active:!1}];for(const g of p){const E=document.createElement("button");E.type="button",E.className="cs-site",E.dataset.site=g.key,E.textContent=g.label,g.active&&E.classList.add("cs-site--active"),l.appendChild(E)}const m=document.createElement("div");m.className="cs-search";const c=document.createElement("input");c.className="cs-search__input",c.type="text",c.placeholder="Ex.: Psicólogos em Sorocaba",c.spellcheck=!1,c.autocomplete="off";const d=()=>{const g=c.value.trim();g&&this.doMapsSearch(g)};c.addEventListener("keydown",g=>{g.key==="Enter"&&d()});const u=document.createElement("button");u.type="button",u.className="cs-search__btn",u.textContent="PESQUISAR",u.addEventListener("click",d);const h=document.createElement("div");h.className="cs-panel__loc",h.innerHTML=ke,this.locEl=document.createElement("span"),this.locEl.textContent="Aguardando busca…",h.append(this.locEl),m.append(c,u,h);const v=this.buildFiltersPanel();this.filtersPanel=v;const f=document.createElement("button");f.type="button",f.className="cs-prospect",f.textContent="PROSPECTAR",f.addEventListener("click",()=>void this.runProspect(f));const x=document.createElement("div");x.className="cs-result",x.style.display="none",this.resultPanel=x;const k=document.createElement("div");k.className="cs-leads";const C=document.createElement("div");C.className="cs-leads__title",C.textContent="AREA DE LEADS E SCROLL";const P=document.createElement("div");P.className="cs-panel__list",this.listEl=P,k.append(C,x,P),i.append(l,m,v,f,k);const B=document.createElement("div");B.className="cs-panel__footer";const A=document.createElement("div");A.className="cs-footer__count",this.countEl=A;const M=document.createElement("div");M.className="cs-footer__row";const _=document.createElement("button");_.type="button",_.className="cs-footer__btn cs-foot-delete",_.textContent="EXCLUIR",_.addEventListener("click",()=>void this.doDelete(_));const S=document.createElement("button");S.type="button",S.className="cs-footer__btn cs-foot-clear",S.textContent="LIMPAR",S.addEventListener("click",()=>void this.confirmClear()),M.append(_,S);const w=document.createElement("button");return w.type="button",w.className="cs-footer__btn cs-foot-import cs-import",w.textContent="IMPORTAR LEADS",w.addEventListener("click",()=>void this.doImport(w)),B.append(A,M,w),e.append(t,i,B),this.balloon=e,e}async runProspect(e){if(!this.prospecting){this.prospecting=!0,this.prospectCancel=!1,this.clearedSession=!1,e.disabled=!0;try{await this.runProspectStages(e),this.scan("force"),this.readFiltersFromPanel();const{matched:t,novoCount:n,existenteCount:a}=this.applyAutomaticSelection();this.renderResult(t,n,a),this.renderBalloonList()}catch(t){b(`Erro na prospecção: ${t}`,"warn")}finally{e.textContent="PROSPECTAR",e.disabled=!1,this.prospecting=!1}}}async runProspectStages(e){const t=[["Coletando resultados",320],["Aprofundando a busca",340],["Carregando mais empresas",360],["Calculando oportunidades",380]];for(const[n,a]of t){if(this.prospectCancel)break;const s=this.found.length;e.textContent=s>0?`PROSPECTANDO… ${s} resultados`:"PROSPECTANDO…",this.updateProspectProgress(),await this.scrollAndCollect(),await I(a),this.updateProspectProgress()}}async scrollAndCollect(){const e=Array.from(document.querySelectorAll(O()));if(e.length===0)return;const t=D(e[0]),n=t?pe(t):null;if(!n)return;const a=this.found.length,s=Math.min(600,n.offsetHeight||400);n.scrollBy({top:s,behavior:"smooth"}),await I(340),this.scan("force"),this.found.length===a&&(n.scrollBy({top:s,behavior:"smooth"}),await I(340),this.scan("force"))}updateProspectProgress(){if(!this.resultPanel)return;const e=this.found.length,t=document.createElement("div");t.className="cs-result__progress",t.textContent=`Coletados: ${e}`,this.resultPanel.replaceChildren(t),this.resultPanel.style.display="block"}applyAutomaticSelection(){const t=this.found.filter(a=>!this.used.has(a.key)&&!this.noInterest.has(a.key)).filter(a=>F(a.lead,this.filters));this.lastMatched=t,this.selected.clear();for(const a of t)this.selected.add(a.key);const n=this.found.filter(a=>this.used.has(a.key)&&F(a.lead,this.filters));return{matched:t,novoCount:t.length,existenteCount:n.length}}buildFiltersPanel(){const e=document.createElement("div");e.className="cs-filters";const t=document.createElement("div");t.className="cs-filters__title",t.textContent="Encontrar oportunidades",e.appendChild(t);const n=document.createElement("div");n.className="cs-chips";for(const c of ne){const d=document.createElement("button");d.type="button",d.className="cs-chip",d.dataset.id=c.id,d.dataset.cat=c.cat,d.dataset.value=c.value,d.dataset.accent=c.accent??"#059669",d.textContent=c.label,d.addEventListener("click",()=>{this.filters.activeChips.has(c.id)?this.filters.activeChips.delete(c.id):this.filters.activeChips.add(c.id),d.classList.toggle("cs-chip--on"),this.syncChipsFromState(d,c.accent)}),this.syncChipsFromState(d,c.accent),n.appendChild(d)}e.appendChild(n);const a=document.createElement("div");a.className="cs-adv";const s=document.createElement("label");s.className="cs-adv__item";const r=document.createElement("span");r.textContent="Nota mín.";const i=document.createElement("select");i.dataset.cat="minRating";for(const c of[0,4,4.5,4.8]){const d=document.createElement("option");d.value=String(c),d.textContent=c===0?"Qualquer":`${c.toFixed(1)}+`,i.appendChild(d)}s.append(r,i);const l=document.createElement("label");l.className="cs-adv__item";const p=document.createElement("span");p.textContent="Avaliações mín.";const m=document.createElement("select");m.dataset.cat="minReviews";for(const c of[0,10,50,100,500]){const d=document.createElement("option");d.value=String(c),d.textContent=c===0?"Qualquer":`${c}+`,m.appendChild(d)}return l.append(p,m),a.append(s,l),e.appendChild(a),e.appendChild(this.buildServiceGroup()),e}syncChipsFromState(e,t){e.classList.contains("cs-chip--on")?(e.style.borderColor=t??"#059669",e.style.background=`${t??"#059669"}22`,e.style.color="#fff"):(e.style.borderColor="",e.style.background="",e.style.color="")}buildServiceGroup(){const e=document.createElement("div");e.className="cs-fgroup cs-fgroup--svc";const t=document.createElement("div");t.className="cs-fgroup__h",t.textContent="SERVIÇO / NECESSIDADE",e.appendChild(t);const n=document.createElement("div");n.className="cs-radio";const a=[{id:"todos",label:"Todos"},{id:"site",label:"Site"},{id:"sistema",label:"Sistema"},{id:"trafego",label:"Tráfego pago"},{id:"automacao",label:"Automação"},{id:"presenca",label:"Presença digital"}];for(const s of a){const r=document.createElement("label");r.className="cs-radio__item";const i=document.createElement("input");i.type="radio",i.name="cs-service",i.value=s.id,i.dataset.cat="service",s.id==="todos"&&(i.checked=!0);const l=document.createElement("span");l.textContent=s.label,r.append(i,l),n.appendChild(r)}return e.appendChild(n),e}readFiltersFromPanel(){if(!this.filtersPanel)return;const e=[],t=[],n=[],a=[];this.filtersPanel.querySelectorAll(".cs-chip.cs-chip--on").forEach(c=>{const d=c.dataset.cat,u=c.dataset.value;!d||!u||(d==="site"?e.push(u):d==="digital"?t.push(u):d==="score"?a.push(u):d==="qualify"&&n.push(u))});let s=null,r=null;const i=this.filtersPanel.querySelector("select[data-cat=minRating]");i&&(s=parseFloat(i.value)||null);const l=this.filtersPanel.querySelector("select[data-cat=minReviews]");l&&(r=parseInt(l.value,10)||null);let p="todos";const m=this.filtersPanel.querySelector("input[name=cs-service]:checked");m&&(p=m.value),this.filters={site:e,digital:t,qualify:n,minRating:s,minReviews:r,scoreBands:a,service:p,activeChips:this.filters.activeChips}}renderResult(e,t,n){if(!this.resultPanel)return;const a=this.found.length,s=document.createElement("div");s.className="cs-result__card";const r=document.createElement("div");r.className="cs-result__head";const i=document.createElement("div");i.className="cs-result__big",i.textContent=`${t}`;const l=document.createElement("div");l.className="cs-result__sub",l.textContent=t===1?"oportunidade encontrada":"oportunidades encontradas",r.append(i,l),s.appendChild(r);const p=document.createElement("div");p.className="cs-result__stats";const m=document.createElement("div");m.innerHTML=`<span>${a}</span> analisadas`;const c=document.createElement("div");if(c.innerHTML=`<span>${t}</span> selecionadas automaticamente`,p.append(m,c),n>0){const d=document.createElement("div");d.className="cs-result__dup",d.innerHTML=`⚠ ${n} já existem na Vyntra`,p.appendChild(d)}if(s.appendChild(p),e.length>0){const d=this.buildAlexHint(e);s.appendChild(d)}if(t>0){const d=document.createElement("button");d.type="button",d.className="cs-result__cta";const u=n>0?`${t} NOVOS`:`${t} LEADS`;d.textContent=n>0?`IMPORTAR ${t} NOVOS`:`IMPORTAR ${t} LEADS`,d.addEventListener("click",()=>void this.doProspectImport(d,e,u)),s.appendChild(d)}else{const d=document.createElement("div");d.className="cs-result__empty",d.textContent="Nenhuma empresa corresponde aos critérios. Ajuste os filtros e tente novamente.",s.appendChild(d)}this.resultPanel.replaceChildren(s),this.resultPanel.style.display="block"}buildAlexHint(e){const t=document.createElement("div");t.className="cs-alex";const n=document.createElement("div");n.className="cs-alex__avatar",n.textContent="🤖";const a=document.createElement("div");a.className="cs-alex__body";const s=document.createElement("div");s.className="cs-alex__name",s.textContent="Alex";const r=document.createElement("div");r.className="cs-alex__msg";const i=e.filter(m=>z(m.lead).band==="alta").length,p=e.filter(m=>!m.lead.website).length>=e.length/2?"sem site ou com presença digital fraca":"com boa avaliação e presença consolidada";return r.textContent=`Encontrei ${e.length} empresas que parecem boas oportunidades para prospecção.`+(i>0?` ${i} delas possuem alta oportunidade.`:"")+` A maior oportunidade está em empresas ${p}.`,a.append(s,r),t.append(n,a),t}async doProspectImport(e,t,n){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const a=t.map(r=>r.lead).slice(0,50);if(a.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const s=e.textContent;e.disabled=!0;try{const r=["Google Maps"],i=this.filters.service!=="todos"?`Interesse: ${this.serviceLabel(this.filters.service)}`:null,p={source:"google_maps",sourceDetail:"vyntra_prospector",tags:i?[...r,i]:r,prospectFilters:this.filtersToSnapshot(),prospectedAt:new Date().toISOString()};let m=0;const c=await $(this.cfg,a,(d,u)=>{m=d;const h=Math.round(d/u*100);e.textContent=`Importando… ${h}%`},p);console.log("[IMPORT] Resultado completo:",{ok:c.ok,failed:c.failed,firstError:c.firstError,errors:c.errors}),this.renderProspectReport({analyzed:this.found.length,opportunities:t.length,imported:c.ok,failed:c.failed,alreadyExists:this.countAlreadyExists(t),filtersText:ie(this.filters)}),e.textContent=c.failed===0?`✓ ${c.ok} LEADS IMPORTADOS`:`${c.ok} ok, ${c.failed} falharam`,c.failed===0?(b(`✅ ${c.ok} lead(s) importado(s)!`),this.selected.clear()):b(`⚠️ ${c.ok} ok, ${c.failed} falharam${c.firstError?`: ${c.firstError}`:""}`,"warn"),this.checkUsed(),this.syncAll()}catch(r){e.textContent=`Erro: ${r}`,b(`Erro ao importar: ${r}`,"warn")}finally{setTimeout(()=>{e.textContent=s,e.disabled=!1},4e3)}}countAlreadyExists(e){return e.filter(t=>this.used.has(t.key)).length}serviceLabel(e){return{todos:"Todos",site:"Site",sistema:"Sistema",trafego:"Tráfego pago",automacao:"Automação",presenca:"Presença digital"}[e]}filtersToSnapshot(){return{site:this.filters.site,digital:this.filters.digital,minRating:this.filters.minRating,minReviews:this.filters.minReviews,scoreBands:this.filters.scoreBands,service:this.filters.service,query:this.lastQuery,at:new Date().toISOString()}}renderProspectReport(e){if(!this.resultPanel)return;const t=document.createElement("div");t.className="cs-result__card cs-result__report";const n=document.createElement("div");n.className="cs-result__head cs-result__head--ok";const a=document.createElement("div");a.className="cs-result__title",a.textContent="PROSPECÇÃO CONCLUÍDA",n.appendChild(a),t.appendChild(n);const s=[`${e.analyzed} empresas analisadas`,`${e.opportunities} oportunidades encontradas`,`${e.imported} novos leads importados`,e.failed>0?`${e.failed} com erro`:null,e.alreadyExists>0?`${e.alreadyExists} já estavam na Vyntra`:null].filter(Boolean),r=document.createElement("ul");r.className="cs-result__lines";for(const l of s){const p=document.createElement("li");p.textContent=l,r.appendChild(p)}if(t.appendChild(r),e.filtersText.length>0){const l=document.createElement("div");l.className="cs-result__crit",l.innerHTML='<div class="cs-result__crit-h">Critérios:</div>';const p=document.createElement("div");p.className="cs-result__tags";for(const m of e.filtersText){const c=document.createElement("span");c.className="cs-result__chip",c.textContent=`✓ ${m}`,p.appendChild(c)}l.appendChild(p),t.appendChild(l)}const i=document.createElement("button");i.type="button",i.className="cs-result__cta cs-result__cta--ghost",i.textContent="VER LEADS",i.addEventListener("click",()=>this.renderBalloonList()),t.appendChild(i),this.resultPanel.replaceChildren(t),this.resultPanel.style.display="block"}doProspect(e){this.runProspect(e)}renderBalloonList(){!this.balloon||!this.listEl||(this.updateCounts(),this.renderCardList())}renderCardList(){if(!this.listEl)return;if(this.found.length===0){this.listEl.innerHTML="";const t=document.createElement("div");t.className="cs-empty",this.clearedSession?t.innerHTML='<span class="cs-empty__icon">✓</span><b>0 leads capturados</b> · <b>0 leads selecionados</b><br/>Sessão limpa. Inicie uma nova busca e toque em PROSPECTAR para capturar novamente.':t.innerHTML="<b>0 leads capturados</b> · <b>0 leads selecionados</b><br/>Rode a busca no Google Maps e toque em PROSPECTAR para listar as empresas.",this.listEl.appendChild(t);return}const e=document.createDocumentFragment();for(const t of this.found)e.appendChild(this.buildCard(t));this.listEl.replaceChildren(e)}buildCard(e){const t=document.createElement("div");t.className="cs-pcard",t.dataset.key=e.key;const n=z(e.lead),a=document.createElement("div");a.className="cs-pcard__top";const s=document.createElement("div");s.className="cs-pcard__name",s.textContent=e.lead.name,s.title=e.lead.name;const r=document.createElement("div");r.className="cs-pcard__badge "+te(n.band),r.textContent=n.label,a.append(s,r);const i=document.createElement("div");i.className="cs-pcard__meta";const l=[];if(e.lead.address){const f=document.createElement("span");f.textContent=e.lead.address.split(",")[0],l.push(f)}if(e.lead.phone){const f=document.createElement("span");f.textContent=e.lead.phone,l.push(f)}if(e.lead.rating!=null){const f=document.createElement("span");f.className="cs-pcard__rating",f.innerHTML=Ee+e.lead.rating.toFixed(1),l.push(f)}for(let f=0;f<l.length;f++)f>0&&i.appendChild(document.createTextNode(" • ")),i.appendChild(l[f]);l.length===0&&(i.textContent="—");const p=document.createElement("div");p.className="cs-pcard__scorebar";const m=document.createElement("div");m.className="cs-pcard__bar";const c=document.createElement("div");c.className="cs-pcard__barfill",c.style.width=`${n.total}%`,m.appendChild(c);const d=document.createElement("div");d.className="cs-pcard__score",d.innerHTML=`${n.total}<small>/100</small>`,p.append(m,d);const u=document.createElement("div");u.className="cs-pcard__actions";const h=document.createElement("button");h.type="button",h.className="cs-pcard__btn cs-pcard__lead",h.innerHTML=(this.selected.has(e.key)?L:R)+'<span data-role="lead-label">Lead</span>',h.addEventListener("click",()=>{this.used.has(e.key)||this.noInterest.has(e.key)||this.toggleControl(e.key)});const v=document.createElement("button");return v.type="button",v.className="cs-pcard__btn cs-pcard__site",v.title="Abrir site",v.innerHTML=H,e.lead.website?v.addEventListener("click",f=>{f.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):v.disabled=!0,u.append(h,v),t.append(a,i,p,u),this.updateCard(t,e),t}updateCard(e,t){const n=e.querySelector(".cs-pcard__lead");if(!n)return;const a=n.querySelector('[data-role="lead-label"]');if(this.noInterest.has(t.key)){n.classList.add("nointerest"),n.disabled=!0,a&&(a.textContent="Sem interesse");return}if(this.used.has(t.key)){n.classList.add("used"),n.disabled=!0,a&&(a.textContent="Importado");return}n.classList.toggle("on",this.selected.has(t.key)),n.innerHTML=(this.selected.has(t.key)?L:R)+'<span data-role="lead-label">Lead</span>'}syncAll(){this.updateCounts(),this.renderControls(),this.renderBalloonList()}updateCounts(){if(!this.listEl)return;if(this.listEl.querySelectorAll(".cs-pcard").forEach(t=>{const n=t.dataset.key,a=n?this.found.find(s=>s.key===n):void 0;a&&this.updateCard(t,a)}),this.countEl){const t=this.found.length,n=this.selected.size;this.countEl.innerHTML=`<b>${t}</b> capturados · <b>${n}</b> selecionados`}}toggleBalloon(e){var n;if(e&&this.floatBtn){this.restoreBalloon();return}const t=e??!((n=this.balloon)!=null&&n.classList.contains("open"));if(!this.balloon||!document.body.contains(this.balloon)){t&&this.ensureBalloon();return}this.balloon.classList.toggle("open",t),t?this.renderBalloonList():this.ensureLauncher()}clampElement(e){if(!document.body.contains(e))return;const t=12,n=e.offsetWidth||0,a=e.offsetHeight||0,s=Math.max(0,window.innerWidth-t-n),r=Math.max(0,window.innerHeight-t-a),i=parseFloat(e.style.right),l=parseFloat(e.style.top);if(!Number.isFinite(i)||!Number.isFinite(l))return;const p=Math.min(Math.max(0,i),s),m=Math.min(Math.max(0,l),r);(p!==i||m!==l)&&(e.style.right=`${p}px`,e.style.top=`${m}px`,e.style.left="",e.style.bottom="",this.savePosition(e))}positionBalloon(){if(!this.balloon)return;const e=this.readPosition();this.balloon.style.right=`${Math.max(12,e.right)}px`,this.balloon.style.top=`${Math.max(12,e.top)}px`,this.clampElement(this.balloon)}refreshCards(){if(this.clearedSession)return;const e=document.querySelectorAll(O()),t=new Set;for(const n of Array.from(e)){const a=D(n),s=n.href,r=ue(n,a);if(!r)continue;const i=de(s),l=i||s;if(!i&&!s||t.has(l))continue;t.add(l);const p=this.found.find(m=>m.key===l);if(p){p.host=p.host&&document.body.contains(p.host)?p.host:a,p.lead.name=r;continue}this.found.push({lead:this.parseCard(a,r,s,i),host:a,key:l,control:null})}this.checkUsed()}async checkUsed(){const e=this.cfg??await y();if(!e.extensionKey||!e.ownerUserId)return;const t=this.found.map(n=>n.lead.place_id).filter(n=>!!n);if(t.length!==0)try{const n=await V(e,t);this.used=new Set(n.used);const a=Date.now();this.noInterest=new Set(Object.entries(n.noInterest).filter(([,s])=>s&&new Date(s).getTime()>a).map(([s])=>s)),this.syncAll()}catch{}}prune(){this.found=this.found.filter(e=>e.host&&document.body.contains(e.host))}parseCard(e,t,n,a){const s=((e==null?void 0:e.innerText)||"")??"",r=n.match(/!3d([-\d.]+)!4d([-\d.]+)/);return{name:t,phone:me(e,s),category:fe(s,t),website:he(e),address:ve(e),city:null,state:null,rating:ye(s),reviews:xe(s),latitude:r?parseFloat(r[1]):null,longitude:r?parseFloat(r[2]):null,place_id:a,instagram:ge(e),facebook:be(e)}}async promptConfig(){const e=this.cfg??await y();alert(e.extensionKey&&e.ownerUserId?"Extensão vinculada à sua conta Vyntra ✓":"Esta extensão não está vinculada a uma conta. Baixe novamente a extensão no painel Vyntra.")}async doImport(e){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const t=this.found.filter(a=>!this.used.has(a.key)&&this.selected.has(a.key)).map(a=>a.lead).slice(0,50);if(t.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const n=e.innerHTML;e.disabled=!0,e.textContent="Importando…";try{let a=0;const s=await $(this.cfg,t,(r,i)=>{a=r,e.textContent=`${r}/${i}…`});console.log("[IMPORT] Resultado completo:",{ok:s.ok,failed:s.failed,firstError:s.firstError,errors:s.errors}),e.textContent=s.failed===0?"✓":`${s.ok} ok, ${s.failed} falharam`,s.failed===0?(b(s.ok>0?`✅ ${s.ok} lead(s) importado(s)!`:"Nenhum lead novo para importar."),this.selected.clear()):b(`⚠️ ${s.ok} ok, ${s.failed} falharam${s.firstError?`: ${s.firstError}`:""}`,"warn"),this.checkUsed(),this.syncAll(),setTimeout(()=>{e.innerHTML=n,e.disabled=!1},2e3)}catch(a){e.textContent=`Erro: ${a}`,setTimeout(()=>{e.innerHTML=n,e.disabled=!1},3e3)}}async doDelete(e){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const t=this.found.filter(a=>this.selected.has(a.key)&&a.lead.place_id).map(a=>a.lead.place_id);if(t.length===0){alert("Selecione pelo menos um lead para excluir.");return}if(!confirm(`Excluir ${t.length} lead(s) do banco?`))return;const n=e.innerHTML;e.disabled=!0,e.innerHTML="Excluindo…";try{const a=await U(this.cfg,t);if(a.failed===0){b(`🗑️ ${a.ok} lead(s) excluído(s)!`);for(const s of t)this.used.delete(s);this.selected.clear()}else b(`⚠️ ${a.ok} ok, ${a.failed} falharam ao excluir`,"warn");this.checkUsed(),this.syncAll()}catch(a){b(`Erro ao excluir: ${a}`,"warn")}finally{e.innerHTML=n,e.disabled=!1}}confirmClear(){return new Promise(e=>{const t=document.createElement("div");t.className="cs-modal";const n=document.createElement("div");n.className="cs-modal__card";const a=document.createElement("div");a.className="cs-modal__title",a.textContent="Limpar leads capturados";const s=document.createElement("div");s.className="cs-modal__text",s.textContent="Tem certeza que deseja remover todos os leads capturados desta sessão? Leads já importados para o VYNTRA não serão afetados.";const r=document.createElement("div");r.className="cs-modal__actions";const i=document.createElement("button");i.type="button",i.className="cs-modal__btn cs-modal__btn--ghost",i.textContent="Cancelar",i.addEventListener("click",()=>{t.remove(),e()});const l=document.createElement("button");l.type="button",l.className="cs-modal__btn cs-modal__btn--danger",l.textContent="Limpar leads",l.addEventListener("click",()=>{t.remove(),this.clearLocal(),e()}),r.append(i,l),n.append(a,s,r),t.append(n),document.body.appendChild(t),requestAnimationFrame(()=>t.classList.add("cs-open"))})}clearLocal(){this.clearedSession=!0,this.found=[],this.selected.clear(),this.lastMatched=[],this.resultPanel&&(this.resultPanel.style.display="none"),this.syncAll(),b("✓ Leads removidos")}}const W=()=>{const o=window.location.hostname,e=window.location.href,t=/(^|\.)google\.(com|com\.br|[a-z.]+)\/maps\//.test(e)||o.startsWith("maps.google");!t&&!(()=>{const a=o.toLowerCase();return!!(/(^|\.)wepsy\.com\.br$/.test(a)||/(^|\.)webmotors\.com\.br$/.test(a))})()||(typeof document<"u"&&T(async()=>{const{detectWelcomeSite:a,showWelcome:s}=await import("./welcome-Bio4P_8f.js");return{detectWelcomeSite:a,showWelcome:s}},[]).then(({detectWelcomeSite:a,showWelcome:s})=>{const r=a(o,e);r&&r!=="global"&&s(r)}),T(()=>Promise.resolve().then(()=>J),void 0).then(async({getExtensionSites:a})=>{const s=await a();if(t){if(s.maps===!1)return;new le().init()}else T(async()=>{const{GlobalScanner:r}=await import("./global-WbbZDocz.js");return{GlobalScanner:r}},__vite__mapDeps([0,1])).then(({GlobalScanner:r})=>{new r().init()})}))};typeof window<"u"&&W();function Le(){W()}function O(){return'a[href*="/maps/place/"]'}function de(o){const e=o.match(/(?:^|[?&])place_id=([^&]+)/);return e?decodeURIComponent(e[1]):null}function D(o){let e=o.parentElement;for(let t=0;t<9&&e&&e.tagName!=="BODY"&&e.getAttribute("role")!=="feed";t++){if(e.getAttribute("role")==="article"||e.querySelector('span[aria-label*="stars"], span[aria-label*="avalia"], span[aria-label*="estrela"]')||e.querySelector('a[href*="/maps/place/"]'))return e;e=e.parentElement}return o.closest('div[role="article"], [role="article"]')??o}function pe(o){let e=o.parentElement;for(;e&&e.tagName!=="BODY"&&e.tagName!=="HTML";){const t=getComputedStyle(e);if(["auto","scroll"].includes(t.overflowY)||t.overflowY==="clip"&&["auto","scroll"].includes(t.overflow))return e;e=e.parentElement}return document.scrollingElement}function ue(o,e){const n=(o.textContent||"").split(/\s+/).filter(Boolean);if(n.length>0&&n.length<14)return n.slice(0,6).join(" ");const a=o.querySelector('h3, [role="heading"], [style*="font"]'),s=((a==null?void 0:a.textContent)||"").trim();return s?s.split(`
`)[0]:e&&(e.textContent||"").trim().split(`
`)[0]||null}function me(o,e){const t=o==null?void 0:o.querySelector('a[href^="tel:"]');if(t)return t.href.replace("tel:","").trim();const n=e.match(/\(\d{2,3}\)\s?\d[\d\s-]{7,}/);return n?n[0].replace(/\s+/g," ").trim():null}function fe(o,e){for(const t of o.split(`
`)){const n=t.trim();if(n&&n!==e&&n.length<40&&!/\d/.test(n)&&!n.startsWith("★")&&!/^\d/.test(n))return n}return null}function he(o){if(!o)return null;const e=['a[data-tooltip="Abrir site"]','a[data-tooltip="Website"]','a[aria-label*="Abrir site"]','a[href]:not([href^="tel:"]):not([href*="/maps/place/"]):not([href^="http://www.google.com/maps"])'];for(const a of e){const s=o.querySelector(a),r=s==null?void 0:s.href;if(r&&r.startsWith("http"))return r.split("&place_id")[0]}const t=o.querySelector('a[href^="http"]'),n=t==null?void 0:t.href;return n&&n.startsWith("http")&&!n.includes("/maps/place/")?n.split("&")[0]:null}function ve(o){var t;const e=o==null?void 0:o.querySelector('button[data-tooltip="Endereço"], div[class*="address"], span[data-type="address"]');return((t=e==null?void 0:e.textContent)==null?void 0:t.trim())||null}function ge(o){if(!o)return null;const e=['a[data-tooltip*="Instagram" i]','a[aria-label*="Instagram" i]','a[href*="instagram.com/"]','a[href*="instagram.com"]'];for(const a of e){const s=o.querySelector(a),r=s==null?void 0:s.href;if(r&&/instagram\.com/i.test(r))return j(r)}const n=(o.innerText||"").match(/instagram\.com\/[A-Za-z0-9_.\-]+/i);return n?`https://www.${n[0].toLowerCase()}`:null}function be(o){if(!o)return null;const e=['a[data-tooltip*="Facebook" i]','a[aria-label*="Facebook" i]','a[href*="facebook.com/"]','a[href*="fb.com/"]'];for(const t of e){const n=o.querySelector(t),a=n==null?void 0:n.href;if(a&&/facebook\.com|fb\.com/i.test(a))return j(a)}return null}function j(o){try{const e=new URL(o);return`${e.protocol}//${e.host}${e.pathname.replace(/\/$/,"")}`}catch{return o.split("?")[0]}}function ye(o){const e=o.match(/([\d.]+)[\s]*[★✩]/);return e?parseFloat(e[1]):null}function xe(o){const e=o.match(/\(([\d.,]+)\)/);return e?parseInt(e[1].replace(/[^\d]/g,""),10):null}function _e(){if(document.getElementById("consecom-css"))return;const o=document.createElement("style");o.id="consecom-css",o.textContent=ce,document.head.appendChild(o)}function b(o,e="ok"){var a;const t="consecom-toast";(a=document.getElementById(t))==null||a.remove();const n=document.createElement("div");n.id=t,n.className="consecom-toast"+(e==="warn"?" cs-warn":""),n.textContent=o,document.body.appendChild(n),window.setTimeout(()=>{n.classList.add("cs-show")},20),window.setTimeout(()=>n.remove(),4e3)}function I(o){return new Promise(e=>window.setTimeout(e,o))}const we='<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z"/></svg>',H='<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm2.5 16c-.8 1.3-1.6 2-2.5 2s-1.7-.7-2.5-2c-.7-1.2-1.2-2.8-1.4-4.5h7.8c-.2 1.7-.7 3.3-1.4 4.5zM7.8 11.5c.2-1.7.7-3.3 1.4-4.5.8-1.3 1.6-2 2.5-2s1.7.7 2.5 2c.7 1.2 1.2 2.8 1.4 4.5H7.8zM12 4c.5.7.9 1.6 1.2 2.6h-2.4C10.6 5.6 11.2 4.6 12 4zm-3.1 7c-.1.5-.1 1 0 1.5H5.9a8 8 0 0 1 0-3h3c-.1.5-.1 1 0 1.5zm-1.6 3h3c.1 1.5.4 2.9.9 4-.9-.4-1.6-.9-2.3-1.6-.5-.6-1-1.5-1.6-2.4zM15.1 17c.7.7 1.4 1.2 2.3 1.6-.5-1.1-.8-2.5-.9-4h3a8 8 0 0 1-.9 3c-.5.5-1 .9-1.6 1.2-.6.3-1.3.5-1.9.6v-2.4zm3.6-4.5h-3.1c0-.5 0-1 .1-1.5h3a8 8 0 0 1 0 3h-3c0-.5-.1-1-.1-1.5zM7.1 7c-.7-.7-1.4-1.2-2.3-1.6.5 1.1.8 2.5.9 4h-3a8 8 0 0 1 .9-3c.5-.5 1-.9 1.6-1.2.6-.3 1.3-.5 1.9-.6V7zm0 1.5v2.4c.5 0 1 .1 1.5.1h1.6c-.1-1.4-.4-2.7-.9-3.8-.7.3-1.4.8-2.2 1.3zM12 20c-.5-.7-.9-1.6-1.2-2.6h2.4c-.3 1-.9 1.9-1.2 2.6z"/></svg>',L='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',R='<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',Ee='<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.9-5 4.7 1.3 6.8L12 17.8 5.9 20.7l1.3-6.8-5-4.7 6.9-.9z"/></svg>',ke='<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>';export{le as M,X as a,$ as b,I as c,Le as d,K as g,_e as i,Se as r,b as s};
