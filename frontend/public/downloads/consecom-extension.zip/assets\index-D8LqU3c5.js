const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/global-B7KyeZEN.js","assets/config-SYaVBN7W.js"])))=>i.map(i=>d[i]);
import{g as x}from"./config-SYaVBN7W.js";const j="modulepreload",G=function(s){return"/"+s},q={},K=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const o=document.querySelector("meta[property=csp-nonce]"),i=(o==null?void 0:o.nonce)||(o==null?void 0:o.getAttribute("nonce"));r=Promise.allSettled(t.map(d=>{if(d=G(d),d in q)return;q[d]=!0;const p=d.endsWith(".css"),u=p?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${d}"]${u}`))return;const c=document.createElement("link");if(c.rel=p?"stylesheet":j,p||(c.as="script"),c.crossOrigin="",c.href=d,i&&c.setAttribute("nonce",i),document.head.appendChild(c),p)return new Promise((l,m)=>{c.addEventListener("load",l),c.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${d}`)))})}))}function a(o){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=o,window.dispatchEvent(i),!i.defaultPrevented)throw o}return r.then(o=>{for(const i of o||[])i.status==="rejected"&&a(i.reason);return e().catch(a)})};async function $(s,e,t={}){const n=await x(),r=await chrome.runtime.sendMessage({type:"consecom:api",path:s,method:"POST",headers:t,body:e,extensionKey:n.extensionKey});return(r==null?void 0:r.ok)===!1&&(r==null?void 0:r.status)===403?{ok:!1,status:403,data:{message:"Extensão não vinculada. Baixe novamente a extensão no painel Vyntra."}}:r??{ok:!1,status:0,data:{message:"Sem resposta do background."}}}async function Q(s,e){if(e.length===0)return{ok:0,failed:0};const t=await $("/api/extension/delete",{placeIds:e,ownerUserId:s.ownerUserId});if(!t.ok)return{ok:0,failed:e.length};const n=t.data??{};return{ok:Number(n.ok??0),failed:Number(n.failed??0)}}async function F(s,e,t,n){var p,u,c;if(!s.extensionKey||!s.ownerUserId)return{ok:0,failed:e.length,firstError:"Extensão não vinculada a uma conta Vyntra. Baixe novamente a extensão no painel.",errors:[]};const r=e.map(l=>({name:l.name,phone:l.phone??"",category:l.category,website:l.website,address:l.address,city:l.city,state:l.state,rating:l.rating,reviews:l.reviews,latitude:l.latitude,longitude:l.longitude,place_id:l.place_id,instagram:l.instagram,facebook:l.facebook})),a=await $("/api/extension/import-leads",{ownerUserId:s.ownerUserId,leads:r,listName:`Importação ${new Date().toISOString().slice(0,10)}`,source:(n==null?void 0:n.source)??"google_maps",sourceDetail:(n==null?void 0:n.sourceDetail)??"vyntra_prospector",tags:n==null?void 0:n.tags,prospectFilters:n==null?void 0:n.prospectFilters,score:n==null?void 0:n.score,serviceInterest:n==null?void 0:n.serviceInterest,prospectedAt:(n==null?void 0:n.prospectedAt)??new Date().toISOString()});if(!a.ok){const l=a.data??{},m=l.message??l.error??`HTTP ${a.status}`;return console.error("[IMPORT] Backend import failed:",{status:a.status,message:m}),{ok:0,failed:e.length,firstError:m,errors:[]}}const o=a.data??{},i=Number(((p=o.summary)==null?void 0:p.created)??0),d=Number(((u=o.summary)==null?void 0:u.errors)??0);return console.log("[IMPORT] Backend import response:",{status:a.status,ok:i,failed:d}),e.forEach((l,m)=>t==null?void 0:t(m+1,e.length)),{ok:i,failed:d,firstError:typeof((c=o.firstError)==null?void 0:c.body)=="string"?o.firstError.body:void 0,errors:[]}}async function X(s,e){if(e.length===0)return{used:[],noInterest:{}};const t=await $("/api/extension/known",{placeIds:e});if(!t.ok)return{used:[],noInterest:{}};const n=t.data??{};return{used:Array.isArray(n.used)?n.used:[],noInterest:n.noInterest??{}}}function A(s){let e=0;s.rating!=null&&s.rating>0&&(e=Math.min(45,Math.round(s.rating/5*45)));let t=0;s.reviews!=null&&s.reviews>0&&(t=Math.min(30,Math.round(Math.log10(s.reviews+1)/Math.log10(1e4)*30)));const n=s.website?10:0,r=s.phone?10:0,a=s.category?5:0,o=Math.max(0,Math.min(100,e+t+n+r+a)),i=Z(o);return{total:o,band:i,label:J[i],parts:{rating:e,reviews:t,website:n,phone:r,category:a}}}const J={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Oportunidade média",baixa:"Baixa oportunidade",nenhuma:"Sem dados"};function Z(s){return s>=90?"alta":s>=70?"boa":s>=50?"media":s>=1?"baixa":"nenhuma"}function ee(s){return"cs-band-"+s}const te=[{id:"sem_site",label:"Sem site",cat:"site",value:"sem_site",accent:"#f87171"},{id:"alta",label:"Alta oportunidade",cat:"score",value:"alta",accent:"#10b981"},{id:"site_ruim",label:"Site ruim",cat:"site",value:"site_ruim",accent:"#f59e0b"},{id:"poucas_avaliacoes",label:"Poucas avaliações",cat:"qualify",value:"poucas_avaliacoes",accent:"#a855f7"},{id:"nota_baixa",label:"Nota baixa",cat:"qualify",value:"nota_baixa",accent:"#f87171"},{id:"sem_presenca_digital",label:"Sem presença digital",cat:"digital",value:"sem_presenca_digital",accent:"#64748b"},{id:"tem_telefone",label:"Tem telefone",cat:"qualify",value:"tem_telefone",accent:"#22c55e"},{id:"sem_instagram",label:"Sem Instagram",cat:"digital",value:"sem_instagram",accent:"#ec4899"},{id:"sem_whatsapp",label:"Sem WhatsApp",cat:"digital",value:"sem_whatsapp",accent:"#f87171"},{id:"tem_whatsapp",label:"Tem WhatsApp",cat:"digital",value:"tem_whatsapp",accent:"#22c55e"},{id:"tem_site",label:"Tem site",cat:"site",value:"site_bom",accent:"#22c55e"},{id:"boa",label:"Boa oportunidade",cat:"score",value:"boa",accent:"#84cc16"},{id:"media",label:"Média oportunidade",cat:"score",value:"media",accent:"#f59e0b"},{id:"baixa",label:"Baixa oportunidade",cat:"score",value:"baixa",accent:"#f87171"}],ne={site:[],digital:[],qualify:[],minRating:null,minReviews:null,scoreBands:[],service:"todos",activeChips:new Set};function H(s,e){if(e.site.length>0&&!re(s,e.site)||e.digital.length>0&&!ae(s,e.digital)||e.qualify.length>0&&!se(s,e.qualify)||e.minRating!=null&&e.minRating>0&&(s.rating==null||s.rating<e.minRating)||e.minReviews!=null&&e.minReviews>0&&(s.reviews==null||s.reviews<e.minReviews))return!1;if(e.scoreBands.length>0){const t=A(s);if(t.band==="nenhuma"||!e.scoreBands.includes(t.band))return!1}return!0}function re(s,e){const t=!!s.website;for(const n of e)switch(n){case"sem_site":if(!t)return!0;break;case"site_bom":case"site_profissional":case"site_ruim":case"site_desatualizado":case"site_nao_responsivo":case"site_lento":case"site_amador":case"site_quebrado":case"site_problemas":if(t)return!0;break}return!1}function ae(s,e){const t=!!s.instagram,n=!!s.facebook,r=!!s.phone;for(const a of e)switch(a){case"sem_instagram":if(!t)return!0;break;case"instagram_encontrado":if(t)return!0;break;case"sem_facebook":if(!n)return!0;break;case"sem_presenca_digital":if(!t&&!n&&!r)return!0;break;case"sem_whatsapp":if(!r)return!0;break;case"tem_whatsapp":if(r)return!0;break;case"instagram_pouco_ativo":case"instagram_sem_link_site":if(t)return!0;break}return!1}function se(s,e){for(const t of e)switch(t){case"tem_telefone":if(s.phone)return!0;break;case"tem_site":if(s.website)return!0;break;case"poucas_avaliacoes":if(s.reviews==null||s.reviews<10)return!0;break;case"muitas_avaliacoes":if(s.reviews!=null&&s.reviews>=100)return!0;break;case"nota_baixa":if(s.rating==null||s.rating<4)return!0;break}return!1}function oe(s){const e=[],t={sem_site:"Sem site",site_ruim:"Site ruim",site_desatualizado:"Site desatualizado",site_nao_responsivo:"Site não responsivo",site_lento:"Site lento",site_amador:"Site amador",site_quebrado:"Site quebrado",site_problemas:"Site com problemas",site_bom:"Site bom",site_profissional:"Site profissional"},n={sem_instagram:"Sem Instagram",instagram_encontrado:"Instagram encontrado",instagram_pouco_ativo:"Instagram pouco ativo",instagram_sem_link_site:"Instagram sem link para site",sem_facebook:"Sem Facebook",sem_presenca_digital:"Sem presença digital",sem_whatsapp:"Sem WhatsApp",tem_whatsapp:"Tem WhatsApp"},r={tem_telefone:"Tem telefone",poucas_avaliacoes:"Poucas avaliações",nota_baixa:"Nota baixa",muitas_avaliacoes:"Muitas avaliações",tem_site:"Tem site"};for(const o of s.site)e.push(t[o]);for(const o of s.digital)e.push(n[o]);for(const o of s.qualify)e.push(r[o]);s.minRating!=null&&s.minRating>0&&e.push(`${s.minRating.toFixed(1)}+ estrelas`),s.minReviews!=null&&s.minReviews>0&&e.push(`${s.minReviews}+ avaliações`);const a={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Média oportunidade",baixa:"Baixa oportunidade"};for(const o of s.scoreBands)e.push(a[o]);return e}const ie=`/* ===== Vyntra Prospector — tema escuro roxo ===== */\r
:root {\r
  --vy-bg: #10071d;\r
  --vy-panel: #160b28;\r
  --vy-card: #1d1030;\r
  --vy-border: rgba(255, 255, 255, 0.07);\r
  --vy-text: #e9e4f4;\r
  --vy-muted: #8d82a8;\r
  --vy-accent: #8b5cf6;\r
  --vy-accent2: #a855f7;\r
  --vy-gradient: linear-gradient(135deg, #8b5cf6, #a855f7);\r
}\r
\r
/* ===== Botão flutuante Vyntra (quando painel minimizado) ===== */\r
.consecom-floatbtn {\r
  position: fixed;\r
  z-index: 2147483647;\r
  width: 48px;\r
  height: 48px;\r
  border-radius: 14px;\r
  background: var(--vy-gradient);\r
  color: #fff;\r
  cursor: grab;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  box-shadow: 0 12px 32px rgba(139, 92, 246, 0.45);\r
  user-select: none;\r
  touch-action: none;\r
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;\r
  font-size: 22px;\r
  font-weight: 800;\r
  line-height: 1;\r
  border: none;\r
  transition: transform 0.12s, filter 0.15s;\r
  padding: 0;\r
}\r
.consecom-floatbtn:active { cursor: grabbing; }\r
.consecom-floatbtn:hover { filter: brightness(1.1); transform: translateY(-1px); }\r
.consecom-floatbtn {\r
  opacity: 0;\r
  transform: scale(0.85);\r
  transition: opacity 0.16s ease, transform 0.18s ease, filter 0.12s;\r
  pointer-events: none;\r
}\r
.consecom-floatbtn.open {\r
  opacity: 1;\r
  transform: scale(1);\r
  pointer-events: auto;\r
}\r
\r
/* ===== Painel flutuante Vyntra (compacto, arrastável) ===== */\r
.consecom-balloon {\r
  position: fixed;\r
  z-index: 2147483647;\r
  top: 20px;\r
  right: 20px;\r
  width: min(360px, calc(100vw - 24px));\r
  max-width: calc(100vw - 24px);\r
  height: min(560px, calc(100vh - 24px));\r
  max-height: calc(100vh - 24px);\r
  min-height: 60px;\r
  background: var(--vy-panel);\r
  border: 1px solid var(--vy-border);\r
  border-radius: 16px;\r
  box-shadow: 0 24px 60px rgba(139, 92, 246, 0.45);\r
  display: flex;\r
  flex-direction: column;\r
  opacity: 0;\r
  transform: translateX(calc(110% + 20px)) scale(0.96);\r
  pointer-events: none;\r
  transition: transform 0.18s ease, opacity 0.16s ease;\r
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;\r
  overflow: hidden;\r
}\r
.consecom-balloon.open {\r
  opacity: 1;\r
  transform: translateX(0) scale(1);\r
  pointer-events: auto;\r
}\r
\r
/* Header arrastável (grip + titulo + controles) */\r
.cs-panel__header {\r
  display: flex;\r
  align-items: center;\r
  gap: 10px;\r
  padding: 10px 12px;\r
  border-bottom: 1px solid var(--vy-border);\r
  cursor: grab;\r
  flex-shrink: 0;\r
  touch-action: none;\r
  user-select: none;\r
  -webkit-user-select: none;\r
}\r
.cs-panel__header:active { cursor: grabbing; }\r
.cs-panel__grip {\r
  cursor: grab;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 3px;\r
  padding: 2px 4px;\r
  color: var(--vy-muted);\r
  font-size: 12px;\r
  line-height: 1;\r
  touch-action: none;\r
  user-select: none;\r
  -webkit-user-select: none;\r
}\r
.cs-panel__grip:active { cursor: grabbing; }\r
\r
.cs-panel__logo {\r
  width: 32px;\r
  height: 32px;\r
  border-radius: 10px;\r
  background: var(--vy-gradient);\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  font-weight: 800;\r
  font-size: 16px;\r
  font-style: italic;\r
  color: #fff;\r
  flex: 0 0 auto;\r
}\r
.cs-panel__titles { flex: 1; min-width: 0; }\r
.cs-panel__name { font-size: 14px; font-weight: 800; color: var(--vy-text); letter-spacing: -0.01em; }\r
.cs-panel__tag { font-size: 10px; color: var(--vy-muted); margin-top: 1px; }\r
\r
/* Controles do header (minimizar / fechar) */\r
.cs-panel__controls { display: flex; align-items: center; gap: 4px; flex-shrink: 0; }\r
.cs-panel__btn {\r
  width: 26px; height: 26px; border-radius: 8px;\r
  background: rgba(255,255,255,0.04); border: 1px solid var(--vy-border);\r
  color: var(--vy-muted); display: flex; align-items: center; justify-content: center;\r
  cursor: pointer; font-size: 12px; transition: all 0.12s;\r
}\r
.cs-panel__btn:hover { background: rgba(255,255,255,0.08); color: var(--vy-text); border-color: var(--vy-accent); }\r
.cs-panel__btn svg { width: 13px; height: 13px; fill: currentColor; }\r
\r
/* Body com scroll interno */\r
.cs-panel__body { flex: 1; overflow-y: auto; overflow-x: hidden; min-height: 0; }\r
.cs-panel__body::-webkit-scrollbar { width: 6px; }\r
.cs-panel__body::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 999px; }\r
\r
/* Rodapé fixo */\r
.cs-panel__footer {\r
  border-top: 1px solid var(--vy-border);\r
  padding: 8px 12px;\r
  flex-shrink: 0;\r
}\r
\r
.cs-panel__header {\r
  display: flex;\r
  align-items: center;\r
  gap: 11px;\r
  padding: 14px 14px 12px;\r
  border-bottom: 1px solid var(--vy-border);\r
}\r
.cs-panel__titles { min-width: 0; }\r
.cs-panel__name { font-size: 15px; font-weight: 800; color: var(--vy-text); letter-spacing: -0.01em; }\r
.cs-panel__tag { font-size: 11px; color: var(--vy-muted); margin-top: 1px; }\r
\r
.cs-panel__search { padding: 12px 16px; display: flex; flex-direction: column; gap: 8px; }\r
.cs-panel__input {\r
  width: 100%;\r
  padding: 10px 12px;\r
  background: rgba(0, 0, 0, 0.28);\r
  border: 1px solid var(--vy-border);\r
  border-radius: 10px;\r
  color: var(--vy-text);\r
  font-size: 13px;\r
  font-family: inherit;\r
  outline: none;\r
  transition: border-color 0.15s;\r
}\r
.cs-panel__input:focus { border-color: var(--vy-accent); }\r
.cs-panel__input::placeholder { color: #6d6288; }\r
.cs-panel__loc {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  font-size: 11.5px;\r
  color: var(--vy-muted);\r
}\r
.cs-panel__loc svg { width: 13px; height: 13px; fill: currentColor; }\r
\r
.cs-prospect {\r
  margin: 2px 16px 12px;\r
  padding: 13px;\r
  border: none;\r
  border-radius: 12px;\r
  background: var(--vy-gradient);\r
  color: #fff;\r
  font-weight: 800;\r
  font-size: 14px;\r
  letter-spacing: 0.06em;\r
  font-family: inherit;\r
  cursor: pointer;\r
  transition: transform 0.12s, filter 0.15s;\r
  box-shadow: 0 10px 26px rgba(139, 92, 246, 0.35);\r
}\r
.cs-prospect:hover:not(:disabled) { filter: brightness(1.08); transform: translateY(-1px); }\r
.cs-prospect:active:not(:disabled) { transform: translateY(0); }\r
.cs-prospect:disabled { opacity: 0.55; cursor: default; }\r
\r
/* ===== Lista de cards ===== */\r
.cs-panel__list {\r
  flex: 1;\r
  overflow-y: auto;\r
  padding: 4px 12px 12px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 8px;\r
}\r
.cs-panel__list::-webkit-scrollbar { width: 6px; }\r
.cs-panel__list::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.12); border-radius: 999px; }\r
\r
.cs-pcard {\r
  background: var(--vy-card);\r
  border: 1px solid var(--vy-border);\r
  border-radius: 12px;\r
  padding: 10px 12px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 7px;\r
  transition: border-color 0.15s, box-shadow 0.15s;\r
}\r
.cs-pcard:hover { border-color: rgba(139,92,246,0.35); box-shadow: 0 4px 14px rgba(139,92,246,0.12); }\r
\r
/* Linha 1: nome + badge + score (referência VYNTRA) */\r
.cs-pcard__top { display: flex; align-items: center; gap: 8px; min-width: 0; }\r
.cs-pcard__name {\r
  flex: 1;\r
  min-width: 0;\r
  font-size: 13.5px;\r
  font-weight: 700;\r
  color: var(--vy-text);\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
/* Badge de oportunidade (direita) */\r
.cs-pcard__badge {\r
  font-size: 10px;\r
  font-weight: 700;\r
  padding: 3px 8px;\r
  border-radius: 999px;\r
  letter-spacing: 0.02em;\r
  white-space: nowrap;\r
  flex: 0 0 auto;\r
}\r
.cs-band-alta { color: #a7f3d0; background: rgba(16, 185, 129, 0.16); border: 1px solid rgba(16, 185, 129, 0.35); }\r
.cs-band-boa { color: #bbf7d0; background: rgba(34, 197, 94, 0.16); border: 1px solid rgba(34, 197, 94, 0.35); }\r
.cs-band-media { color: #fde68a; background: rgba(245, 158, 11, 0.16); border: 1px solid rgba(245, 158, 11, 0.35); }\r
.cs-band-baixa { color: #fecaca; background: rgba(248, 113, 113, 0.16); border: 1px solid rgba(248, 113, 113, 0.35); }\r
.cs-band-nenhuma { color: #94a3b8; background: rgba(100, 116, 139, 0.14); border: 1px solid rgba(100, 116, 139, 0.3); }\r
\r
/* Linha 2: meta (endereço • telefone • nota) */\r
.cs-pcard__meta {\r
  font-size: 11px;\r
  color: var(--vy-muted);\r
  display: flex;\r
  align-items: center;\r
  gap: 5px;\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
.cs-pcard__rating {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 3px;\r
  font-size: 11px;\r
  color: #fbbf24;\r
  font-weight: 700;\r
}\r
.cs-pcard__rating svg { width: 11px; height: 11px; fill: currentColor; }\r
\r
/* Linha 3: barra de score */\r
.cs-pcard__scorebar { display: flex; align-items: center; gap: 8px; }\r
.cs-pcard__bar {\r
  flex: 1;\r
  height: 5px;\r
  border-radius: 999px;\r
  background: rgba(255, 255, 255, 0.08);\r
  overflow: hidden;\r
}\r
.cs-pcard__barfill {\r
  height: 100%;\r
  border-radius: 999px;\r
  background: var(--vy-gradient);\r
  transition: width 0.4s ease;\r
}\r
.cs-pcard__score {\r
  font-size: 11px;\r
  font-weight: 800;\r
  color: var(--vy-text);\r
  flex: 0 0 auto;\r
}\r
.cs-pcard__score small { color: var(--vy-muted); font-weight: 600; }\r
\r
/* Linha 4: ações */\r
.cs-pcard__actions { display: flex; gap: 6px; margin-top: 1px; }\r
.cs-pcard__btn {\r
  flex: 1;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 6px;\r
  padding: 8px 10px;\r
  border: none;\r
  border-radius: 9px;\r
  font-family: inherit;\r
  font-size: 12px;\r
  font-weight: 700;\r
  cursor: pointer;\r
  transition: transform 0.1s, filter 0.15s;\r
}\r
.cs-pcard__btn svg { width: 13px; height: 13px; fill: currentColor; }\r
.cs-pcard__lead {\r
  background: var(--vy-gradient);\r
  color: #fff;\r
}\r
.cs-pcard__lead:hover:not(:disabled) { filter: brightness(1.08); transform: translateY(-1px); }\r
.cs-pcard__lead.on { background: #22c55e; }\r
.cs-pcard__lead.used { background: rgba(255, 255, 255, 0.12); color: var(--vy-muted); cursor: default; }\r
.cs-pcard__lead.nointerest { background: rgba(239, 68, 68, 0.22); color: #fca5a5; }\r
.cs-pcard__site {\r
  background: rgba(255, 255, 255, 0.08);\r
  color: var(--vy-text);\r
}\r
.cs-pcard__site:hover:not(:disabled) { filter: brightness(1.15); }\r
.cs-pcard__site:disabled { opacity: 0.4; cursor: default; }\r
\r
/* ===== Rodapé do painel ===== */\r
.cs-panel__footer {\r
  border-top: 1px solid var(--vy-border);\r
  padding: 10px 12px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 6px;\r
}\r
.cs-footer__row { display: flex; gap: 6px; }\r
.cs-footer__btn {\r
  flex: 1;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 6px;\r
  padding: 9px 10px;\r
  border: none;\r
  border-radius: 9px;\r
  font-family: inherit;\r
  font-size: 12px;\r
  font-weight: 700;\r
  color: #fff;\r
  cursor: pointer;\r
  transition: transform 0.1s, filter 0.15s;\r
}\r
.cs-footer__btn svg { width: 13px; height: 13px; fill: currentColor; }\r
.cs-footer__btn:hover:not(:disabled) { filter: brightness(1.1); }\r
.cs-footer__btn:disabled { opacity: 0.55; cursor: default; }\r
.cs-foot-import { background: var(--vy-gradient); }\r
.cs-foot-all { background: rgba(255, 255, 255, 0.1); color: var(--vy-text); }\r
.cs-foot-delete { background: rgba(239, 68, 68, 0.2); color: #fda4af; }\r
.cs-foot-config { background: rgba(255, 255, 255, 0.08); color: var(--vy-muted); }\r
.cs-foot-clear { background: rgba(139, 92, 246, 0.16); color: #c4b5fd; }\r
\r
.cs-footer__count {\r
  font-size: 11px;\r
  color: var(--vy-muted);\r
  text-align: center;\r
  padding-bottom: 2px;\r
}\r
.cs-footer__count b { color: var(--vy-text); font-weight: 600; }\r
\r
/* ===== Modal de confirmação (Limpar leads) ===== */\r
.cs-modal {\r
  position: fixed;\r
  inset: 0;\r
  z-index: 2147483646;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  background: rgba(5, 5, 12, 0.72);\r
  backdrop-filter: blur(2px);\r
  opacity: 0;\r
  transition: opacity 0.16s ease;\r
}\r
.cs-modal.cs-open { opacity: 1; }\r
.cs-modal__card {\r
  width: min(360px, calc(100vw - 32px));\r
  background: #16161f;\r
  border: 1px solid rgba(255, 255, 255, 0.1);\r
  border-radius: 14px;\r
  padding: 18px 16px;\r
  box-shadow: 0 18px 46px rgba(0, 0, 0, 0.45);\r
  font-family: Inter, system-ui, sans-serif;\r
  color: #e6e6ef;\r
  transform: translateY(6px);\r
  transition: transform 0.16s ease;\r
}\r
.cs-modal.cs-open .cs-modal__card { transform: translateY(0); }\r
.cs-modal__title {\r
  font-size: 14px;\r
  font-weight: 700;\r
  color: #fff;\r
  margin-bottom: 6px;\r
}\r
.cs-modal__text {\r
  font-size: 12.5px;\r
  line-height: 1.55;\r
  color: var(--vy-muted);\r
  margin-bottom: 14px;\r
}\r
.cs-modal__actions {\r
  display: flex;\r
  gap: 8px;\r
  justify-content: flex-end;\r
}\r
.cs-modal__btn {\r
  border: none;\r
  border-radius: 9px;\r
  padding: 8px 14px;\r
  font-family: inherit;\r
  font-size: 12.5px;\r
  font-weight: 700;\r
  cursor: pointer;\r
  transition: filter 0.15s;\r
}\r
.cs-modal__btn:hover { filter: brightness(1.12); }\r
.cs-modal__btn--ghost { background: rgba(255, 255, 255, 0.08); color: #d7d7e2; }\r
.cs-modal__btn--danger { background: rgba(139, 92, 246, 0.9); color: #fff; }\r
\r
.cs-empty {\r
  text-align: center;\r
  color: var(--vy-muted);\r
  font-size: 12px;\r
  padding: 28px 12px;\r
  line-height: 1.6;\r
}\r
.cs-empty b { color: var(--vy-text); font-weight: 700; }\r
.cs-empty__icon { font-size: 20px; display: block; margin-bottom: 8px; }\r
\r
/* ===== Cards nativos enxutos (controles dentro dos cards do Maps) ===== */\r
.consecom-host {\r
  position: relative !important;\r
  min-width: 0 !important;\r
}\r
.consecom-host > *:not(.consecom-control) {\r
  opacity: 0 !important;\r
  pointer-events: none !important;\r
  height: 0 !important;\r
  overflow: hidden !important;\r
}\r
.consecom-control {\r
  position: relative !important;\r
  z-index: 30 !important;\r
  display: flex !important;\r
  align-items: center !important;\r
  gap: 6px !important;\r
  padding: 5px 8px !important;\r
  background: var(--vy-card) !important;\r
  border: 1px solid var(--vy-border) !important;\r
  border-radius: 8px !important;\r
  box-sizing: border-box !important;\r
  min-height: 34px !important;\r
  font-family: 'Inter', 'Segoe UI', Roboto, system-ui, sans-serif !important;\r
}\r
.consecom-control .cs-select { flex: 0 0 auto !important; }\r
.consecom-control .cs-name {\r
  flex: 1 !important;\r
  min-width: 0 !important;\r
  font-size: 12px !important;\r
  font-weight: 600 !important;\r
  color: var(--vy-text) !important;\r
  white-space: nowrap !important;\r
  overflow: hidden !important;\r
  text-overflow: ellipsis !important;\r
}\r
.consecom-control .cs-actions {\r
  display: flex !important;\r
  gap: 4px !important;\r
  flex: 0 0 auto !important;\r
}\r
.consecom-control .cs-round {\r
  width: 26px !important;\r
  height: 26px !important;\r
  border-radius: 50% !important;\r
  border: none !important;\r
  cursor: pointer !important;\r
  display: flex !important;\r
  align-items: center !important;\r
  justify-content: center !important;\r
  padding: 0 !important;\r
  background: var(--vy-gradient) !important;\r
  color: #fff !important;\r
  box-shadow: 0 1px 4px rgba(139, 92, 246, 0.4) !important;\r
  transition: transform 0.1s, background 0.15s !important;\r
}\r
.consecom-control .cs-round svg { width: 13px; height: 13px; fill: #fff; }\r
.consecom-control .cs-round:hover:not(:disabled) { filter: brightness(1.1); transform: scale(1.08); }\r
.consecom-control .cs-round:disabled { background: rgba(255, 255, 255, 0.1); box-shadow: none; cursor: default; opacity: 0.6; }\r
.consecom-control .cs-round:disabled svg { fill: #6d6288; }\r
.consecom-control .cs-select { background: transparent; border: 2px solid var(--vy-accent); color: var(--vy-accent); }\r
.consecom-control .cs-select svg { fill: var(--vy-accent); }\r
.consecom-control .cs-select.on { background: var(--vy-accent); color: #fff; }\r
.consecom-control .cs-select.on svg { fill: #fff; }\r
.consecom-control .cs-select.used { background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.12); color: #6d6288; }\r
.consecom-control .cs-select.used svg { fill: #6d6288; }\r
.consecom-control .cs-select.nointerest { background: rgba(239, 68, 68, 0.25); border-color: #ef4444; color: #fca5a5; font-weight: 700; }\r
.consecom-control .cs-badge {\r
  position: absolute !important;\r
  top: -8px !important;\r
  right: -6px !important;\r
  background: #ef4444 !important;\r
  color: #fff !important;\r
  font-size: 9px !important;\r
  font-weight: 700 !important;\r
  padding: 1px 5px !important;\r
  border-radius: 999px !important;\r
  white-space: nowrap !important;\r
  box-shadow: 0 1px 3px rgba(0,0,0,.25) !important;\r
}\r
\r
/* ===== Toast ===== */\r
.consecom-toast {\r
  position: fixed;\r
  top: 18px;\r
  left: 50%;\r
  transform: translateX(-50%) translateY(-18px);\r
  z-index: 2147483647;\r
  padding: 12px 20px;\r
  background: #160b28;\r
  color: #e9e4f4;\r
  border: 1px solid rgba(16, 185, 129, 0.5);\r
  border-radius: 12px;\r
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);\r
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;\r
  font-size: 14px;\r
  font-weight: 600;\r
  opacity: 0;\r
  transition: opacity 0.25s, transform 0.25s;\r
  pointer-events: none;\r
}\r
.consecom-toast.cs-warn { border-color: rgba(249, 115, 22, 0.6); }\r
.consecom-toast.cs-show { opacity: 1; transform: translateX(-50%) translateY(0); }\r
\r
/* ===== Prospecção Automática — Painel de filtros (chips) ===== */\r
.cs-filters { padding: 10px 14px; border-top: 1px solid var(--vy-border); display: flex; flex-direction: column; gap: 10px; }\r
.cs-filters__title {\r
  font-size: 11px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;\r
  color: var(--vy-muted);\r
}\r
.cs-chips { display: flex; flex-wrap: wrap; gap: 6px; }\r
.cs-chip {\r
  font-size: 11px; font-weight: 600; padding: 5px 10px; border-radius: 999px;\r
  background: rgba(255,255,255,0.04); color: var(--vy-text);\r
  border: 1px solid var(--vy-border); cursor: pointer;\r
  transition: all 0.15s; white-space: nowrap; font-family: 'Inter', sans-serif;\r
}\r
.cs-chip:hover { border-color: var(--vy-accent); color: var(--vy-accent2); }\r
.cs-chip--on {\r
  background: var(--vy-gradient) !important; color: #fff !important;\r
  border-color: transparent !important;\r
  box-shadow: 0 2px 8px rgba(139,92,246,0.35);\r
}\r
.cs-chip:focus-visible { outline: 2px solid var(--vy-accent); outline-offset: 1px; }\r
\r
.cs-adv { display: flex; gap: 10px; padding-top: 8px; border-top: 1px solid var(--vy-border); }\r
.cs-adv__item { display: flex; flex-direction: column; gap: 4px; flex: 1; }\r
.cs-adv__item span { font-size: 9px; font-weight: 700; color: var(--vy-muted); text-transform: uppercase; letter-spacing: 0.06em; }\r
.cs-adv__item select {\r
  background: var(--vy-card); color: var(--vy-text); border: 1px solid var(--vy-border);\r
  border-radius: 7px; padding: 6px 8px; font-size: 12px; font-family: 'Inter', sans-serif;\r
  cursor: pointer; outline: none;\r
}\r
.cs-adv__item select:focus { border-color: var(--vy-accent); }\r
\r
.cs-fgroup { margin-bottom: 4px; }\r
.cs-fgroup__h {\r
  font-size: 10px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase;\r
  color: var(--vy-accent2); margin-bottom: 4px;\r
}\r
.cs-radio { display: flex; flex-wrap: wrap; gap: 6px; }\r
.cs-radio__item {\r
  display: flex; align-items: center; gap: 5px; padding: 4px 9px;\r
  border: 1px solid var(--vy-border); border-radius: 999px;\r
  font-size: 11px; cursor: pointer; color: var(--vy-text); background: rgba(255,255,255,0.04);\r
  transition: all 0.15s;\r
}\r
.cs-radio__item:hover { border-color: var(--vy-accent); }\r
.cs-radio__item input { accent-color: var(--vy-accent); }\r
.cs-radio__item:has(input:checked) {\r
  border-color: var(--vy-accent); background: rgba(139,92,246,0.18); color: var(--vy-accent2);\r
}\r
\r
/* ===== Resultado da prospecção (Alex) ===== */\r
.cs-result { padding: 12px 14px; }\r
.cs-result__card {\r
  background: var(--vy-card); border: 1px solid var(--vy-border); border-radius: 14px;\r
  padding: 14px; animation: cs-fadein 0.3s ease;\r
}\r
@keyframes cs-fadein { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }\r
.cs-result__head { text-align: center; margin-bottom: 10px; }\r
.cs-result__big { font-size: 34px; font-weight: 800; color: var(--vy-accent2); line-height: 1; }\r
.cs-result__sub { font-size: 12px; color: var(--vy-muted); margin-top: 2px; }\r
.cs-result__head--ok .cs-result__title { color: #10b981; font-weight: 800; letter-spacing: 0.04em; }\r
.cs-result__stats { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--vy-muted); margin-bottom: 10px; }\r
.cs-result__stats span { color: var(--vy-text); font-weight: 700; }\r
.cs-result__dup { color: #f59e0b; }\r
.cs-alex {\r
  display: flex; gap: 10px; background: rgba(139,92,246,0.08); border: 1px solid rgba(139,92,246,0.2);\r
  border-radius: 10px; padding: 10px; margin-bottom: 12px;\r
}\r
.cs-alex__avatar { font-size: 18px; }\r
.cs-alex__name { font-size: 12px; font-weight: 700; color: var(--vy-accent2); }\r
.cs-alex__msg { font-size: 12px; color: var(--vy-text); line-height: 1.4; margin-top: 2px; }\r
.cs-result__cta {\r
  width: 100%; padding: 13px; border: none; border-radius: 12px;\r
  background: var(--vy-gradient); color: #fff; font-size: 14px; font-weight: 800;\r
  letter-spacing: 0.04em; cursor: pointer; transition: transform 0.15s, box-shadow 0.15s;\r
  font-family: 'Inter', sans-serif;\r
}\r
.cs-result__cta:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(139,92,246,0.45); }\r
.cs-result__cta:disabled { opacity: 0.7; cursor: default; transform: none; }\r
.cs-result__cta--ghost { background: transparent; border: 1px solid var(--vy-border); color: var(--vy-text); }\r
.cs-result__empty { text-align: center; color: var(--vy-muted); font-size: 13px; padding: 12px; }\r
\r
/* Relatório final */\r
.cs-result__lines { list-style: none; padding: 0; margin: 8px 0; font-size: 12px; color: var(--vy-text); }\r
.cs-result__lines li { padding: 3px 0; border-bottom: 1px dashed rgba(255,255,255,0.05); }\r
.cs-result__crit { margin: 8px 0; }\r
.cs-result__crit-h { font-size: 10px; font-weight: 700; text-transform: uppercase; color: var(--vy-muted); margin-bottom: 4px; }\r
.cs-result__tags { display: flex; flex-wrap: wrap; gap: 5px; }\r
.cs-result__chip {\r
  font-size: 11px; padding: 3px 8px; border-radius: 999px;\r
  background: rgba(139,92,246,0.15); color: var(--vy-accent2); border: 1px solid rgba(139,92,246,0.3);\r
}\r
.cs-result__progress { font-size: 12px; color: var(--vy-muted); text-align: center; padding: 8px; }\r
`;class le{constructor(){this.cfg=null,this.found=[],this.selected=new Set,this.used=new Set,this.noInterest=new Set,this.scanning=!1,this.clearedSession=!1,this.bubble=null,this.balloon=null,this.floatBtn=null,this.headerEl=null,this.listEl=null,this.locEl=null,this.countEl=null,this.lastQuery="",this.filters={...ne},this.filtersPanel=null,this.resultPanel=null,this.prospecting=!1,this.prospectCancel=!1,this.lastMatched=[],this.debounceScan=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.scan()},350))}})()}async init(){this.cfg=await x(),ye(),this.observeDom(),this.scan("force"),window.addEventListener("click",e=>{var t,n;(t=this.balloon)!=null&&t.classList.contains("open")&&(this.balloon.contains(e.target)||(n=this.floatBtn)!=null&&n.contains(e.target)||this.toggleBalloon(!1))}),chrome.runtime.onMessage.addListener(e=>{((e==null?void 0:e.type)==="consecom:open"||(e==null?void 0:e.type)==="consecom:ping")&&this.toggleBalloon(!0)}),window.addEventListener("resize",()=>{var e;(e=this.balloon)!=null&&e.classList.contains("open")&&this.clampElement(this.balloon),this.floatBtn&&document.body.contains(this.floatBtn)&&this.clampElement(this.floatBtn)}),this.ensureLauncher()}ensureLauncher(){if(this.balloon&&this.balloon.classList.contains("open")||this.floatBtn&&document.body.contains(this.floatBtn))return;(!this.floatBtn||!document.body.contains(this.floatBtn))&&(this.floatBtn=this.buildFloatBtn(),document.body.appendChild(this.floatBtn));const e=this.readPosition();this.floatBtn.style.right=`${e.right}px`,this.floatBtn.style.top=`${e.top}px`,requestAnimationFrame(()=>{var t;return(t=this.floatBtn)==null?void 0:t.classList.add("open")})}observeDom(){new MutationObserver(()=>this.debounceScan()).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("scroll",()=>this.debounceScan(),{passive:!0})}scan(e="scan"){if(!(this.scanning&&e!=="force")){this.scanning=!0;try{this.syncArea(),this.refreshCards(),this.prune(),this.renderControls(),this.renderBalloonList()}finally{this.scanning=!1}}}syncArea(){var n;const e=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]'),t=((e==null?void 0:e.value)||"").trim();t&&t!==this.lastQuery&&(this.lastQuery=t,this.clearedSession=!1,this.selected.clear(),this.found=[],this.locEl&&(this.locEl.textContent=t),(n=this.balloon)!=null&&n.classList.contains("open")&&this.renderCardList()),t&&(this.lastQuery=t)}renderControls(){}makeHostSlim(e){e.classList.contains("consecom-host")||e.classList.add("consecom-host")}toggleSelected(e){this.used.has(e)||this.noInterest.has(e)||(this.selected.has(e)?this.selected.delete(e):this.selected.add(e),this.syncAll())}toggleControl(e){this.toggleSelected(e)}selectAllAvailable(){const e=this.found.filter(r=>!this.used.has(r.key)&&!this.noInterest.has(r.key)),t=Math.min(50,e.length),n=new Set;for(let r=0;r<t;r++)n.add(e[r].key);this.selected=n,this.syncAll(),b(`✅ ${this.selected.size} selecionado(s) (máx. 50 por importação)`)}clearSelection(){this.selected.clear(),this.syncAll()}buildControl(e){const t=document.createElement("div");t.className="consecom-control",t.title=e.lead.name;const n=document.createElement("button");n.type="button",n.className="cs-round cs-select",n.title="Selecionar",n.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),this.toggleControl(e.key)});const r=document.createElement("span");r.className="cs-name",r.textContent=e.lead.name,r.title=e.lead.name;const a=document.createElement("div");a.className="cs-actions";const o=document.createElement("button");o.type="button",o.className="cs-round",o.title="Abrir site",o.innerHTML=V,e.lead.website?o.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):o.disabled=!0;const i=document.createElement("button");i.type="button",i.className="cs-round",i.title="Chamar",i.innerHTML=_e,e.lead.phone?i.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),window.location.href=`tel:${e.lead.phone.replace(/\s+/g,"")}`}):i.disabled=!0,a.append(o,i);const d=document.createElement("span");return d.className="cs-badge",d.textContent="Sem interesse",d.style.display="none",t.append(n,r,a,d),t}updateControl(e){var a,o;const t=(a=e.control)==null?void 0:a.querySelector(".cs-select");if(!t)return;const n=this.noInterest.has(e.key);t.classList.toggle("nointerest",n);const r=(o=e.control)==null?void 0:o.querySelector(".cs-badge");if(r&&(r.style.display=n?"block":"none"),n){t.disabled=!0,t.title="Sem interesse — não importar (6 meses)",t.innerHTML="✕";return}this.used.has(e.key)?(t.classList.add("used"),t.disabled=!0,t.title="Já importado anteriormente",t.innerHTML=L):(t.disabled=!1,t.classList.toggle("on",this.selected.has(e.key)),t.title=this.selected.has(e.key)?"Remover seleção":"Selecionar",t.innerHTML=this.selected.has(e.key)?L:T)}ensureBalloon(){if(this.balloon&&document.body.contains(this.balloon)){const t=this.readPosition();this.balloon.style.right=`${t.right}px`,this.balloon.style.top=`${t.top}px`,requestAnimationFrame(()=>{var n;return(n=this.balloon)==null?void 0:n.classList.add("open")});return}this.balloon=this.buildBalloon();const e=this.readPosition();this.balloon.style.right=`${e.right}px`,this.balloon.style.top=`${e.top}px`,document.body.appendChild(this.balloon),this.positionBalloon(),requestAnimationFrame(()=>{var t;return(t=this.balloon)==null?void 0:t.classList.add("open")})}minimizeBalloon(){if(!this.balloon||!this.headerEl)return;this.balloon.classList.remove("open"),this.balloon.style.display="none",this.balloon.dataset.minimized="true",(!this.floatBtn||!document.body.contains(this.floatBtn))&&(this.floatBtn=this.buildFloatBtn(),document.body.appendChild(this.floatBtn));const e=this.readPosition();this.floatBtn.style.right=`${e.right}px`,this.floatBtn.style.top=`${e.top}px`,requestAnimationFrame(()=>{var t;return(t=this.floatBtn)==null?void 0:t.classList.add("open")})}buildFloatBtn(){const e=document.createElement("button");return e.type="button",e.className="consecom-floatbtn",e.title="Abrir Vyntra",e.textContent="V",e.addEventListener("click",()=>{if(e.dataset.dragged==="true"){e.dataset.dragged="false";return}this.restoreBalloon()}),this.enableDrag(e,e),e}restoreBalloon(){this.balloon||(this.balloon=this.buildBalloon(),document.body.appendChild(this.balloon)),this.balloon.style.display="flex",this.balloon.dataset.minimized="false";const e=this.floatBtn?{right:parseFloat(this.floatBtn.style.right)||20,top:parseFloat(this.floatBtn.style.top)||20}:this.readPosition();this.balloon.style.right=`${e.right}px`,this.balloon.style.top=`${e.top}px`,this.clampElement(this.balloon),requestAnimationFrame(()=>{var t;return(t=this.balloon)==null?void 0:t.classList.add("open")}),this.floatBtn&&(this.floatBtn.classList.remove("open"),this.floatBtn.remove(),this.floatBtn=null),this.renderBalloonList()}readPosition(){const e=parseFloat(localStorage.getItem("consecom-float-right")||"20"),t=parseFloat(localStorage.getItem("consecom-float-top")||"20");return{right:Math.max(12,Number.isFinite(e)?e:20),top:Math.max(12,Number.isFinite(t)?t:20)}}savePosition(e){const t=parseFloat(e.style.right)||20,n=parseFloat(e.style.top)||20;localStorage.setItem("consecom-float-right",String(Math.max(12,t))),localStorage.setItem("consecom-float-top",String(Math.max(12,n)))}enableDrag(e,t){let r=!1,a=!1,o=0,i=0,d=0,p=0;const u=m=>{if(m.button!==0||r)return;const h=m.target;if(!(h&&h!==e&&h.closest("button, input, select, textarea, a, .cs-panel__controls, [data-no-drag]"))){m.preventDefault(),r=!0,a=!1,t.dataset.dragged="false",o=m.clientX,i=m.clientY,d=parseFloat(t.style.right)||20,p=parseFloat(t.style.top)||20;try{e.setPointerCapture(m.pointerId)}catch{}}},c=m=>{if(!r)return;const h=m.clientX-o,g=m.clientY-i;Math.abs(h)+Math.abs(g)>3&&(a=!0);const f=Math.max(0,window.innerWidth-12-t.offsetWidth),S=Math.max(0,window.innerHeight-12-t.offsetHeight),v=Math.min(Math.max(0,d-h),f),E=Math.min(Math.max(0,p+g),S);t.style.right=`${v}px`,t.style.top=`${E}px`,t.style.left="",t.style.bottom=""},l=m=>{if(r){r=!1;try{e.hasPointerCapture(m.pointerId)&&e.releasePointerCapture(m.pointerId)}catch{}a&&(t.dataset.dragged="true",this.savePosition(t))}};e.addEventListener("pointerdown",u),e.addEventListener("pointermove",c),e.addEventListener("pointerup",l),e.addEventListener("pointercancel",l),e.addEventListener("lostpointercapture",()=>{r=!1})}buildBalloon(){const e=document.createElement("aside");e.className="consecom-balloon";const t=document.createElement("div");t.className="cs-panel__header",this.headerEl=t;const n=document.createElement("div");n.className="cs-panel__grip",n.title="Arrastar painel",n.innerHTML="&#8230;<br>&#8230;<br>&#8230;";const r=document.createElement("div");r.className="cs-panel__logo",r.textContent="V";const a=document.createElement("div");a.className="cs-panel__titles";const o=document.createElement("div");o.className="cs-panel__name",o.textContent="VYNTRA";const i=document.createElement("div");i.className="cs-panel__tag",i.textContent="Prospecção Automática";const d=document.createElement("div");d.className="cs-panel__tagline",d.textContent="Encontre empresas qualificadas no Google Maps e importe os melhores leads.",a.append(o,i,d);const p=document.createElement("div");p.className="cs-panel__controls";const u=document.createElement("button");u.type="button",u.className="cs-panel__btn",u.title="Minimizar",u.innerHTML='<svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M19 13h-4v4h-2v-4H5v-2h4V7h2v4h4z"/></svg>',u.addEventListener("click",C=>{C.stopPropagation(),this.minimizeBalloon()});const c=document.createElement("button");c.type="button",c.className="cs-panel__btn",c.title="Fechar",c.innerHTML='<svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M18.3 5.71 12 12l6.3 6.29-1 1L12 14l-6.3 6.3-1-1L10.8 12 4.5 5.7l1-1L12 10.8l6.3-6.3z"/></svg>',c.addEventListener("click",C=>{C.stopPropagation(),this.toggleBalloon(!1)}),p.append(u,c),t.append(n,r,a,p),this.enableDrag(t,e);const l=document.createElement("div");l.className="cs-panel__body";const m=document.createElement("div");m.className="cs-panel__search";const h=document.createElement("input");h.className="cs-panel__input",h.type="text",h.placeholder="Buscar empresas",h.spellcheck=!1,h.addEventListener("keydown",C=>{var R;if(C.key==="Enter"){const P=h.value.trim();if(!P)return;const w=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]');if(w){const I=(R=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:R.set;I==null||I.call(w,P),w.dispatchEvent(new Event("input",{bubbles:!0})),w.dispatchEvent(new Event("change",{bubbles:!0})),w.focus(),w.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0}))}else this.lastQuery=P,this.selected.clear(),this.found=[],this.scan("force")}});const g=document.createElement("div");g.className="cs-panel__loc",g.innerHTML=ke,this.locEl=document.createElement("span"),this.locEl.textContent="Aguardando busca…",g.append(this.locEl),m.append(h,g);const f=document.createElement("button");f.type="button",f.className="cs-prospect",f.textContent="PROSPECTAR",f.addEventListener("click",()=>void this.runProspect(f));const S=this.buildFiltersPanel();this.filtersPanel=S;const v=document.createElement("div");v.className="cs-result",v.style.display="none",this.resultPanel=v;const E=document.createElement("div");E.className="cs-panel__list",this.listEl=E;const N=document.createElement("div");N.className="cs-panel__footer";const B=document.createElement("div");B.className="cs-footer__count",this.countEl=B;const M=document.createElement("div");M.className="cs-footer__row";const k=document.createElement("button");k.type="button",k.className="cs-footer__btn cs-foot-clear",k.innerHTML="Limpar"+U,k.addEventListener("click",()=>void this.confirmClear());const y=document.createElement("button");y.type="button",y.className="cs-footer__btn cs-foot-delete",y.innerHTML="Excluir"+U,y.addEventListener("click",()=>void this.doDelete(y));const _=document.createElement("button");return _.type="button",_.className="cs-footer__btn cs-foot-config",_.title="Configurar Supabase",_.innerHTML="Configurar"+we,_.addEventListener("click",()=>void this.promptConfig()),M.append(k,y,_),N.append(B,M),l.append(m,f,S,v,E),e.append(t,l,N),this.balloon=e,e}async runProspect(e){if(!this.prospecting){this.prospecting=!0,this.prospectCancel=!1,this.clearedSession=!1,e.disabled=!0;try{await this.runProspectStages(e),this.scan("force"),this.readFiltersFromPanel();const{matched:t,novoCount:n,existenteCount:r}=this.applyAutomaticSelection();this.renderResult(t,n,r),this.renderBalloonList()}catch(t){b(`Erro na prospecção: ${t}`,"warn")}finally{e.textContent="PROSPECTAR",e.disabled=!1,this.prospecting=!1}}}async runProspectStages(e){const t=[["Coletando resultados",320],["Aprofundando a busca",340],["Carregando mais empresas",360],["Calculando oportunidades",380]];for(const[n,r]of t){if(this.prospectCancel)break;const a=this.found.length;e.textContent=a>0?`PROSPECTANDO… ${a} resultados`:"PROSPECTANDO…",this.updateProspectProgress(),await this.scrollAndCollect(),await z(r),this.updateProspectProgress()}}async scrollAndCollect(){const e=Array.from(document.querySelectorAll(D()));if(e.length===0)return;const t=O(e[0]),n=t?de(t):null;if(!n)return;const r=this.found.length,a=Math.min(600,n.offsetHeight||400);n.scrollBy({top:a,behavior:"smooth"}),await z(340),this.scan("force"),this.found.length===r&&(n.scrollBy({top:a,behavior:"smooth"}),await z(340),this.scan("force"))}updateProspectProgress(){if(!this.resultPanel)return;const e=this.found.length,t=document.createElement("div");t.className="cs-result__progress",t.textContent=`Coletados: ${e}`,this.resultPanel.replaceChildren(t),this.resultPanel.style.display="block"}applyAutomaticSelection(){const t=this.found.filter(r=>!this.used.has(r.key)&&!this.noInterest.has(r.key)).filter(r=>H(r.lead,this.filters));this.lastMatched=t,this.selected.clear();for(const r of t)this.selected.add(r.key);const n=this.found.filter(r=>this.used.has(r.key)&&H(r.lead,this.filters));return{matched:t,novoCount:t.length,existenteCount:n.length}}buildFiltersPanel(){const e=document.createElement("div");e.className="cs-filters";const t=document.createElement("div");t.className="cs-filters__title",t.textContent="Encontrar oportunidades",e.appendChild(t);const n=document.createElement("div");n.className="cs-chips";for(const c of te){const l=document.createElement("button");l.type="button",l.className="cs-chip",l.dataset.id=c.id,l.dataset.cat=c.cat,l.dataset.value=c.value,l.dataset.accent=c.accent??"#8b5cf6",l.textContent=c.label,l.addEventListener("click",()=>{this.filters.activeChips.has(c.id)?this.filters.activeChips.delete(c.id):this.filters.activeChips.add(c.id),l.classList.toggle("cs-chip--on"),this.syncChipsFromState(l,c.accent)}),this.syncChipsFromState(l,c.accent),n.appendChild(l)}e.appendChild(n);const r=document.createElement("div");r.className="cs-adv";const a=document.createElement("label");a.className="cs-adv__item";const o=document.createElement("span");o.textContent="Nota mín.";const i=document.createElement("select");i.dataset.cat="minRating";for(const c of[0,4,4.5,4.8]){const l=document.createElement("option");l.value=String(c),l.textContent=c===0?"Qualquer":`${c.toFixed(1)}+`,i.appendChild(l)}a.append(o,i);const d=document.createElement("label");d.className="cs-adv__item";const p=document.createElement("span");p.textContent="Avaliações mín.";const u=document.createElement("select");u.dataset.cat="minReviews";for(const c of[0,10,50,100,500]){const l=document.createElement("option");l.value=String(c),l.textContent=c===0?"Qualquer":`${c}+`,u.appendChild(l)}return d.append(p,u),r.append(a,d),e.appendChild(r),e.appendChild(this.buildServiceGroup()),e}syncChipsFromState(e,t){e.classList.contains("cs-chip--on")?(e.style.borderColor=t??"#8b5cf6",e.style.background=`${t??"#8b5cf6"}22`,e.style.color="#fff"):(e.style.borderColor="",e.style.background="",e.style.color="")}buildServiceGroup(){const e=document.createElement("div");e.className="cs-fgroup cs-fgroup--svc";const t=document.createElement("div");t.className="cs-fgroup__h",t.textContent="SERVIÇO / NECESSIDADE",e.appendChild(t);const n=document.createElement("div");n.className="cs-radio";const r=[{id:"todos",label:"Todos"},{id:"site",label:"Site"},{id:"sistema",label:"Sistema"},{id:"trafego",label:"Tráfego pago"},{id:"automacao",label:"Automação"},{id:"presenca",label:"Presença digital"}];for(const a of r){const o=document.createElement("label");o.className="cs-radio__item";const i=document.createElement("input");i.type="radio",i.name="cs-service",i.value=a.id,i.dataset.cat="service",a.id==="todos"&&(i.checked=!0);const d=document.createElement("span");d.textContent=a.label,o.append(i,d),n.appendChild(o)}return e.appendChild(n),e}readFiltersFromPanel(){if(!this.filtersPanel)return;const e=[],t=[],n=[],r=[];this.filtersPanel.querySelectorAll(".cs-chip.cs-chip--on").forEach(c=>{const l=c.dataset.cat,m=c.dataset.value;!l||!m||(l==="site"?e.push(m):l==="digital"?t.push(m):l==="score"?r.push(m):l==="qualify"&&n.push(m))});let a=null,o=null;const i=this.filtersPanel.querySelector("select[data-cat=minRating]");i&&(a=parseFloat(i.value)||null);const d=this.filtersPanel.querySelector("select[data-cat=minReviews]");d&&(o=parseInt(d.value,10)||null);let p="todos";const u=this.filtersPanel.querySelector("input[name=cs-service]:checked");u&&(p=u.value),this.filters={site:e,digital:t,qualify:n,minRating:a,minReviews:o,scoreBands:r,service:p,activeChips:this.filters.activeChips}}renderResult(e,t,n){if(!this.resultPanel)return;const r=this.found.length,a=document.createElement("div");a.className="cs-result__card";const o=document.createElement("div");o.className="cs-result__head";const i=document.createElement("div");i.className="cs-result__big",i.textContent=`${t}`;const d=document.createElement("div");d.className="cs-result__sub",d.textContent=t===1?"oportunidade encontrada":"oportunidades encontradas",o.append(i,d),a.appendChild(o);const p=document.createElement("div");p.className="cs-result__stats";const u=document.createElement("div");u.innerHTML=`<span>${r}</span> analisadas`;const c=document.createElement("div");if(c.innerHTML=`<span>${t}</span> selecionadas automaticamente`,p.append(u,c),n>0){const l=document.createElement("div");l.className="cs-result__dup",l.innerHTML=`⚠ ${n} já existem na Vyntra`,p.appendChild(l)}if(a.appendChild(p),e.length>0){const l=this.buildAlexHint(e);a.appendChild(l)}if(t>0){const l=document.createElement("button");l.type="button",l.className="cs-result__cta";const m=n>0?`${t} NOVOS`:`${t} LEADS`;l.textContent=n>0?`IMPORTAR ${t} NOVOS`:`IMPORTAR ${t} LEADS`,l.addEventListener("click",()=>void this.doProspectImport(l,e,m)),a.appendChild(l)}else{const l=document.createElement("div");l.className="cs-result__empty",l.textContent="Nenhuma empresa corresponde aos critérios. Ajuste os filtros e tente novamente.",a.appendChild(l)}this.resultPanel.replaceChildren(a),this.resultPanel.style.display="block"}buildAlexHint(e){const t=document.createElement("div");t.className="cs-alex";const n=document.createElement("div");n.className="cs-alex__avatar",n.textContent="🤖";const r=document.createElement("div");r.className="cs-alex__body";const a=document.createElement("div");a.className="cs-alex__name",a.textContent="Alex";const o=document.createElement("div");o.className="cs-alex__msg";const i=e.filter(u=>A(u.lead).band==="alta").length,p=e.filter(u=>!u.lead.website).length>=e.length/2?"sem site ou com presença digital fraca":"com boa avaliação e presença consolidada";return o.textContent=`Encontrei ${e.length} empresas que parecem boas oportunidades para prospecção.`+(i>0?` ${i} delas possuem alta oportunidade.`:"")+` A maior oportunidade está em empresas ${p}.`,r.append(a,o),t.append(n,r),t}async doProspectImport(e,t,n){if(this.cfg=this.cfg??await x(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const r=t.map(o=>o.lead).slice(0,50);if(r.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const a=e.textContent;e.disabled=!0;try{const o=["Google Maps"],i=this.filters.service!=="todos"?`Interesse: ${this.serviceLabel(this.filters.service)}`:null,p={source:"google_maps",sourceDetail:"vyntra_prospector",tags:i?[...o,i]:o,prospectFilters:this.filtersToSnapshot(),prospectedAt:new Date().toISOString()};let u=0;const c=await F(this.cfg,r,(l,m)=>{u=l;const h=Math.round(l/m*100);e.textContent=`Importando… ${h}%`},p);console.log("[IMPORT] Resultado completo:",{ok:c.ok,failed:c.failed,firstError:c.firstError,errors:c.errors}),this.renderProspectReport({analyzed:this.found.length,opportunities:t.length,imported:c.ok,failed:c.failed,alreadyExists:this.countAlreadyExists(t),filtersText:oe(this.filters)}),e.textContent=c.failed===0?`✓ ${c.ok} LEADS IMPORTADOS`:`${c.ok} ok, ${c.failed} falharam`,c.failed===0?(b(`✅ ${c.ok} lead(s) importado(s)!`),this.selected.clear()):b(`⚠️ ${c.ok} ok, ${c.failed} falharam${c.firstError?`: ${c.firstError}`:""}`,"warn"),this.checkUsed(),this.syncAll()}catch(o){e.textContent=`Erro: ${o}`,b(`Erro ao importar: ${o}`,"warn")}finally{setTimeout(()=>{e.textContent=a,e.disabled=!1},4e3)}}countAlreadyExists(e){return e.filter(t=>this.used.has(t.key)).length}serviceLabel(e){return{todos:"Todos",site:"Site",sistema:"Sistema",trafego:"Tráfego pago",automacao:"Automação",presenca:"Presença digital"}[e]}filtersToSnapshot(){return{site:this.filters.site,digital:this.filters.digital,minRating:this.filters.minRating,minReviews:this.filters.minReviews,scoreBands:this.filters.scoreBands,service:this.filters.service,query:this.lastQuery,at:new Date().toISOString()}}renderProspectReport(e){if(!this.resultPanel)return;const t=document.createElement("div");t.className="cs-result__card cs-result__report";const n=document.createElement("div");n.className="cs-result__head cs-result__head--ok";const r=document.createElement("div");r.className="cs-result__title",r.textContent="PROSPECÇÃO CONCLUÍDA",n.appendChild(r),t.appendChild(n);const a=[`${e.analyzed} empresas analisadas`,`${e.opportunities} oportunidades encontradas`,`${e.imported} novos leads importados`,e.failed>0?`${e.failed} com erro`:null,e.alreadyExists>0?`${e.alreadyExists} já estavam na Vyntra`:null].filter(Boolean),o=document.createElement("ul");o.className="cs-result__lines";for(const d of a){const p=document.createElement("li");p.textContent=d,o.appendChild(p)}if(t.appendChild(o),e.filtersText.length>0){const d=document.createElement("div");d.className="cs-result__crit",d.innerHTML='<div class="cs-result__crit-h">Critérios:</div>';const p=document.createElement("div");p.className="cs-result__tags";for(const u of e.filtersText){const c=document.createElement("span");c.className="cs-result__chip",c.textContent=`✓ ${u}`,p.appendChild(c)}d.appendChild(p),t.appendChild(d)}const i=document.createElement("button");i.type="button",i.className="cs-result__cta cs-result__cta--ghost",i.textContent="VER LEADS",i.addEventListener("click",()=>this.renderBalloonList()),t.appendChild(i),this.resultPanel.replaceChildren(t),this.resultPanel.style.display="block"}doProspect(e){this.runProspect(e)}renderBalloonList(){!this.balloon||!this.listEl||(this.updateCounts(),this.renderCardList())}renderCardList(){if(!this.listEl)return;if(this.found.length===0){this.listEl.innerHTML="";const t=document.createElement("div");t.className="cs-empty",this.clearedSession?t.innerHTML='<span class="cs-empty__icon">✓</span><b>0 leads capturados</b> · <b>0 leads selecionados</b><br/>Sessão limpa. Inicie uma nova busca e toque em PROSPECTAR para capturar novamente.':t.innerHTML="<b>0 leads capturados</b> · <b>0 leads selecionados</b><br/>Rode a busca no Google Maps e toque em PROSPECTAR para listar as empresas.",this.listEl.appendChild(t);return}const e=document.createDocumentFragment();for(const t of this.found)e.appendChild(this.buildCard(t));this.listEl.replaceChildren(e)}buildCard(e){const t=document.createElement("div");t.className="cs-pcard",t.dataset.key=e.key;const n=A(e.lead),r=document.createElement("div");r.className="cs-pcard__top";const a=document.createElement("div");a.className="cs-pcard__name",a.textContent=e.lead.name,a.title=e.lead.name;const o=document.createElement("div");o.className="cs-pcard__badge "+ee(n.band),o.textContent=n.label,r.append(a,o);const i=document.createElement("div");i.className="cs-pcard__meta";const d=[];if(e.lead.address){const f=document.createElement("span");f.textContent=e.lead.address.split(",")[0],d.push(f)}if(e.lead.phone){const f=document.createElement("span");f.textContent=e.lead.phone,d.push(f)}if(e.lead.rating!=null){const f=document.createElement("span");f.className="cs-pcard__rating",f.innerHTML=Ee+e.lead.rating.toFixed(1),d.push(f)}for(let f=0;f<d.length;f++)f>0&&i.appendChild(document.createTextNode(" • ")),i.appendChild(d[f]);d.length===0&&(i.textContent="—");const p=document.createElement("div");p.className="cs-pcard__scorebar";const u=document.createElement("div");u.className="cs-pcard__bar";const c=document.createElement("div");c.className="cs-pcard__barfill",c.style.width=`${n.total}%`,u.appendChild(c);const l=document.createElement("div");l.className="cs-pcard__score",l.innerHTML=`${n.total}<small>/100</small>`,p.append(u,l);const m=document.createElement("div");m.className="cs-pcard__actions";const h=document.createElement("button");h.type="button",h.className="cs-pcard__btn cs-pcard__lead",h.innerHTML=(this.selected.has(e.key)?L:T)+'<span data-role="lead-label">Lead</span>',h.addEventListener("click",()=>{this.used.has(e.key)||this.noInterest.has(e.key)||this.toggleControl(e.key)});const g=document.createElement("button");return g.type="button",g.className="cs-pcard__btn cs-pcard__site",g.title="Abrir site",g.innerHTML=V,e.lead.website?g.addEventListener("click",f=>{f.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):g.disabled=!0,m.append(h,g),t.append(r,i,p,m),this.updateCard(t,e),t}updateCard(e,t){const n=e.querySelector(".cs-pcard__lead");if(!n)return;const r=n.querySelector('[data-role="lead-label"]');if(this.noInterest.has(t.key)){n.classList.add("nointerest"),n.disabled=!0,r&&(r.textContent="Sem interesse");return}if(this.used.has(t.key)){n.classList.add("used"),n.disabled=!0,r&&(r.textContent="Importado");return}n.classList.toggle("on",this.selected.has(t.key)),n.innerHTML=(this.selected.has(t.key)?L:T)+'<span data-role="lead-label">Lead</span>'}syncAll(){this.updateCounts(),this.renderControls(),this.renderBalloonList()}updateCounts(){if(!this.listEl)return;if(this.listEl.querySelectorAll(".cs-pcard").forEach(t=>{const n=t.dataset.key,r=n?this.found.find(a=>a.key===n):void 0;r&&this.updateCard(t,r)}),this.countEl){const t=this.found.length,n=this.selected.size;this.countEl.innerHTML=`<b>${t}</b> capturados · <b>${n}</b> selecionados`}}toggleBalloon(e){var n;if(e&&this.floatBtn){this.restoreBalloon();return}const t=e??!((n=this.balloon)!=null&&n.classList.contains("open"));if(!this.balloon||!document.body.contains(this.balloon)){t&&this.ensureBalloon();return}this.balloon.classList.toggle("open",t),t?this.renderBalloonList():this.ensureLauncher()}clampElement(e){if(!document.body.contains(e))return;const t=12,n=e.offsetWidth||0,r=e.offsetHeight||0,a=Math.max(0,window.innerWidth-t-n),o=Math.max(0,window.innerHeight-t-r),i=parseFloat(e.style.right),d=parseFloat(e.style.top);if(!Number.isFinite(i)||!Number.isFinite(d))return;const p=Math.min(Math.max(0,i),a),u=Math.min(Math.max(0,d),o);(p!==i||u!==d)&&(e.style.right=`${p}px`,e.style.top=`${u}px`,e.style.left="",e.style.bottom="",this.savePosition(e))}positionBalloon(){if(!this.balloon)return;const e=this.readPosition();this.balloon.style.right=`${Math.max(12,e.right)}px`,this.balloon.style.top=`${Math.max(12,e.top)}px`,this.clampElement(this.balloon)}refreshCards(){if(this.clearedSession)return;const e=document.querySelectorAll(D()),t=new Set;for(const n of Array.from(e)){const r=O(n),a=n.href,o=pe(n,r);if(!o)continue;const i=ce(a),d=i||a;if(!i&&!a||t.has(d))continue;t.add(d);const p=this.found.find(u=>u.key===d);if(p){p.host=p.host&&document.body.contains(p.host)?p.host:r,p.lead.name=o;continue}this.found.push({lead:this.parseCard(r,o,a,i),host:r,key:d,control:null})}this.checkUsed()}async checkUsed(){const e=this.cfg??await x();if(!e.extensionKey||!e.ownerUserId)return;const t=this.found.map(n=>n.lead.place_id).filter(n=>!!n);if(t.length!==0)try{const n=await X(e,t);this.used=new Set(n.used);const r=Date.now();this.noInterest=new Set(Object.entries(n.noInterest).filter(([,a])=>a&&new Date(a).getTime()>r).map(([a])=>a)),this.syncAll()}catch{}}prune(){this.found=this.found.filter(e=>e.host&&document.body.contains(e.host))}parseCard(e,t,n,r){const a=((e==null?void 0:e.innerText)||"")??"",o=n.match(/!3d([-\d.]+)!4d([-\d.]+)/);return{name:t,phone:ue(e,a),category:me(a,t),website:fe(e),address:he(e),city:null,state:null,rating:xe(a),reviews:ve(a),latitude:o?parseFloat(o[1]):null,longitude:o?parseFloat(o[2]):null,place_id:r,instagram:ge(e),facebook:be(e)}}async promptConfig(){const e=this.cfg??await x();alert(e.extensionKey&&e.ownerUserId?"Extensão vinculada à sua conta Vyntra ✓":"Esta extensão não está vinculada a uma conta. Baixe novamente a extensão no painel Vyntra.")}async doImport(e){if(this.cfg=this.cfg??await x(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const t=this.found.filter(r=>!this.used.has(r.key)&&this.selected.has(r.key)).map(r=>r.lead).slice(0,50);if(t.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const n=e.innerHTML;e.disabled=!0,e.textContent="Importando…";try{let r=0;const a=await F(this.cfg,t,(o,i)=>{r=o,e.textContent=`${o}/${i}…`});console.log("[IMPORT] Resultado completo:",{ok:a.ok,failed:a.failed,firstError:a.firstError,errors:a.errors}),e.textContent=a.failed===0?"✓":`${a.ok} ok, ${a.failed} falharam`,a.failed===0?(b(a.ok>0?`✅ ${a.ok} lead(s) importado(s)!`:"Nenhum lead novo para importar."),this.selected.clear()):b(`⚠️ ${a.ok} ok, ${a.failed} falharam${a.firstError?`: ${a.firstError}`:""}`,"warn"),this.checkUsed(),this.syncAll(),setTimeout(()=>{e.innerHTML=n,e.disabled=!1},2e3)}catch(r){e.textContent=`Erro: ${r}`,setTimeout(()=>{e.innerHTML=n,e.disabled=!1},3e3)}}async doDelete(e){if(this.cfg=this.cfg??await x(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const t=this.found.filter(r=>this.selected.has(r.key)&&r.lead.place_id).map(r=>r.lead.place_id);if(t.length===0){alert("Selecione pelo menos um lead para excluir.");return}if(!confirm(`Excluir ${t.length} lead(s) do banco?`))return;const n=e.innerHTML;e.disabled=!0,e.innerHTML="Excluindo…";try{const r=await Q(this.cfg,t);if(r.failed===0){b(`🗑️ ${r.ok} lead(s) excluído(s)!`);for(const a of t)this.used.delete(a);this.selected.clear()}else b(`⚠️ ${r.ok} ok, ${r.failed} falharam ao excluir`,"warn");this.checkUsed(),this.syncAll()}catch(r){b(`Erro ao excluir: ${r}`,"warn")}finally{e.innerHTML=n,e.disabled=!1}}confirmClear(){return new Promise(e=>{const t=document.createElement("div");t.className="cs-modal";const n=document.createElement("div");n.className="cs-modal__card";const r=document.createElement("div");r.className="cs-modal__title",r.textContent="Limpar leads capturados";const a=document.createElement("div");a.className="cs-modal__text",a.textContent="Tem certeza que deseja remover todos os leads capturados desta sessão? Leads já importados para o VYNTRA não serão afetados.";const o=document.createElement("div");o.className="cs-modal__actions";const i=document.createElement("button");i.type="button",i.className="cs-modal__btn cs-modal__btn--ghost",i.textContent="Cancelar",i.addEventListener("click",()=>{t.remove(),e()});const d=document.createElement("button");d.type="button",d.className="cs-modal__btn cs-modal__btn--danger",d.textContent="Limpar leads",d.addEventListener("click",()=>{t.remove(),this.clearLocal(),e()}),o.append(i,d),n.append(r,a,o),t.append(n),document.body.appendChild(t),requestAnimationFrame(()=>t.classList.add("cs-open"))})}clearLocal(){this.clearedSession=!0,this.found=[],this.selected.clear(),this.lastMatched=[],this.resultPanel&&(this.resultPanel.style.display="none"),this.syncAll(),b("✓ Leads removidos")}}const Y=()=>{const s=window.location.hostname;/(^|\.)google\.(com|com\.br|[a-z.]+)\/maps\//.test(window.location.href)||s.startsWith("maps.google")?new le().init():K(async()=>{const{GlobalScanner:t}=await import("./global-B7KyeZEN.js");return{GlobalScanner:t}},__vite__mapDeps([0,1])).then(({GlobalScanner:t})=>{new t().init()})};typeof window<"u"&&Y();function Se(){Y()}function D(){return'a[href*="/maps/place/"]'}function ce(s){const e=s.match(/(?:^|[?&])place_id=([^&]+)/);return e?decodeURIComponent(e[1]):null}function O(s){let e=s.parentElement;for(let t=0;t<9&&e&&e.tagName!=="BODY"&&e.getAttribute("role")!=="feed";t++){if(e.getAttribute("role")==="article"||e.querySelector('span[aria-label*="stars"], span[aria-label*="avalia"], span[aria-label*="estrela"]')||e.querySelector('a[href*="/maps/place/"]'))return e;e=e.parentElement}return s.closest('div[role="article"], [role="article"]')??s}function de(s){let e=s.parentElement;for(;e&&e.tagName!=="BODY"&&e.tagName!=="HTML";){const t=getComputedStyle(e);if(["auto","scroll"].includes(t.overflowY)||t.overflowY==="clip"&&["auto","scroll"].includes(t.overflow))return e;e=e.parentElement}return document.scrollingElement}function pe(s,e){const n=(s.textContent||"").split(/\s+/).filter(Boolean);if(n.length>0&&n.length<14)return n.slice(0,6).join(" ");const r=s.querySelector('h3, [role="heading"], [style*="font"]'),a=((r==null?void 0:r.textContent)||"").trim();return a?a.split(`
`)[0]:e&&(e.textContent||"").trim().split(`
`)[0]||null}function ue(s,e){const t=s==null?void 0:s.querySelector('a[href^="tel:"]');if(t)return t.href.replace("tel:","").trim();const n=e.match(/\(\d{2,3}\)\s?\d[\d\s-]{7,}/);return n?n[0].replace(/\s+/g," ").trim():null}function me(s,e){for(const t of s.split(`
`)){const n=t.trim();if(n&&n!==e&&n.length<40&&!/\d/.test(n)&&!n.startsWith("★")&&!/^\d/.test(n))return n}return null}function fe(s){if(!s)return null;const e=['a[data-tooltip="Abrir site"]','a[data-tooltip="Website"]','a[aria-label*="Abrir site"]','a[href]:not([href^="tel:"]):not([href*="/maps/place/"]):not([href^="http://www.google.com/maps"])'];for(const r of e){const a=s.querySelector(r),o=a==null?void 0:a.href;if(o&&o.startsWith("http"))return o.split("&place_id")[0]}const t=s.querySelector('a[href^="http"]'),n=t==null?void 0:t.href;return n&&n.startsWith("http")&&!n.includes("/maps/place/")?n.split("&")[0]:null}function he(s){var t;const e=s==null?void 0:s.querySelector('button[data-tooltip="Endereço"], div[class*="address"], span[data-type="address"]');return((t=e==null?void 0:e.textContent)==null?void 0:t.trim())||null}function ge(s){if(!s)return null;const e=['a[data-tooltip*="Instagram" i]','a[aria-label*="Instagram" i]','a[href*="instagram.com/"]','a[href*="instagram.com"]'];for(const r of e){const a=s.querySelector(r),o=a==null?void 0:a.href;if(o&&/instagram\.com/i.test(o))return W(o)}const n=(s.innerText||"").match(/instagram\.com\/[A-Za-z0-9_.\-]+/i);return n?`https://www.${n[0].toLowerCase()}`:null}function be(s){if(!s)return null;const e=['a[data-tooltip*="Facebook" i]','a[aria-label*="Facebook" i]','a[href*="facebook.com/"]','a[href*="fb.com/"]'];for(const t of e){const n=s.querySelector(t),r=n==null?void 0:n.href;if(r&&/facebook\.com|fb\.com/i.test(r))return W(r)}return null}function W(s){try{const e=new URL(s);return`${e.protocol}//${e.host}${e.pathname.replace(/\/$/,"")}`}catch{return s.split("?")[0]}}function xe(s){const e=s.match(/([\d.]+)[\s]*[★✩]/);return e?parseFloat(e[1]):null}function ve(s){const e=s.match(/\(([\d.,]+)\)/);return e?parseInt(e[1].replace(/[^\d]/g,""),10):null}function ye(){if(document.getElementById("consecom-css"))return;const s=document.createElement("style");s.id="consecom-css",s.textContent=ie,document.head.appendChild(s)}function b(s,e="ok"){var r;const t="consecom-toast";(r=document.getElementById(t))==null||r.remove();const n=document.createElement("div");n.id=t,n.className="consecom-toast"+(e==="warn"?" cs-warn":""),n.textContent=s,document.body.appendChild(n),window.setTimeout(()=>{n.classList.add("cs-show")},20),window.setTimeout(()=>n.remove(),4e3)}function z(s){return new Promise(e=>window.setTimeout(e,s))}const _e='<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z"/></svg>',V='<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm2.5 16c-.8 1.3-1.6 2-2.5 2s-1.7-.7-2.5-2c-.7-1.2-1.2-2.8-1.4-4.5h7.8c-.2 1.7-.7 3.3-1.4 4.5zM7.8 11.5c.2-1.7.7-3.3 1.4-4.5.8-1.3 1.6-2 2.5-2s1.7.7 2.5 2c.7 1.2 1.2 2.8 1.4 4.5H7.8zM12 4c.5.7.9 1.6 1.2 2.6h-2.4C10.6 5.6 11.2 4.6 12 4zm-3.1 7c-.1.5-.1 1 0 1.5H5.9a8 8 0 0 1 0-3h3c-.1.5-.1 1 0 1.5zm-1.6 3h3c.1 1.5.4 2.9.9 4-.9-.4-1.6-.9-2.3-1.6-.5-.6-1-1.5-1.6-2.4zM15.1 17c.7.7 1.4 1.2 2.3 1.6-.5-1.1-.8-2.5-.9-4h3a8 8 0 0 1-.9 3c-.5.5-1 .9-1.6 1.2-.6.3-1.3.5-1.9.6v-2.4zm3.6-4.5h-3.1c0-.5 0-1 .1-1.5h3a8 8 0 0 1 0 3h-3c0-.5-.1-1-.1-1.5zM7.1 7c-.7-.7-1.4-1.2-2.3-1.6.5 1.1.8 2.5.9 4h-3a8 8 0 0 1 .9-3c.5-.5 1-.9 1.6-1.2.6-.3 1.3-.5 1.9-.6V7zm0 1.5v2.4c.5 0 1 .1 1.5.1h1.6c-.1-1.4-.4-2.7-.9-3.8-.7.3-1.4.8-2.2 1.3zM12 20c-.5-.7-.9-1.6-1.2-2.6h2.4c-.3 1-.9 1.9-1.2 2.6z"/></svg>',L='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',T='<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',we='<svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm8.9-3.3a7.5 7.5 0 0 0 0-1.5l2-1.6-2-3.4-2.5 1a7.7 7.7 0 0 0-1.7-1L16 1.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.5 7.5 0 0 0 0 1.5l-2 1.6 2 3.4 2.5-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6zM12 16.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>',Ee='<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.9-5 4.7 1.3 6.8L12 17.8 5.9 20.7l1.3-6.8-5-4.7 6.9-.9z"/></svg>',ke='<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>',U='<svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>';export{le as M,F as a,z as b,Se as c,ye as i,b as s};
