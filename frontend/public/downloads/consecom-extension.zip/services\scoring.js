/** Maps a funnel status to a base engagement weight. */
const STATUS_BASE = {
    novo: 5,
    na_fila: 8,
    enviado: 15,
    conversando: 35,
    remarketing: 22,
    sem_interesse: 2,
    reuniao_marcada: 65,
    reuniao_cancelada: 25,
    fechado: 95,
    nao_fechado: 40,
};
export function bandOf(score) {
    if (score <= 20)
        return 'baixa_prioridade';
    if (score <= 40)
        return 'potencial_baixo';
    if (score <= 60)
        return 'interessante';
    if (score <= 80)
        return 'qualificado';
    return 'alta_prioridade';
}
export function computeLeadScore(input) {
    const factors = [];
    let score = STATUS_BASE[input.status ?? 'novo'] ?? 5;
    factors.push(`status:${input.status ?? 'novo'}=${score}`);
    if (input.hasConversation) {
        score += 10;
        factors.push('conversa_ativa=+10');
    }
    const msgs = Math.min(input.messagesCount, 20);
    if (msgs > 0) {
        const bonus = Math.min(msgs * 1.5, 15);
        score += bonus;
        factors.push(`mensagens=${msgs}=+${bonus.toFixed(1)}`);
    }
    if (input.problemIdentified) {
        score += 12;
        factors.push('problema_identificado=+12');
    }
    if (input.interestLevel === 'alto') {
        score += 8;
        factors.push('interesse_alto=+8');
    }
    else if (input.interestLevel === 'medio') {
        score += 4;
        factors.push('interesse_medio=+4');
    }
    if (input.meetingBooked) {
        score += 20;
        factors.push('reuniao_marcada=+20');
    }
    if (input.saleStatus === 'venda') {
        score += 25;
        factors.push('venda=+25');
    }
    score = Math.max(0, Math.min(100, Math.round(score)));
    return { score, band: bandOf(score), factors };
}
//# sourceMappingURL=scoring.js.map