import{g as N,a as y,s as q}from"./config-6cNGcIy7.js";async function H(a,e){const t=N(a);if(!t)return{ok:0,failed:e.length};let n=0,r=0;for(const s of e){const{error:o}=await t.from("leads").delete().eq("place_id",s);o?r++:n++}return{ok:n,failed:r}}async function A(a,e,t,n){const r=N(a);if(!r)return{ok:0,failed:e.length,firstError:"Configure a URL e a chave anon do Supabase."};let s=null;if(e.length>0){const{data:i,error:m}=await r.from("capture_sessions").insert({imported_by:"extension"}).select("id").single();!m&&i&&(s=i.id)}const o=(n==null?void 0:n.source)??"google_maps",c=(n==null?void 0:n.sourceDetail)??"vyntra_prospector",p=(n==null?void 0:n.prospectedAt)??new Date().toISOString();let d=0,u=0,l;for(let i=0;i<e.length;i++){const m=e[i],f={name:m.name||null,phone:m.phone||null,category:m.category||null,website:m.website||null,address:m.address||null,city:m.city||null,state:m.state||null,rating:m.rating,reviews:m.reviews,latitude:m.latitude,longitude:m.longitude,place_id:m.place_id||null,niche:"maps",session_id:s,source:o,source_detail:c,instagram:m.instagram||null,facebook:m.facebook||null,has_website:!!m.website,prospected_at:p};n!=null&&n.tags&&(f.tags=n.tags),n!=null&&n.prospectFilters&&(f.prospect_filters=n.prospectFilters),(n==null?void 0:n.score)!=null&&(f.score=n.score),n!=null&&n.scoreFactors&&(f.score_factors=n.scoreFactors),(n==null?void 0:n.serviceInterest)!=null&&(f.service_interest=n.serviceInterest);const{error:b}=await r.from("leads").upsert(f,{onConflict:"place_id",ignoreDuplicates:!1});b?(u++,l||(l=b.message)):d++,t==null||t(i+1,e.length)}return{ok:d,failed:u,firstError:l}}function L(a){let e=0;a.rating!=null&&a.rating>0&&(e=Math.min(45,Math.round(a.rating/5*45)));let t=0;a.reviews!=null&&a.reviews>0&&(t=Math.min(30,Math.round(Math.log10(a.reviews+1)/Math.log10(1e4)*30)));const n=a.website?10:0,r=a.phone?10:0,s=a.category?5:0,o=Math.max(0,Math.min(100,e+t+n+r+s)),c=F(o);return{total:o,band:c,label:D[c],parts:{rating:e,reviews:t,website:n,phone:r,category:s}}}const D={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Oportunidade média",baixa:"Baixa oportunidade",nenhuma:"Sem dados"};function F(a){return a>=90?"alta":a>=70?"boa":a>=50?"media":a>=1?"baixa":"nenhuma"}function U(a){return"cs-band-"+a}const O=[{id:"sem_site",label:"Sem site",cat:"site",value:"sem_site",accent:"#f87171"},{id:"alta",label:"Alta oportunidade",cat:"score",value:"alta",accent:"#10b981"},{id:"site_ruim",label:"Site ruim",cat:"site",value:"site_ruim",accent:"#f59e0b"},{id:"poucas_avaliacoes",label:"Poucas avaliações",cat:"qualify",value:"poucas_avaliacoes",accent:"#a855f7"},{id:"nota_baixa",label:"Nota baixa",cat:"qualify",value:"nota_baixa",accent:"#f87171"},{id:"sem_presenca_digital",label:"Sem presença digital",cat:"digital",value:"sem_presenca_digital",accent:"#64748b"},{id:"tem_telefone",label:"Tem telefone",cat:"qualify",value:"tem_telefone",accent:"#22c55e"},{id:"sem_instagram",label:"Sem Instagram",cat:"digital",value:"sem_instagram",accent:"#ec4899"},{id:"sem_whatsapp",label:"Sem WhatsApp",cat:"digital",value:"sem_whatsapp",accent:"#f87171"},{id:"tem_whatsapp",label:"Tem WhatsApp",cat:"digital",value:"tem_whatsapp",accent:"#22c55e"},{id:"tem_site",label:"Tem site",cat:"site",value:"site_bom",accent:"#22c55e"},{id:"boa",label:"Boa oportunidade",cat:"score",value:"boa",accent:"#84cc16"},{id:"media",label:"Média oportunidade",cat:"score",value:"media",accent:"#f59e0b"},{id:"baixa",label:"Baixa oportunidade",cat:"score",value:"baixa",accent:"#f87171"}],V={site:[],digital:[],qualify:[],minRating:null,minReviews:null,scoreBands:[],service:"todos",activeChips:new Set};function T(a,e){if(e.site.length>0&&!W(a,e.site)||e.digital.length>0&&!Y(a,e.digital)||e.qualify.length>0&&!j(a,e.qualify)||e.minRating!=null&&e.minRating>0&&(a.rating==null||a.rating<e.minRating)||e.minReviews!=null&&e.minReviews>0&&(a.reviews==null||a.reviews<e.minReviews))return!1;if(e.scoreBands.length>0){const t=L(a);if(t.band==="nenhuma"||!e.scoreBands.includes(t.band))return!1}return!0}function W(a,e){const t=!!a.website;for(const n of e)switch(n){case"sem_site":if(!t)return!0;break;case"site_bom":case"site_profissional":case"site_ruim":case"site_desatualizado":case"site_nao_responsivo":case"site_lento":case"site_amador":case"site_quebrado":case"site_problemas":if(t)return!0;break}return!1}function Y(a,e){const t=!!a.instagram,n=!!a.facebook,r=!!a.whatsapp;for(const s of e)switch(s){case"sem_instagram":if(!t)return!0;break;case"instagram_encontrado":if(t)return!0;break;case"sem_facebook":if(!n)return!0;break;case"sem_presenca_digital":if(!t&&!n&&!r)return!0;break;case"sem_whatsapp":if(!r)return!0;break;case"tem_whatsapp":if(r)return!0;break;case"instagram_pouco_ativo":case"instagram_sem_link_site":if(t)return!0;break}return!1}function j(a,e){for(const t of e)switch(t){case"tem_telefone":if(a.phone)return!0;break;case"tem_site":if(a.website)return!0;break;case"poucas_avaliacoes":if(a.reviews==null||a.reviews<10)return!0;break;case"muitas_avaliacoes":if(a.reviews!=null&&a.reviews>=100)return!0;break;case"nota_baixa":if(a.rating==null||a.rating<4)return!0;break}return!1}function K(a){const e=[],t={sem_site:"Sem site",site_ruim:"Site ruim",site_desatualizado:"Site desatualizado",site_nao_responsivo:"Site não responsivo",site_lento:"Site lento",site_amador:"Site amador",site_quebrado:"Site quebrado",site_problemas:"Site com problemas",site_bom:"Site bom",site_profissional:"Site profissional"},n={sem_instagram:"Sem Instagram",instagram_encontrado:"Instagram encontrado",instagram_pouco_ativo:"Instagram pouco ativo",instagram_sem_link_site:"Instagram sem link para site",sem_facebook:"Sem Facebook",sem_presenca_digital:"Sem presença digital",sem_whatsapp:"Sem WhatsApp",tem_whatsapp:"Tem WhatsApp"},r={tem_telefone:"Tem telefone",poucas_avaliacoes:"Poucas avaliações",nota_baixa:"Nota baixa",muitas_avaliacoes:"Muitas avaliações",tem_site:"Tem site"};for(const o of a.site)e.push(t[o]);for(const o of a.digital)e.push(n[o]);for(const o of a.qualify)e.push(r[o]);a.minRating!=null&&a.minRating>0&&e.push(`${a.minRating.toFixed(1)}+ estrelas`),a.minReviews!=null&&a.minReviews>0&&e.push(`${a.minReviews}+ avaliações`);const s={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Média oportunidade",baixa:"Baixa oportunidade"};for(const o of a.scoreBands)e.push(s[o]);return e}const Q=`/* ===== Vyntra Prospector — tema escuro roxo ===== */\r
:root {\r
  --vy-bg: #10071d;\r
  --vy-panel: #160b28;\r
  --vy-card: #1d1030;\r
  --vy-border: rgba(255, 255, 255, 0.07);\r
  --vy-text: #e9e4f4;\r
  --vy-muted: #8d82a8;\r
  --vy-accent: #8b5cf6;\r
  --vy-accent2: #a855f7;\r
  --vy-gradient: linear-gradient(135deg, #8b5cf6, #a855f7);\r
}\r
\r
/* ===== Bolha flutuante Vyntra (arrastável) ===== */\r
.consecom-bubble {\r
  position: fixed;\r
  z-index: 2147483647;\r
  width: 54px;\r
  height: 54px;\r
  border-radius: 50%;\r
  background: var(--vy-gradient);\r
  color: #fff;\r
  cursor: grab;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  box-shadow: 0 8px 28px rgba(139, 92, 246, 0.5);\r
  user-select: none;\r
  touch-action: none;\r
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;\r
}\r
.consecom-bubble:active { cursor: grabbing; }\r
.consecom-bubble__icon {\r
  font-size: 24px;\r
  font-weight: 800;\r
  line-height: 1;\r
  font-style: italic;\r
}\r
.consecom-bubble__count {\r
  position: absolute;\r
  top: -6px;\r
  right: -6px;\r
  min-width: 20px;\r
  height: 20px;\r
  padding: 0 5px;\r
  border-radius: 999px;\r
  background: #ef4444;\r
  border: 2px solid #fff;\r
  font-size: 11px;\r
  font-weight: 700;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  box-sizing: border-box;\r
}\r
\r
/* ===== Painel lateral Vyntra (sidebar fixa à esquerda) ===== */\r
.consecom-balloon {\r
  position: fixed;\r
  z-index: 2147483646;\r
  top: 0;\r
  right: 0;\r
  bottom: 0;\r
  width: 380px;\r
  max-width: 94vw;\r
  max-height: 100vh;\r
  background: var(--vy-panel);\r
  border-left: 1px solid var(--vy-border);\r
  display: flex;\r
  flex-direction: column;\r
  opacity: 0;\r
  transform: translateX(110%);\r
  pointer-events: none;\r
  transition: transform 0.24s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.18s ease;\r
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;\r
  box-shadow: -24px 0 60px rgba(0, 0, 0, 0.45);\r
}\r
.consecom-balloon.open {\r
  opacity: 1;\r
  transform: translateX(0);\r
  pointer-events: auto;\r
}\r
\r
.cs-panel__header {\r
  display: flex;\r
  align-items: center;\r
  gap: 11px;\r
  padding: 16px 16px 12px;\r
  border-bottom: 1px solid var(--vy-border);\r
}\r
.cs-panel__logo {\r
  width: 40px;\r
  height: 40px;\r
  border-radius: 12px;\r
  background: var(--vy-gradient);\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  font-weight: 800;\r
  font-size: 20px;\r
  font-style: italic;\r
  color: #fff;\r
  flex: 0 0 auto;\r
}\r
.cs-panel__titles { min-width: 0; }\r
.cs-panel__name { font-size: 15px; font-weight: 800; color: var(--vy-text); letter-spacing: -0.01em; }\r
.cs-panel__tag { font-size: 11px; color: var(--vy-muted); margin-top: 1px; }\r
\r
.cs-panel__search { padding: 12px 16px; display: flex; flex-direction: column; gap: 8px; }\r
.cs-panel__input {\r
  width: 100%;\r
  padding: 10px 12px;\r
  background: rgba(0, 0, 0, 0.28);\r
  border: 1px solid var(--vy-border);\r
  border-radius: 10px;\r
  color: var(--vy-text);\r
  font-size: 13px;\r
  font-family: inherit;\r
  outline: none;\r
  transition: border-color 0.15s;\r
}\r
.cs-panel__input:focus { border-color: var(--vy-accent); }\r
.cs-panel__input::placeholder { color: #6d6288; }\r
.cs-panel__loc {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  font-size: 11.5px;\r
  color: var(--vy-muted);\r
}\r
.cs-panel__loc svg { width: 13px; height: 13px; fill: currentColor; }\r
\r
.cs-prospect {\r
  margin: 2px 16px 12px;\r
  padding: 13px;\r
  border: none;\r
  border-radius: 12px;\r
  background: var(--vy-gradient);\r
  color: #fff;\r
  font-weight: 800;\r
  font-size: 14px;\r
  letter-spacing: 0.06em;\r
  font-family: inherit;\r
  cursor: pointer;\r
  transition: transform 0.12s, filter 0.15s;\r
  box-shadow: 0 10px 26px rgba(139, 92, 246, 0.35);\r
}\r
.cs-prospect:hover:not(:disabled) { filter: brightness(1.08); transform: translateY(-1px); }\r
.cs-prospect:active:not(:disabled) { transform: translateY(0); }\r
.cs-prospect:disabled { opacity: 0.55; cursor: default; }\r
\r
/* ===== Lista de cards ===== */\r
.cs-panel__list {\r
  flex: 1;\r
  overflow-y: auto;\r
  padding: 4px 12px 12px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 8px;\r
}\r
.cs-panel__list::-webkit-scrollbar { width: 6px; }\r
.cs-panel__list::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.12); border-radius: 999px; }\r
\r
.cs-pcard {\r
  background: var(--vy-card);\r
  border: 1px solid var(--vy-border);\r
  border-radius: 12px;\r
  padding: 10px 12px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 7px;\r
  transition: border-color 0.15s, box-shadow 0.15s;\r
}\r
.cs-pcard:hover { border-color: rgba(139,92,246,0.35); box-shadow: 0 4px 14px rgba(139,92,246,0.12); }\r
\r
/* Linha 1: nome + badge + score (referência VYNTRA) */\r
.cs-pcard__top { display: flex; align-items: center; gap: 8px; min-width: 0; }\r
.cs-pcard__name {\r
  flex: 1;\r
  min-width: 0;\r
  font-size: 13.5px;\r
  font-weight: 700;\r
  color: var(--vy-text);\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
\r
/* Badge de oportunidade (direita) */\r
.cs-pcard__badge {\r
  font-size: 10px;\r
  font-weight: 700;\r
  padding: 3px 8px;\r
  border-radius: 999px;\r
  letter-spacing: 0.02em;\r
  white-space: nowrap;\r
  flex: 0 0 auto;\r
}\r
.cs-band-alta { color: #a7f3d0; background: rgba(16, 185, 129, 0.16); border: 1px solid rgba(16, 185, 129, 0.35); }\r
.cs-band-boa { color: #bbf7d0; background: rgba(34, 197, 94, 0.16); border: 1px solid rgba(34, 197, 94, 0.35); }\r
.cs-band-media { color: #fde68a; background: rgba(245, 158, 11, 0.16); border: 1px solid rgba(245, 158, 11, 0.35); }\r
.cs-band-baixa { color: #fecaca; background: rgba(248, 113, 113, 0.16); border: 1px solid rgba(248, 113, 113, 0.35); }\r
.cs-band-nenhuma { color: #94a3b8; background: rgba(100, 116, 139, 0.14); border: 1px solid rgba(100, 116, 139, 0.3); }\r
\r
/* Linha 2: meta (endereço • telefone • nota) */\r
.cs-pcard__meta {\r
  font-size: 11px;\r
  color: var(--vy-muted);\r
  display: flex;\r
  align-items: center;\r
  gap: 5px;\r
  white-space: nowrap;\r
  overflow: hidden;\r
  text-overflow: ellipsis;\r
}\r
.cs-pcard__rating {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 3px;\r
  font-size: 11px;\r
  color: #fbbf24;\r
  font-weight: 700;\r
}\r
.cs-pcard__rating svg { width: 11px; height: 11px; fill: currentColor; }\r
\r
/* Linha 3: barra de score */\r
.cs-pcard__scorebar { display: flex; align-items: center; gap: 8px; }\r
.cs-pcard__bar {\r
  flex: 1;\r
  height: 5px;\r
  border-radius: 999px;\r
  background: rgba(255, 255, 255, 0.08);\r
  overflow: hidden;\r
}\r
.cs-pcard__barfill {\r
  height: 100%;\r
  border-radius: 999px;\r
  background: var(--vy-gradient);\r
  transition: width 0.4s ease;\r
}\r
.cs-pcard__score {\r
  font-size: 11px;\r
  font-weight: 800;\r
  color: var(--vy-text);\r
  flex: 0 0 auto;\r
}\r
.cs-pcard__score small { color: var(--vy-muted); font-weight: 600; }\r
\r
/* Linha 4: ações */\r
.cs-pcard__actions { display: flex; gap: 6px; margin-top: 1px; }\r
.cs-pcard__btn {\r
  flex: 1;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 6px;\r
  padding: 8px 10px;\r
  border: none;\r
  border-radius: 9px;\r
  font-family: inherit;\r
  font-size: 12px;\r
  font-weight: 700;\r
  cursor: pointer;\r
  transition: transform 0.1s, filter 0.15s;\r
}\r
.cs-pcard__btn svg { width: 13px; height: 13px; fill: currentColor; }\r
.cs-pcard__lead {\r
  background: var(--vy-gradient);\r
  color: #fff;\r
}\r
.cs-pcard__lead:hover:not(:disabled) { filter: brightness(1.08); transform: translateY(-1px); }\r
.cs-pcard__lead.on { background: #22c55e; }\r
.cs-pcard__lead.used { background: rgba(255, 255, 255, 0.12); color: var(--vy-muted); cursor: default; }\r
.cs-pcard__lead.nointerest { background: rgba(239, 68, 68, 0.22); color: #fca5a5; }\r
.cs-pcard__site {\r
  background: rgba(255, 255, 255, 0.08);\r
  color: var(--vy-text);\r
}\r
.cs-pcard__site:hover:not(:disabled) { filter: brightness(1.15); }\r
.cs-pcard__site:disabled { opacity: 0.4; cursor: default; }\r
\r
/* ===== Rodapé do painel ===== */\r
.cs-panel__footer {\r
  border-top: 1px solid var(--vy-border);\r
  padding: 10px 12px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 6px;\r
}\r
.cs-footer__row { display: flex; gap: 6px; }\r
.cs-footer__btn {\r
  flex: 1;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 6px;\r
  padding: 9px 10px;\r
  border: none;\r
  border-radius: 9px;\r
  font-family: inherit;\r
  font-size: 12px;\r
  font-weight: 700;\r
  color: #fff;\r
  cursor: pointer;\r
  transition: transform 0.1s, filter 0.15s;\r
}\r
.cs-footer__btn svg { width: 13px; height: 13px; fill: currentColor; }\r
.cs-footer__btn:hover:not(:disabled) { filter: brightness(1.1); }\r
.cs-footer__btn:disabled { opacity: 0.55; cursor: default; }\r
.cs-foot-import { background: var(--vy-gradient); }\r
.cs-foot-all { background: rgba(255, 255, 255, 0.1); color: var(--vy-text); }\r
.cs-foot-delete { background: rgba(239, 68, 68, 0.2); color: #fda4af; }\r
.cs-foot-config { background: rgba(255, 255, 255, 0.08); color: var(--vy-muted); }\r
\r
.cs-empty {\r
  text-align: center;\r
  color: var(--vy-muted);\r
  font-size: 12px;\r
  padding: 28px 12px;\r
  line-height: 1.6;\r
}\r
\r
/* ===== Cards nativos enxutos (controles dentro dos cards do Maps) ===== */\r
.consecom-host {\r
  position: relative !important;\r
  min-width: 0 !important;\r
}\r
.consecom-host > *:not(.consecom-control) {\r
  opacity: 0 !important;\r
  pointer-events: none !important;\r
  height: 0 !important;\r
  overflow: hidden !important;\r
}\r
.consecom-control {\r
  position: relative !important;\r
  z-index: 30 !important;\r
  display: flex !important;\r
  align-items: center !important;\r
  gap: 6px !important;\r
  padding: 5px 8px !important;\r
  background: var(--vy-card) !important;\r
  border: 1px solid var(--vy-border) !important;\r
  border-radius: 8px !important;\r
  box-sizing: border-box !important;\r
  min-height: 34px !important;\r
  font-family: 'Inter', 'Segoe UI', Roboto, system-ui, sans-serif !important;\r
}\r
.consecom-control .cs-select { flex: 0 0 auto !important; }\r
.consecom-control .cs-name {\r
  flex: 1 !important;\r
  min-width: 0 !important;\r
  font-size: 12px !important;\r
  font-weight: 600 !important;\r
  color: var(--vy-text) !important;\r
  white-space: nowrap !important;\r
  overflow: hidden !important;\r
  text-overflow: ellipsis !important;\r
}\r
.consecom-control .cs-actions {\r
  display: flex !important;\r
  gap: 4px !important;\r
  flex: 0 0 auto !important;\r
}\r
.consecom-control .cs-round {\r
  width: 26px !important;\r
  height: 26px !important;\r
  border-radius: 50% !important;\r
  border: none !important;\r
  cursor: pointer !important;\r
  display: flex !important;\r
  align-items: center !important;\r
  justify-content: center !important;\r
  padding: 0 !important;\r
  background: var(--vy-gradient) !important;\r
  color: #fff !important;\r
  box-shadow: 0 1px 4px rgba(139, 92, 246, 0.4) !important;\r
  transition: transform 0.1s, background 0.15s !important;\r
}\r
.consecom-control .cs-round svg { width: 13px; height: 13px; fill: #fff; }\r
.consecom-control .cs-round:hover:not(:disabled) { filter: brightness(1.1); transform: scale(1.08); }\r
.consecom-control .cs-round:disabled { background: rgba(255, 255, 255, 0.1); box-shadow: none; cursor: default; opacity: 0.6; }\r
.consecom-control .cs-round:disabled svg { fill: #6d6288; }\r
.consecom-control .cs-select { background: transparent; border: 2px solid var(--vy-accent); color: var(--vy-accent); }\r
.consecom-control .cs-select svg { fill: var(--vy-accent); }\r
.consecom-control .cs-select.on { background: var(--vy-accent); color: #fff; }\r
.consecom-control .cs-select.on svg { fill: #fff; }\r
.consecom-control .cs-select.used { background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.12); color: #6d6288; }\r
.consecom-control .cs-select.used svg { fill: #6d6288; }\r
.consecom-control .cs-select.nointerest { background: rgba(239, 68, 68, 0.25); border-color: #ef4444; color: #fca5a5; font-weight: 700; }\r
.consecom-control .cs-badge {\r
  position: absolute !important;\r
  top: -8px !important;\r
  right: -6px !important;\r
  background: #ef4444 !important;\r
  color: #fff !important;\r
  font-size: 9px !important;\r
  font-weight: 700 !important;\r
  padding: 1px 5px !important;\r
  border-radius: 999px !important;\r
  white-space: nowrap !important;\r
  box-shadow: 0 1px 3px rgba(0,0,0,.25) !important;\r
}\r
\r
/* ===== Toast ===== */\r
.consecom-toast {\r
  position: fixed;\r
  top: 18px;\r
  left: 50%;\r
  transform: translateX(-50%) translateY(-18px);\r
  z-index: 2147483647;\r
  padding: 12px 20px;\r
  background: #160b28;\r
  color: #e9e4f4;\r
  border: 1px solid rgba(16, 185, 129, 0.5);\r
  border-radius: 12px;\r
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);\r
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;\r
  font-size: 14px;\r
  font-weight: 600;\r
  opacity: 0;\r
  transition: opacity 0.25s, transform 0.25s;\r
  pointer-events: none;\r
}\r
.consecom-toast.cs-warn { border-color: rgba(249, 115, 22, 0.6); }\r
.consecom-toast.cs-show { opacity: 1; transform: translateX(-50%) translateY(0); }\r
\r
/* ===== Prospecção Automática — Painel de filtros (chips) ===== */\r
.cs-filters { padding: 10px 14px; border-top: 1px solid var(--vy-border); display: flex; flex-direction: column; gap: 10px; }\r
.cs-filters__title {\r
  font-size: 11px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;\r
  color: var(--vy-muted);\r
}\r
.cs-chips { display: flex; flex-wrap: wrap; gap: 6px; }\r
.cs-chip {\r
  font-size: 11px; font-weight: 600; padding: 5px 10px; border-radius: 999px;\r
  background: rgba(255,255,255,0.04); color: var(--vy-text);\r
  border: 1px solid var(--vy-border); cursor: pointer;\r
  transition: all 0.15s; white-space: nowrap; font-family: 'Inter', sans-serif;\r
}\r
.cs-chip:hover { border-color: var(--vy-accent); color: var(--vy-accent2); }\r
.cs-chip--on {\r
  background: var(--vy-gradient) !important; color: #fff !important;\r
  border-color: transparent !important;\r
  box-shadow: 0 2px 8px rgba(139,92,246,0.35);\r
}\r
.cs-chip:focus-visible { outline: 2px solid var(--vy-accent); outline-offset: 1px; }\r
\r
.cs-adv { display: flex; gap: 10px; padding-top: 8px; border-top: 1px solid var(--vy-border); }\r
.cs-adv__item { display: flex; flex-direction: column; gap: 4px; flex: 1; }\r
.cs-adv__item span { font-size: 9px; font-weight: 700; color: var(--vy-muted); text-transform: uppercase; letter-spacing: 0.06em; }\r
.cs-adv__item select {\r
  background: var(--vy-card); color: var(--vy-text); border: 1px solid var(--vy-border);\r
  border-radius: 7px; padding: 6px 8px; font-size: 12px; font-family: 'Inter', sans-serif;\r
  cursor: pointer; outline: none;\r
}\r
.cs-adv__item select:focus { border-color: var(--vy-accent); }\r
\r
.cs-fgroup { margin-bottom: 4px; }\r
.cs-fgroup__h {\r
  font-size: 10px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase;\r
  color: var(--vy-accent2); margin-bottom: 4px;\r
}\r
.cs-radio { display: flex; flex-wrap: wrap; gap: 6px; }\r
.cs-radio__item {\r
  display: flex; align-items: center; gap: 5px; padding: 4px 9px;\r
  border: 1px solid var(--vy-border); border-radius: 999px;\r
  font-size: 11px; cursor: pointer; color: var(--vy-text); background: rgba(255,255,255,0.04);\r
  transition: all 0.15s;\r
}\r
.cs-radio__item:hover { border-color: var(--vy-accent); }\r
.cs-radio__item input { accent-color: var(--vy-accent); }\r
.cs-radio__item:has(input:checked) {\r
  border-color: var(--vy-accent); background: rgba(139,92,246,0.18); color: var(--vy-accent2);\r
}\r
\r
/* ===== Resultado da prospecção (Alex) ===== */\r
.cs-result { padding: 12px 14px; }\r
.cs-result__card {\r
  background: var(--vy-card); border: 1px solid var(--vy-border); border-radius: 14px;\r
  padding: 14px; animation: cs-fadein 0.3s ease;\r
}\r
@keyframes cs-fadein { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }\r
.cs-result__head { text-align: center; margin-bottom: 10px; }\r
.cs-result__big { font-size: 34px; font-weight: 800; color: var(--vy-accent2); line-height: 1; }\r
.cs-result__sub { font-size: 12px; color: var(--vy-muted); margin-top: 2px; }\r
.cs-result__head--ok .cs-result__title { color: #10b981; font-weight: 800; letter-spacing: 0.04em; }\r
.cs-result__stats { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--vy-muted); margin-bottom: 10px; }\r
.cs-result__stats span { color: var(--vy-text); font-weight: 700; }\r
.cs-result__dup { color: #f59e0b; }\r
.cs-alex {\r
  display: flex; gap: 10px; background: rgba(139,92,246,0.08); border: 1px solid rgba(139,92,246,0.2);\r
  border-radius: 10px; padding: 10px; margin-bottom: 12px;\r
}\r
.cs-alex__avatar { font-size: 18px; }\r
.cs-alex__name { font-size: 12px; font-weight: 700; color: var(--vy-accent2); }\r
.cs-alex__msg { font-size: 12px; color: var(--vy-text); line-height: 1.4; margin-top: 2px; }\r
.cs-result__cta {\r
  width: 100%; padding: 13px; border: none; border-radius: 12px;\r
  background: var(--vy-gradient); color: #fff; font-size: 14px; font-weight: 800;\r
  letter-spacing: 0.04em; cursor: pointer; transition: transform 0.15s, box-shadow 0.15s;\r
  font-family: 'Inter', sans-serif;\r
}\r
.cs-result__cta:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(139,92,246,0.45); }\r
.cs-result__cta:disabled { opacity: 0.7; cursor: default; transform: none; }\r
.cs-result__cta--ghost { background: transparent; border: 1px solid var(--vy-border); color: var(--vy-text); }\r
.cs-result__empty { text-align: center; color: var(--vy-muted); font-size: 13px; padding: 12px; }\r
\r
/* Relatório final */\r
.cs-result__lines { list-style: none; padding: 0; margin: 8px 0; font-size: 12px; color: var(--vy-text); }\r
.cs-result__lines li { padding: 3px 0; border-bottom: 1px dashed rgba(255,255,255,0.05); }\r
.cs-result__crit { margin: 8px 0; }\r
.cs-result__crit-h { font-size: 10px; font-weight: 700; text-transform: uppercase; color: var(--vy-muted); margin-bottom: 4px; }\r
.cs-result__tags { display: flex; flex-wrap: wrap; gap: 5px; }\r
.cs-result__chip {\r
  font-size: 11px; padding: 3px 8px; border-radius: 999px;\r
  background: rgba(139,92,246,0.15); color: var(--vy-accent2); border: 1px solid rgba(139,92,246,0.3);\r
}\r
.cs-result__progress { font-size: 12px; color: var(--vy-muted); text-align: center; padding: 8px; }\r
`;class X{constructor(){this.cfg=null,this.rtChannel=null,this.found=[],this.selected=new Set,this.used=new Set,this.noInterest=new Set,this.scanning=!1,this.bubble=null,this.balloon=null,this.bCount=null,this.listEl=null,this.locEl=null,this.lastQuery="",this.dragging=!1,this.suppressClick=!1,this.filters={...V},this.filtersPanel=null,this.resultPanel=null,this.prospecting=!1,this.prospectCancel=!1,this.lastMatched=[],this.debounceUsed=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.checkUsed()},400))}})(),this.debounceScan=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.scan()},350))}})()}async init(){this.cfg=await y(),le(),this.ensureBubble(),this.observeDom(),this.scan("force"),window.addEventListener("click",e=>{var t,n;(t=this.balloon)!=null&&t.classList.contains("open")&&(this.balloon.contains(e.target)||(n=this.bubble)!=null&&n.contains(e.target)||this.toggleBalloon(!1))}),chrome.runtime.onMessage.addListener(e=>{((e==null?void 0:e.type)==="consecom:open"||(e==null?void 0:e.type)==="consecom:ping")&&this.toggleBalloon(!0)}),this.subscribeRealtime()}subscribeRealtime(){var t;(t=this.rtChannel)==null||t.unsubscribe(),this.rtChannel=null;const e=this.cfg?N(this.cfg):null;e&&(this.rtChannel=e.channel("consecom-leads-rt").on("postgres_changes",{event:"*",schema:"public",table:"leads"},()=>this.debounceUsed()).subscribe())}observeDom(){new MutationObserver(()=>this.debounceScan()).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("scroll",()=>this.debounceScan(),{passive:!0})}scan(e="scan"){if(!(this.scanning&&e!=="force")){this.scanning=!0;try{this.syncArea(),this.refreshCards(),this.prune(),this.renderControls(),this.renderBalloonList()}finally{this.scanning=!1}}}syncArea(){var n;const e=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]'),t=((e==null?void 0:e.value)||"").trim();t&&t!==this.lastQuery&&(this.lastQuery=t,this.selected.clear(),this.found=[],this.locEl&&(this.locEl.textContent=t),(n=this.balloon)!=null&&n.classList.contains("open")&&this.renderCardList()),t&&(this.lastQuery=t)}renderControls(){}makeHostSlim(e){e.classList.contains("consecom-host")||e.classList.add("consecom-host")}toggleSelected(e){this.used.has(e)||this.noInterest.has(e)||(this.selected.has(e)?this.selected.delete(e):this.selected.add(e),this.syncAll())}toggleControl(e){this.toggleSelected(e)}selectAllAvailable(){const e=this.found.filter(r=>!this.used.has(r.key)&&!this.noInterest.has(r.key)),t=Math.min(50,e.length),n=new Set;for(let r=0;r<t;r++)n.add(e[r].key);this.selected=n,this.syncAll(),g(`✅ ${this.selected.size} selecionado(s) (máx. 50 por importação)`)}clearSelection(){this.selected.clear(),this.syncAll()}buildControl(e){const t=document.createElement("div");t.className="consecom-control",t.title=e.lead.name;const n=document.createElement("button");n.type="button",n.className="cs-round cs-select",n.title="Selecionar",n.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),this.toggleControl(e.key)});const r=document.createElement("span");r.className="cs-name",r.textContent=e.lead.name,r.title=e.lead.name;const s=document.createElement("div");s.className="cs-actions";const o=document.createElement("button");o.type="button",o.className="cs-round",o.title="Abrir site",o.innerHTML=M,e.lead.website?o.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):o.disabled=!0;const c=document.createElement("button");c.type="button",c.className="cs-round",c.title="Chamar",c.innerHTML=de,e.lead.phone?c.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),window.location.href=`tel:${e.lead.phone.replace(/\s+/g,"")}`}):c.disabled=!0,s.append(o,c);const p=document.createElement("span");return p.className="cs-badge",p.textContent="Sem interesse",p.style.display="none",t.append(n,r,s,p),t}updateControl(e){var s,o;const t=(s=e.control)==null?void 0:s.querySelector(".cs-select");if(!t)return;const n=this.noInterest.has(e.key);t.classList.toggle("nointerest",n);const r=(o=e.control)==null?void 0:o.querySelector(".cs-badge");if(r&&(r.style.display=n?"block":"none"),n){t.disabled=!0,t.title="Sem interesse — não importar (6 meses)",t.innerHTML="✕";return}this.used.has(e.key)?(t.classList.add("used"),t.disabled=!0,t.title="Já importado anteriormente",t.innerHTML=w):(t.disabled=!1,t.classList.toggle("on",this.selected.has(e.key)),t.title=this.selected.has(e.key)?"Remover seleção":"Selecionar",t.innerHTML=this.selected.has(e.key)?w:S)}buildBubble(){const e=document.createElement("div");e.className="consecom-bubble",e.title="Vyntra Prospector";const t=document.createElement("span");t.className="consecom-bubble__icon",t.textContent="V";const n=document.createElement("span");return n.className="consecom-bubble__count",n.textContent="0",this.bCount=n,e.append(t,n),this.bubble=e,e.addEventListener("click",()=>{if(this.suppressClick){this.suppressClick=!1;return}this.toggleBalloon()}),this.enableDrag(e),e.style.right=localStorage.getItem("consecom-bubble-x")||"20px",e.style.top=localStorage.getItem("consecom-bubble-top")||"16px",e}ensureBubble(){if(this.bubble&&document.body.contains(this.bubble))return;const e=this.buildBubble();document.body.appendChild(e)}enableDrag(e){let t=0,n=0,r=0,s=0;const o={v:!1},c=u=>{this.dragging=!0,o.v=!1,t=u.clientX,n=u.clientY,r=e.offsetLeft,s=e.offsetTop,e.setPointerCapture(u.pointerId)},p=u=>{if(!this.dragging)return;const l=u.clientX-t,i=u.clientY-n;Math.abs(l)+Math.abs(i)>4&&(o.v=!0);const m=Math.max(0,Math.min(window.innerWidth-60,r-l)),f=Math.max(0,Math.min(window.innerHeight-60,s+i));e.style.right=`${m}px`,e.style.left="",e.style.top=`${f}px`},d=u=>{this.dragging&&(e.hasPointerCapture(u.pointerId)&&e.releasePointerCapture(u.pointerId),this.suppressClick=o.v,this.dragging=!1,localStorage.setItem("consecom-bubble-x",e.style.right),localStorage.setItem("consecom-bubble-top",e.style.top))};e.addEventListener("pointerdown",c),e.addEventListener("pointermove",p),e.addEventListener("pointerup",d),e.addEventListener("pointercancel",d)}buildBalloon(){const e=document.createElement("aside");e.className="consecom-balloon";const t=document.createElement("div");t.className="cs-panel__header";const n=document.createElement("div");n.className="cs-panel__logo",n.textContent="V";const r=document.createElement("div");r.className="cs-panel__titles";const s=document.createElement("div");s.className="cs-panel__name",s.textContent="VYNTRA";const o=document.createElement("div");o.className="cs-panel__tag",o.textContent="Prospecção Automática";const c=document.createElement("div");c.className="cs-panel__tagline",c.textContent="Encontre empresas qualificadas no Google Maps e importe os melhores leads.",r.append(s,o,c),t.append(n,r);const p=document.createElement("div");p.className="cs-panel__search";const d=document.createElement("input");d.className="cs-panel__input",d.type="text",d.placeholder="Buscar empresas",d.spellcheck=!1,d.addEventListener("keydown",B=>{var z;if(B.key==="Enter"){const C=d.value.trim();if(!C)return;const _=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]');if(_){const E=(z=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:z.set;E==null||E.call(_,C),_.dispatchEvent(new Event("input",{bubbles:!0})),_.dispatchEvent(new Event("change",{bubbles:!0})),_.focus(),_.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0}))}else this.lastQuery=C,this.selected.clear(),this.found=[],this.scan("force")}});const u=document.createElement("div");u.className="cs-panel__loc",u.innerHTML=me,this.locEl=document.createElement("span"),this.locEl.textContent="Aguardando busca…",u.append(this.locEl),p.append(d,u);const l=document.createElement("button");l.type="button",l.className="cs-prospect",l.textContent="PROSPECTAR",l.addEventListener("click",()=>void this.runProspect(l));const i=this.buildFiltersPanel();this.filtersPanel=i;const m=document.createElement("div");m.className="cs-result",m.style.display="none",this.resultPanel=m;const f=document.createElement("div");f.className="cs-panel__list",this.listEl=f;const b=document.createElement("div");b.className="cs-panel__footer";const h=document.createElement("div");h.className="cs-footer__row";const v=document.createElement("button");v.type="button",v.className="cs-footer__btn cs-foot-delete",v.innerHTML="Excluir selecionados"+fe,v.addEventListener("click",()=>void this.doDelete(v));const x=document.createElement("button");return x.type="button",x.className="cs-footer__btn cs-foot-config",x.title="Configurar Supabase",x.innerHTML="Configurar"+pe,x.addEventListener("click",()=>void this.promptConfig()),h.append(v,x),b.appendChild(h),e.append(t,p,l,i,m,f,b),this.balloon=e,e}async runProspect(e){if(!this.prospecting){this.prospecting=!0,this.prospectCancel=!1,e.disabled=!0;try{await this.runProspectStages(e),this.scan("force"),this.readFiltersFromPanel();const{matched:t,novoCount:n,existenteCount:r}=this.applyAutomaticSelection();this.renderResult(t,n,r),this.renderBalloonList()}catch(t){g(`Erro na prospecção: ${t}`,"warn")}finally{e.textContent="PROSPECTAR",e.disabled=!1,this.prospecting=!1}}}async runProspectStages(e){const t=[["Coletando resultados",320],["Aprofundando a busca",340],["Carregando mais empresas",360],["Calculando oportunidades",380]];for(const[n,r]of t){if(this.prospectCancel)break;const s=this.found.length;e.textContent=s>0?`PROSPECTANDO… ${s} resultados`:"PROSPECTANDO…",this.updateProspectProgress(),await this.scrollAndCollect(),await k(r),this.updateProspectProgress()}}async scrollAndCollect(){const e=Array.from(document.querySelectorAll(P()));if(e.length===0)return;const t=I(e[0]),n=t?J(t):null;if(!n)return;const r=this.found.length,s=Math.min(600,n.offsetHeight||400);n.scrollBy({top:s,behavior:"smooth"}),await k(340),this.scan("force"),this.found.length===r&&(n.scrollBy({top:s,behavior:"smooth"}),await k(340),this.scan("force"))}updateProspectProgress(){if(!this.resultPanel)return;const e=this.found.length,t=document.createElement("div");t.className="cs-result__progress",t.textContent=`Coletados: ${e}`,this.resultPanel.replaceChildren(t),this.resultPanel.style.display="block"}applyAutomaticSelection(){const t=this.found.filter(r=>!this.used.has(r.key)&&!this.noInterest.has(r.key)).filter(r=>T(r.lead,this.filters));this.lastMatched=t,this.selected.clear();for(const r of t)this.selected.add(r.key);const n=this.found.filter(r=>this.used.has(r.key)&&T(r.lead,this.filters));return{matched:t,novoCount:t.length,existenteCount:n.length}}buildFiltersPanel(){const e=document.createElement("div");e.className="cs-filters";const t=document.createElement("div");t.className="cs-filters__title",t.textContent="Encontrar oportunidades",e.appendChild(t);const n=document.createElement("div");n.className="cs-chips";for(const l of O){const i=document.createElement("button");i.type="button",i.className="cs-chip",i.dataset.id=l.id,i.dataset.cat=l.cat,i.dataset.value=l.value,i.dataset.accent=l.accent??"#8b5cf6",i.textContent=l.label,i.addEventListener("click",()=>{this.filters.activeChips.has(l.id)?this.filters.activeChips.delete(l.id):this.filters.activeChips.add(l.id),i.classList.toggle("cs-chip--on"),this.syncChipsFromState(i,l.accent)}),this.syncChipsFromState(i,l.accent),n.appendChild(i)}e.appendChild(n);const r=document.createElement("div");r.className="cs-adv";const s=document.createElement("label");s.className="cs-adv__item";const o=document.createElement("span");o.textContent="Nota mín.";const c=document.createElement("select");c.dataset.cat="minRating";for(const l of[0,4,4.5,4.8]){const i=document.createElement("option");i.value=String(l),i.textContent=l===0?"Qualquer":`${l.toFixed(1)}+`,c.appendChild(i)}s.append(o,c);const p=document.createElement("label");p.className="cs-adv__item";const d=document.createElement("span");d.textContent="Avaliações mín.";const u=document.createElement("select");u.dataset.cat="minReviews";for(const l of[0,10,50,100,500]){const i=document.createElement("option");i.value=String(l),i.textContent=l===0?"Qualquer":`${l}+`,u.appendChild(i)}return p.append(d,u),r.append(s,p),e.appendChild(r),e.appendChild(this.buildServiceGroup()),e}syncChipsFromState(e,t){e.classList.contains("cs-chip--on")?(e.style.borderColor=t??"#8b5cf6",e.style.background=`${t??"#8b5cf6"}22`,e.style.color="#fff"):(e.style.borderColor="",e.style.background="",e.style.color="")}buildServiceGroup(){const e=document.createElement("div");e.className="cs-fgroup cs-fgroup--svc";const t=document.createElement("div");t.className="cs-fgroup__h",t.textContent="SERVIÇO / NECESSIDADE",e.appendChild(t);const n=document.createElement("div");n.className="cs-radio";const r=[{id:"todos",label:"Todos"},{id:"site",label:"Site"},{id:"sistema",label:"Sistema"},{id:"trafego",label:"Tráfego pago"},{id:"automacao",label:"Automação"},{id:"presenca",label:"Presença digital"}];for(const s of r){const o=document.createElement("label");o.className="cs-radio__item";const c=document.createElement("input");c.type="radio",c.name="cs-service",c.value=s.id,c.dataset.cat="service",s.id==="todos"&&(c.checked=!0);const p=document.createElement("span");p.textContent=s.label,o.append(c,p),n.appendChild(o)}return e.appendChild(n),e}readFiltersFromPanel(){if(!this.filtersPanel)return;const e=[],t=[],n=[],r=[];this.filtersPanel.querySelectorAll(".cs-chip.cs-chip--on").forEach(l=>{const i=l.dataset.cat,m=l.dataset.value;!i||!m||(i==="site"?e.push(m):i==="digital"?t.push(m):i==="score"?r.push(m):i==="qualify"&&n.push(m))});let s=null,o=null;const c=this.filtersPanel.querySelector("select[data-cat=minRating]");c&&(s=parseFloat(c.value)||null);const p=this.filtersPanel.querySelector("select[data-cat=minReviews]");p&&(o=parseInt(p.value,10)||null);let d="todos";const u=this.filtersPanel.querySelector("input[name=cs-service]:checked");u&&(d=u.value),this.filters={site:e,digital:t,qualify:n,minRating:s,minReviews:o,scoreBands:r,service:d,activeChips:this.filters.activeChips}}renderResult(e,t,n){if(!this.resultPanel)return;const r=this.found.length,s=document.createElement("div");s.className="cs-result__card";const o=document.createElement("div");o.className="cs-result__head";const c=document.createElement("div");c.className="cs-result__big",c.textContent=`${t}`;const p=document.createElement("div");p.className="cs-result__sub",p.textContent=t===1?"oportunidade encontrada":"oportunidades encontradas",o.append(c,p),s.appendChild(o);const d=document.createElement("div");d.className="cs-result__stats";const u=document.createElement("div");u.innerHTML=`<span>${r}</span> analisadas`;const l=document.createElement("div");if(l.innerHTML=`<span>${t}</span> selecionadas automaticamente`,d.append(u,l),n>0){const i=document.createElement("div");i.className="cs-result__dup",i.innerHTML=`⚠ ${n} já existem na Vyntra`,d.appendChild(i)}if(s.appendChild(d),e.length>0){const i=this.buildAlexHint(e);s.appendChild(i)}if(t>0){const i=document.createElement("button");i.type="button",i.className="cs-result__cta";const m=n>0?`${t} NOVOS`:`${t} LEADS`;i.textContent=n>0?`IMPORTAR ${t} NOVOS`:`IMPORTAR ${t} LEADS`,i.addEventListener("click",()=>void this.doProspectImport(i,e,m)),s.appendChild(i)}else{const i=document.createElement("div");i.className="cs-result__empty",i.textContent="Nenhuma empresa corresponde aos critérios. Ajuste os filtros e tente novamente.",s.appendChild(i)}this.resultPanel.replaceChildren(s),this.resultPanel.style.display="block"}buildAlexHint(e){const t=document.createElement("div");t.className="cs-alex";const n=document.createElement("div");n.className="cs-alex__avatar",n.textContent="🤖";const r=document.createElement("div");r.className="cs-alex__body";const s=document.createElement("div");s.className="cs-alex__name",s.textContent="Alex";const o=document.createElement("div");o.className="cs-alex__msg";const c=e.filter(u=>L(u.lead).band==="alta").length,d=e.filter(u=>!u.lead.website).length>=e.length/2?"sem site ou com presença digital fraca":"com boa avaliação e presença consolidada";return o.textContent=`Encontrei ${e.length} empresas que parecem boas oportunidades para prospecção.`+(c>0?` ${c} delas possuem alta oportunidade.`:"")+` A maior oportunidade está em empresas ${d}.`,r.append(s,o),t.append(n,r),t}async doProspectImport(e,t,n){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const r=t.map(o=>o.lead).slice(0,50);if(r.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const s=e.textContent;e.disabled=!0;try{const o=["Google Maps"],c=this.filters.service!=="todos"?`Interesse: ${this.serviceLabel(this.filters.service)}`:null,d={source:"google_maps",sourceDetail:"vyntra_prospector",tags:c?[...o,c]:o,prospectFilters:this.filtersToSnapshot(),prospectedAt:new Date().toISOString()};let u=0;const l=await A(this.cfg,r,(i,m)=>{u=i;const f=Math.round(i/m*100);e.textContent=`Importando… ${f}%`},d);this.renderProspectReport({analyzed:this.found.length,opportunities:t.length,imported:l.ok,failed:l.failed,alreadyExists:this.countAlreadyExists(t),filtersText:K(this.filters)}),e.textContent=l.failed===0?`✓ ${l.ok} LEADS IMPORTADOS`:`${l.ok} ok, ${l.failed} falharam`,l.failed===0?(g(`✅ ${l.ok} lead(s) importado(s)!`),this.selected.clear()):g(`⚠️ ${l.ok} ok, ${l.failed} falharam`,"warn"),this.checkUsed(),this.syncAll()}catch(o){e.textContent=`Erro: ${o}`,g(`Erro ao importar: ${o}`,"warn")}finally{setTimeout(()=>{e.textContent=s,e.disabled=!1},4e3)}}countAlreadyExists(e){return e.filter(t=>this.used.has(t.key)).length}serviceLabel(e){return{todos:"Todos",site:"Site",sistema:"Sistema",trafego:"Tráfego pago",automacao:"Automação",presenca:"Presença digital"}[e]}filtersToSnapshot(){return{site:this.filters.site,digital:this.filters.digital,minRating:this.filters.minRating,minReviews:this.filters.minReviews,scoreBands:this.filters.scoreBands,service:this.filters.service,query:this.lastQuery,at:new Date().toISOString()}}renderProspectReport(e){if(!this.resultPanel)return;const t=document.createElement("div");t.className="cs-result__card cs-result__report";const n=document.createElement("div");n.className="cs-result__head cs-result__head--ok";const r=document.createElement("div");r.className="cs-result__title",r.textContent="PROSPECÇÃO CONCLUÍDA",n.appendChild(r),t.appendChild(n);const s=[`${e.analyzed} empresas analisadas`,`${e.opportunities} oportunidades encontradas`,`${e.imported} novos leads importados`,e.failed>0?`${e.failed} com erro`:null,e.alreadyExists>0?`${e.alreadyExists} já estavam na Vyntra`:null].filter(Boolean),o=document.createElement("ul");o.className="cs-result__lines";for(const p of s){const d=document.createElement("li");d.textContent=p,o.appendChild(d)}if(t.appendChild(o),e.filtersText.length>0){const p=document.createElement("div");p.className="cs-result__crit",p.innerHTML='<div class="cs-result__crit-h">Critérios:</div>';const d=document.createElement("div");d.className="cs-result__tags";for(const u of e.filtersText){const l=document.createElement("span");l.className="cs-result__chip",l.textContent=`✓ ${u}`,d.appendChild(l)}p.appendChild(d),t.appendChild(p)}const c=document.createElement("button");c.type="button",c.className="cs-result__cta cs-result__cta--ghost",c.textContent="VER LEADS",c.addEventListener("click",()=>this.renderBalloonList()),t.appendChild(c),this.resultPanel.replaceChildren(t),this.resultPanel.style.display="block"}doProspect(e){this.runProspect(e)}renderBalloonList(){!this.balloon||!this.listEl||(this.updateCounts(),this.renderCardList())}renderCardList(){if(!this.listEl)return;if(this.found.length===0){this.listEl.innerHTML="";const t=document.createElement("div");t.className="cs-empty",t.textContent="Rode a busca no Google Maps e toque em PROSPECTAR para listar as empresas.",this.listEl.appendChild(t);return}const e=document.createDocumentFragment();for(const t of this.found)e.appendChild(this.buildCard(t));this.listEl.replaceChildren(e)}buildCard(e){const t=document.createElement("div");t.className="cs-pcard",t.dataset.key=e.key;const n=L(e.lead),r=document.createElement("div");r.className="cs-pcard__top";const s=document.createElement("div");s.className="cs-pcard__name",s.textContent=e.lead.name,s.title=e.lead.name;const o=document.createElement("div");o.className="cs-pcard__badge "+U(n.band),o.textContent=n.label,r.append(s,o);const c=document.createElement("div");c.className="cs-pcard__meta";const p=[];if(e.lead.address){const h=document.createElement("span");h.textContent=e.lead.address.split(",")[0],p.push(h)}if(e.lead.phone){const h=document.createElement("span");h.textContent=e.lead.phone,p.push(h)}if(e.lead.rating!=null){const h=document.createElement("span");h.className="cs-pcard__rating",h.innerHTML=ue+e.lead.rating.toFixed(1),p.push(h)}for(let h=0;h<p.length;h++)h>0&&c.appendChild(document.createTextNode(" • ")),c.appendChild(p[h]);p.length===0&&(c.textContent="—");const d=document.createElement("div");d.className="cs-pcard__scorebar";const u=document.createElement("div");u.className="cs-pcard__bar";const l=document.createElement("div");l.className="cs-pcard__barfill",l.style.width=`${n.total}%`,u.appendChild(l);const i=document.createElement("div");i.className="cs-pcard__score",i.innerHTML=`${n.total}<small>/100</small>`,d.append(u,i);const m=document.createElement("div");m.className="cs-pcard__actions";const f=document.createElement("button");f.type="button",f.className="cs-pcard__btn cs-pcard__lead",f.innerHTML=(this.selected.has(e.key)?w:S)+'<span data-role="lead-label">Lead</span>',f.addEventListener("click",()=>{this.used.has(e.key)||this.noInterest.has(e.key)||this.toggleControl(e.key)});const b=document.createElement("button");return b.type="button",b.className="cs-pcard__btn cs-pcard__site",b.title="Abrir site",b.innerHTML=M,e.lead.website?b.addEventListener("click",h=>{h.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):b.disabled=!0,m.append(f,b),t.append(r,c,d,m),this.updateCard(t,e),t}updateCard(e,t){const n=e.querySelector(".cs-pcard__lead");if(!n)return;const r=n.querySelector('[data-role="lead-label"]');if(this.noInterest.has(t.key)){n.classList.add("nointerest"),n.disabled=!0,r&&(r.textContent="Sem interesse");return}if(this.used.has(t.key)){n.classList.add("used"),n.disabled=!0,r&&(r.textContent="Importado");return}n.classList.toggle("on",this.selected.has(t.key)),n.innerHTML=(this.selected.has(t.key)?w:S)+'<span data-role="lead-label">Lead</span>'}syncAll(){this.updateCounts(),this.renderControls(),this.renderBalloonList()}updateCounts(){this.bCount&&(this.bCount.textContent=`${this.selected.size}`),this.listEl&&this.listEl.querySelectorAll(".cs-pcard").forEach(t=>{const n=t.dataset.key,r=n?this.found.find(s=>s.key===n):void 0;r&&this.updateCard(t,r)})}toggleBalloon(e){(!this.balloon||!document.body.contains(this.balloon))&&(this.balloon=this.buildBalloon(),document.body.appendChild(this.balloon));const t=e??!this.balloon.classList.contains("open");this.balloon.classList.toggle("open",t),t&&this.renderBalloonList()}positionBalloon(){}refreshCards(){const e=document.querySelectorAll(P()),t=new Set;for(const n of Array.from(e)){const r=I(n),s=n.href,o=Z(n,r);if(!o)continue;const c=G(s),p=c||s;if(!c&&!s||t.has(p))continue;t.add(p);const d=this.found.find(u=>u.key===p);if(d){d.host=d.host&&document.body.contains(d.host)?d.host:r,d.lead.name=o;continue}this.found.push({lead:this.parseCard(r,o,s,c),host:r,key:p,control:null})}this.checkUsed()}async checkUsed(){const e=this.cfg??await y();if(!e.supabaseUrl||!e.anonKey)return;const t=this.found.map(n=>n.lead.place_id).filter(n=>!!n);if(t.length!==0)try{const n=await fetch(`${e.supabaseUrl}/rest/v1/leads?select=place_id,no_interest_until&place_id=in.(${t.map(encodeURIComponent).join(",")})`,{headers:{apikey:e.anonKey,Authorization:`Bearer ${e.anonKey}`}});if(n.ok){const r=await n.json();this.used=new Set(r.filter(o=>o.place_id).map(o=>o.place_id));const s=Date.now();this.noInterest=new Set(r.filter(o=>o.place_id&&o.no_interest_until&&new Date(o.no_interest_until).getTime()>s).map(o=>o.place_id)),this.syncAll()}}catch{}}prune(){this.found=this.found.filter(e=>e.host&&document.body.contains(e.host))}parseCard(e,t,n,r){const s=((e==null?void 0:e.innerText)||"")??"",o=n.match(/!3d([-\d.]+)!4d([-\d.]+)/);return{name:t,phone:ee(e,s),category:te(s,t),website:ne(e),address:re(e),city:null,state:null,rating:ie(s),reviews:ce(s),latitude:o?parseFloat(o[1]):null,longitude:o?parseFloat(o[2]):null,place_id:r,maps_url:n||null,instagram:ae(e),facebook:se(e),whatsapp:oe(e)}}async promptConfig(){var n,r;this.cfg=this.cfg??await y();const e=prompt("URL do projeto Supabase:",((n=this.cfg)==null?void 0:n.supabaseUrl)||"");if(e===null)return;const t=prompt("Chave anon (publishable):",((r=this.cfg)==null?void 0:r.anonKey)||"");if(t!==null){if(!e||!t){alert("Informe URL e chave anon.");return}await q({supabaseUrl:e.replace(/\/+$/,""),anonKey:t}),this.cfg={supabaseUrl:e.replace(/\/+$/,""),anonKey:t},this.subscribeRealtime()}}async doImport(e){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const t=this.found.filter(r=>!this.used.has(r.key)&&this.selected.has(r.key)).map(r=>r.lead).slice(0,50);if(t.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const n=e.innerHTML;e.disabled=!0,e.textContent="Importando…";try{let r=0;const s=await A(this.cfg,t,(o,c)=>{r=o,e.textContent=`${o}/${c}…`});e.textContent=s.failed===0?"✓":`${s.ok} ok, ${s.failed} falharam`,s.failed===0?(g(s.ok>0?`✅ ${s.ok} lead(s) importado(s)!`:"Nenhum lead novo para importar."),this.selected.clear()):g(`⚠️ ${s.ok} ok, ${s.failed} falharam`,"warn"),this.checkUsed(),this.syncAll(),setTimeout(()=>{e.innerHTML=n,e.disabled=!1},2e3)}catch(r){e.textContent=`Erro: ${r}`,setTimeout(()=>{e.innerHTML=n,e.disabled=!1},3e3)}}async doDelete(e){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const t=this.found.filter(r=>this.selected.has(r.key)&&r.lead.place_id).map(r=>r.lead.place_id);if(t.length===0){alert("Selecione pelo menos um lead para excluir.");return}if(!confirm(`Excluir ${t.length} lead(s) do banco?`))return;const n=e.innerHTML;e.disabled=!0,e.innerHTML="Excluindo…";try{const r=await H(this.cfg,t);if(r.failed===0){g(`🗑️ ${r.ok} lead(s) excluído(s)!`);for(const s of t)this.used.delete(s);this.selected.clear()}else g(`⚠️ ${r.ok} ok, ${r.failed} falharam ao excluir`,"warn");this.checkUsed(),this.syncAll()}catch(r){g(`Erro ao excluir: ${r}`,"warn")}finally{e.innerHTML=n,e.disabled=!1}}}const R=()=>{new X().init()};typeof window<"u"&&R();function be(){R()}function P(){return'a[href*="/maps/place/"]'}function G(a){const e=a.match(/(?:^|[?&])place_id=([^&]+)/);return e?decodeURIComponent(e[1]):null}function I(a){let e=a.parentElement;for(let t=0;t<9&&e&&e.tagName!=="BODY"&&e.getAttribute("role")!=="feed";t++){if(e.getAttribute("role")==="article"||e.querySelector('span[aria-label*="stars"], span[aria-label*="avalia"], span[aria-label*="estrela"]')||e.querySelector('a[href*="/maps/place/"]'))return e;e=e.parentElement}return a.closest('div[role="article"], [role="article"]')??a}function J(a){let e=a.parentElement;for(;e&&e.tagName!=="BODY"&&e.tagName!=="HTML";){const t=getComputedStyle(e);if(["auto","scroll"].includes(t.overflowY)||t.overflowY==="clip"&&["auto","scroll"].includes(t.overflow))return e;e=e.parentElement}return document.scrollingElement}function Z(a,e){const n=(a.textContent||"").split(/\s+/).filter(Boolean);if(n.length>0&&n.length<14)return n.slice(0,6).join(" ");const r=a.querySelector('h3, [role="heading"], [style*="font"]'),s=((r==null?void 0:r.textContent)||"").trim();return s?s.split(`
`)[0]:e&&(e.textContent||"").trim().split(`
`)[0]||null}function ee(a,e){const t=a==null?void 0:a.querySelector('a[href^="tel:"]');if(t)return t.href.replace("tel:","").trim();const n=e.match(/\(\d{2,3}\)\s?\d[\d\s-]{7,}/);return n?n[0].replace(/\s+/g," ").trim():null}function te(a,e){for(const t of a.split(`
`)){const n=t.trim();if(n&&n!==e&&n.length<40&&!/\d/.test(n)&&!n.startsWith("★")&&!/^\d/.test(n))return n}return null}function ne(a){if(!a)return null;const e=['a[data-tooltip="Abrir site"]','a[data-tooltip="Website"]','a[aria-label*="Abrir site"]','a[href]:not([href^="tel:"]):not([href*="/maps/place/"]):not([href^="http://www.google.com/maps"])'];for(const r of e){const s=a.querySelector(r),o=s==null?void 0:s.href;if(o&&o.startsWith("http"))return o.split("&place_id")[0]}const t=a.querySelector('a[href^="http"]'),n=t==null?void 0:t.href;return n&&n.startsWith("http")&&!n.includes("/maps/place/")?n.split("&")[0]:null}function re(a){var t;const e=a==null?void 0:a.querySelector('button[data-tooltip="Endereço"], div[class*="address"], span[data-type="address"]');return((t=e==null?void 0:e.textContent)==null?void 0:t.trim())||null}function ae(a){if(!a)return null;const e=['a[data-tooltip*="Instagram" i]','a[aria-label*="Instagram" i]','a[href*="instagram.com/"]','a[href*="instagram.com"]'];for(const r of e){const s=a.querySelector(r),o=s==null?void 0:s.href;if(o&&/instagram\.com/i.test(o))return $(o)}const n=(a.innerText||"").match(/instagram\.com\/[A-Za-z0-9_.\-]+/i);return n?`https://www.${n[0].toLowerCase()}`:null}function se(a){if(!a)return null;const e=['a[data-tooltip*="Facebook" i]','a[aria-label*="Facebook" i]','a[href*="facebook.com/"]','a[href*="fb.com/"]'];for(const t of e){const n=a.querySelector(t),r=n==null?void 0:n.href;if(r&&/facebook\.com|fb\.com/i.test(r))return $(r)}return null}function oe(a){if(!a)return null;const e=['a[data-tooltip*="WhatsApp" i]','a[aria-label*="WhatsApp" i]','a[href*="wa.me/"]','a[href*="api.whatsapp.com"]','a[href^="whatsapp:"]'];for(const t of e){const n=a.querySelector(t),r=n==null?void 0:n.href;if(r&&/wa\.me|whatsapp/i.test(r)){const s=r.match(/(?:wa\.me\/|phone=)(\d+)/);return s?`+${s[1]}`:r}}return null}function $(a){try{const e=new URL(a);return`${e.protocol}//${e.host}${e.pathname.replace(/\/$/,"")}`}catch{return a.split("?")[0]}}function ie(a){const e=a.match(/([\d.]+)[\s]*[★✩]/);return e?parseFloat(e[1]):null}function ce(a){const e=a.match(/\(([\d.,]+)\)/);return e?parseInt(e[1].replace(/[^\d]/g,""),10):null}function le(){if(document.getElementById("consecom-css"))return;const a=document.createElement("style");a.id="consecom-css",a.textContent=Q,document.head.appendChild(a)}function g(a,e="ok"){var r;const t="consecom-toast";(r=document.getElementById(t))==null||r.remove();const n=document.createElement("div");n.id=t,n.className="consecom-toast"+(e==="warn"?" cs-warn":""),n.textContent=a,document.body.appendChild(n),window.setTimeout(()=>{n.classList.add("cs-show")},20),window.setTimeout(()=>n.remove(),4e3)}function k(a){return new Promise(e=>window.setTimeout(e,a))}const de='<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z"/></svg>',M='<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm2.5 16c-.8 1.3-1.6 2-2.5 2s-1.7-.7-2.5-2c-.7-1.2-1.2-2.8-1.4-4.5h7.8c-.2 1.7-.7 3.3-1.4 4.5zM7.8 11.5c.2-1.7.7-3.3 1.4-4.5.8-1.3 1.6-2 2.5-2s1.7.7 2.5 2c.7 1.2 1.2 2.8 1.4 4.5H7.8zM12 4c.5.7.9 1.6 1.2 2.6h-2.4C10.6 5.6 11.2 4.6 12 4zm-3.1 7c-.1.5-.1 1 0 1.5H5.9a8 8 0 0 1 0-3h3c-.1.5-.1 1 0 1.5zm-1.6 3h3c.1 1.5.4 2.9.9 4-.9-.4-1.6-.9-2.3-1.6-.5-.6-1-1.5-1.6-2.4zM15.1 17c.7.7 1.4 1.2 2.3 1.6-.5-1.1-.8-2.5-.9-4h3a8 8 0 0 1-.9 3c-.5.5-1 .9-1.6 1.2-.6.3-1.3.5-1.9.6v-2.4zm3.6-4.5h-3.1c0-.5 0-1 .1-1.5h3a8 8 0 0 1 0 3h-3c0-.5-.1-1-.1-1.5zM7.1 7c-.7-.7-1.4-1.2-2.3-1.6.5 1.1.8 2.5.9 4h-3a8 8 0 0 1 .9-3c.5-.5 1-.9 1.6-1.2.6-.3 1.3-.5 1.9-.6V7zm0 1.5v2.4c.5 0 1 .1 1.5.1h1.6c-.1-1.4-.4-2.7-.9-3.8-.7.3-1.4.8-2.2 1.3zM12 20c-.5-.7-.9-1.6-1.2-2.6h2.4c-.3 1-.9 1.9-1.2 2.6z"/></svg>',w='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',S='<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',pe='<svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm8.9-3.3a7.5 7.5 0 0 0 0-1.5l2-1.6-2-3.4-2.5 1a7.7 7.7 0 0 0-1.7-1L16 1.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.5 7.5 0 0 0 0 1.5l-2 1.6 2 3.4 2.5-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6zM12 16.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>',ue='<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.9-5 4.7 1.3 6.8L12 17.8 5.9 20.7l1.3-6.8-5-4.7 6.9-.9z"/></svg>',me='<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>',fe='<svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>';export{X as MapsScanner,be as startConsecomScanner};
