import{g as L,a as y,s as N}from"./config-6cNGcIy7.js";async function B(a,e){const t=L(a);if(!t)return{ok:0,failed:e.length};let n=0,o=0;for(const r of e){const{error:s}=await t.from("leads").delete().eq("place_id",r);s?o++:n++}return{ok:n,failed:o}}async function T(a,e,t){const n=L(a);if(!n)return{ok:0,failed:e.length,firstError:"Configure a URL e a chave anon do Supabase."};let o=null;if(e.length>0){const{data:l,error:i}=await n.from("capture_sessions").insert({imported_by:"extension"}).select("id").single();!i&&l&&(o=l.id)}let r=0,s=0,c;for(let l=0;l<e.length;l++){const i=e[l],d={name:i.name||null,phone:i.phone||null,category:i.category||null,website:i.website||null,address:i.address||null,city:i.city||null,state:i.state||null,rating:i.rating,reviews:i.reviews,latitude:i.latitude,longitude:i.longitude,place_id:i.place_id||null,niche:"maps",session_id:o},{error:u}=await n.from("leads").upsert(d,{onConflict:"place_id",ignoreDuplicates:!1});u?(s++,c||(c=u.message)):r++,t==null||t(l+1,e.length)}return{ok:r,failed:s,firstError:c}}function A(a){let e=0;a.rating!=null&&a.rating>0&&(e=Math.min(45,Math.round(a.rating/5*45)));let t=0;a.reviews!=null&&a.reviews>0&&(t=Math.min(30,Math.round(Math.log10(a.reviews+1)/Math.log10(1e4)*30)));const n=a.website?10:0,o=a.phone?10:0,r=a.category?5:0,s=Math.max(0,Math.min(100,e+t+n+o+r)),c=R(s);return{total:s,band:c,label:H[c],parts:{rating:e,reviews:t,website:n,phone:o,category:r}}}const H={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Oportunidade média",baixa:"Baixa oportunidade",nenhuma:"Sem dados"},$={alta:"🔥",boa:"😃",media:"🙂",baixa:"😕",nenhuma:"😴"};function R(a){return a>=80?"alta":a>=60?"boa":a>=40?"media":a>=20?"baixa":"nenhuma"}function U(a){return $[a]}function q(a){return"cs-band-"+a}const D=`/* ===== Vyntra Prospector — tema escuro roxo ===== */
:root {
  --vy-bg: #10071d;
  --vy-panel: #160b28;
  --vy-card: #1d1030;
  --vy-border: rgba(255, 255, 255, 0.07);
  --vy-text: #e9e4f4;
  --vy-muted: #8d82a8;
  --vy-accent: #8b5cf6;
  --vy-accent2: #a855f7;
  --vy-gradient: linear-gradient(135deg, #8b5cf6, #a855f7);
}

/* ===== Bolha flutuante Vyntra (arrastável) ===== */
.consecom-bubble {
  position: fixed;
  z-index: 2147483647;
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: var(--vy-gradient);
  color: #fff;
  cursor: grab;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 28px rgba(139, 92, 246, 0.5);
  user-select: none;
  touch-action: none;
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;
}
.consecom-bubble:active { cursor: grabbing; }
.consecom-bubble__icon {
  font-size: 24px;
  font-weight: 800;
  line-height: 1;
  font-style: italic;
}
.consecom-bubble__count {
  position: absolute;
  top: -6px;
  right: -6px;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 999px;
  background: #ef4444;
  border: 2px solid #fff;
  font-size: 11px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
}

/* ===== Painel lateral Vyntra (sidebar fixa à esquerda) ===== */
.consecom-balloon {
  position: fixed;
  z-index: 2147483646;
  top: 0;
  left: 0;
  bottom: 0;
  width: 356px;
  max-width: 92vw;
  background: var(--vy-panel);
  border-right: 1px solid var(--vy-border);
  display: flex;
  flex-direction: column;
  opacity: 0;
  transform: translateX(-110%);
  pointer-events: none;
  transition: transform 0.24s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.18s ease;
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;
  box-shadow: 24px 0 60px rgba(0, 0, 0, 0.45);
}
.consecom-balloon.open {
  opacity: 1;
  transform: translateX(0);
  pointer-events: auto;
}

.cs-panel__header {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 16px 16px 12px;
  border-bottom: 1px solid var(--vy-border);
}
.cs-panel__logo {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--vy-gradient);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 20px;
  font-style: italic;
  color: #fff;
  flex: 0 0 auto;
}
.cs-panel__titles { min-width: 0; }
.cs-panel__name { font-size: 15px; font-weight: 800; color: var(--vy-text); letter-spacing: -0.01em; }
.cs-panel__tag { font-size: 11px; color: var(--vy-muted); margin-top: 1px; }

.cs-panel__search { padding: 12px 16px; display: flex; flex-direction: column; gap: 8px; }
.cs-panel__input {
  width: 100%;
  padding: 10px 12px;
  background: rgba(0, 0, 0, 0.28);
  border: 1px solid var(--vy-border);
  border-radius: 10px;
  color: var(--vy-text);
  font-size: 13px;
  font-family: inherit;
  outline: none;
  transition: border-color 0.15s;
}
.cs-panel__input:focus { border-color: var(--vy-accent); }
.cs-panel__input::placeholder { color: #6d6288; }
.cs-panel__loc {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  color: var(--vy-muted);
}
.cs-panel__loc svg { width: 13px; height: 13px; fill: currentColor; }

.cs-prospect {
  margin: 2px 16px 12px;
  padding: 13px;
  border: none;
  border-radius: 12px;
  background: var(--vy-gradient);
  color: #fff;
  font-weight: 800;
  font-size: 14px;
  letter-spacing: 0.06em;
  font-family: inherit;
  cursor: pointer;
  transition: transform 0.12s, filter 0.15s;
  box-shadow: 0 10px 26px rgba(139, 92, 246, 0.35);
}
.cs-prospect:hover:not(:disabled) { filter: brightness(1.08); transform: translateY(-1px); }
.cs-prospect:active:not(:disabled) { transform: translateY(0); }
.cs-prospect:disabled { opacity: 0.55; cursor: default; }

/* ===== Lista de cards ===== */
.cs-panel__list {
  flex: 1;
  overflow-y: auto;
  padding: 4px 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.cs-panel__list::-webkit-scrollbar { width: 6px; }
.cs-panel__list::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.12); border-radius: 999px; }

.cs-pcard {
  background: var(--vy-card);
  border: 1px solid var(--vy-border);
  border-radius: 12px;
  padding: 11px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.cs-pcard__top { display: flex; align-items: center; gap: 8px; min-width: 0; }
.cs-pcard__name {
  flex: 1;
  min-width: 0;
  font-size: 13.5px;
  font-weight: 700;
  color: var(--vy-text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cs-pcard__rating {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #fbbf24;
  font-weight: 700;
  flex: 0 0 auto;
}
.cs-pcard__rating svg { width: 12px; height: 12px; fill: currentColor; }

.cs-pcard__scorebar {
  display: flex;
  align-items: center;
  gap: 8px;
}
.cs-pcard__bar {
  flex: 1;
  height: 6px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
  overflow: hidden;
}
.cs-pcard__barfill {
  height: 100%;
  border-radius: 999px;
  background: var(--vy-gradient);
  transition: width 0.4s ease;
}
.cs-pcard__score {
  font-size: 11px;
  font-weight: 800;
  color: var(--vy-text);
  flex: 0 0 auto;
}
.cs-pcard__score small { color: var(--vy-muted); font-weight: 600; }

.cs-pcard__badge {
  align-self: flex-start;
  font-size: 10.5px;
  font-weight: 700;
  padding: 3px 8px;
  border-radius: 999px;
  letter-spacing: 0.01em;
}
.cs-band-alta { color: #a7f3d0; background: rgba(16, 185, 129, 0.16); border: 1px solid rgba(16, 185, 129, 0.35); }
.cs-band-boa { color: #bbf7d0; background: rgba(34, 197, 94, 0.16); border: 1px solid rgba(34, 197, 94, 0.35); }
.cs-band-media { color: #fde68a; background: rgba(245, 158, 11, 0.16); border: 1px solid rgba(245, 158, 11, 0.35); }
.cs-band-baixa { color: #fecaca; background: rgba(248, 113, 113, 0.16); border: 1px solid rgba(248, 113, 113, 0.35); }
.cs-band-nenhuma { color: #94a3b8; background: rgba(100, 116, 139, 0.14); border: 1px solid rgba(100, 116, 139, 0.3); }

.cs-pcard__actions { display: flex; gap: 6px; margin-top: 2px; }
.cs-pcard__btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 10px;
  border: none;
  border-radius: 9px;
  font-family: inherit;
  font-size: 12px;
  font-weight: 700;
  cursor: pointer;
  transition: transform 0.1s, filter 0.15s;
}
.cs-pcard__btn svg { width: 13px; height: 13px; fill: currentColor; }
.cs-pcard__lead {
  background: var(--vy-gradient);
  color: #fff;
}
.cs-pcard__lead:hover:not(:disabled) { filter: brightness(1.08); transform: translateY(-1px); }
.cs-pcard__lead.on { background: #22c55e; }
.cs-pcard__lead.used { background: rgba(255, 255, 255, 0.12); color: var(--vy-muted); cursor: default; }
.cs-pcard__lead.nointerest { background: rgba(239, 68, 68, 0.22); color: #fca5a5; }
.cs-pcard__site {
  background: rgba(255, 255, 255, 0.08);
  color: var(--vy-text);
}
.cs-pcard__site:hover:not(:disabled) { filter: brightness(1.15); }
.cs-pcard__site:disabled { opacity: 0.4; cursor: default; }

/* ===== Rodapé do painel ===== */
.cs-panel__footer {
  border-top: 1px solid var(--vy-border);
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cs-footer__row { display: flex; gap: 6px; }
.cs-footer__btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 9px 10px;
  border: none;
  border-radius: 9px;
  font-family: inherit;
  font-size: 12px;
  font-weight: 700;
  color: #fff;
  cursor: pointer;
  transition: transform 0.1s, filter 0.15s;
}
.cs-footer__btn svg { width: 13px; height: 13px; fill: currentColor; }
.cs-footer__btn:hover:not(:disabled) { filter: brightness(1.1); }
.cs-footer__btn:disabled { opacity: 0.55; cursor: default; }
.cs-foot-import { background: var(--vy-gradient); }
.cs-foot-all { background: rgba(255, 255, 255, 0.1); color: var(--vy-text); }
.cs-foot-delete { background: rgba(239, 68, 68, 0.2); color: #fda4af; }
.cs-foot-config { background: rgba(255, 255, 255, 0.08); color: var(--vy-muted); }

.cs-empty {
  text-align: center;
  color: var(--vy-muted);
  font-size: 12px;
  padding: 28px 12px;
  line-height: 1.6;
}

/* ===== Cards nativos enxutos (controles dentro dos cards do Maps) ===== */
.consecom-host {
  position: relative !important;
  min-width: 0 !important;
}
.consecom-host > *:not(.consecom-control) {
  opacity: 0 !important;
  pointer-events: none !important;
  height: 0 !important;
  overflow: hidden !important;
}
.consecom-control {
  position: relative !important;
  z-index: 30 !important;
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  padding: 5px 8px !important;
  background: var(--vy-card) !important;
  border: 1px solid var(--vy-border) !important;
  border-radius: 8px !important;
  box-sizing: border-box !important;
  min-height: 34px !important;
  font-family: 'Inter', 'Segoe UI', Roboto, system-ui, sans-serif !important;
}
.consecom-control .cs-select { flex: 0 0 auto !important; }
.consecom-control .cs-name {
  flex: 1 !important;
  min-width: 0 !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  color: var(--vy-text) !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}
.consecom-control .cs-actions {
  display: flex !important;
  gap: 4px !important;
  flex: 0 0 auto !important;
}
.consecom-control .cs-round {
  width: 26px !important;
  height: 26px !important;
  border-radius: 50% !important;
  border: none !important;
  cursor: pointer !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 0 !important;
  background: var(--vy-gradient) !important;
  color: #fff !important;
  box-shadow: 0 1px 4px rgba(139, 92, 246, 0.4) !important;
  transition: transform 0.1s, background 0.15s !important;
}
.consecom-control .cs-round svg { width: 13px; height: 13px; fill: #fff; }
.consecom-control .cs-round:hover:not(:disabled) { filter: brightness(1.1); transform: scale(1.08); }
.consecom-control .cs-round:disabled { background: rgba(255, 255, 255, 0.1); box-shadow: none; cursor: default; opacity: 0.6; }
.consecom-control .cs-round:disabled svg { fill: #6d6288; }
.consecom-control .cs-select { background: transparent; border: 2px solid var(--vy-accent); color: var(--vy-accent); }
.consecom-control .cs-select svg { fill: var(--vy-accent); }
.consecom-control .cs-select.on { background: var(--vy-accent); color: #fff; }
.consecom-control .cs-select.on svg { fill: #fff; }
.consecom-control .cs-select.used { background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.12); color: #6d6288; }
.consecom-control .cs-select.used svg { fill: #6d6288; }
.consecom-control .cs-select.nointerest { background: rgba(239, 68, 68, 0.25); border-color: #ef4444; color: #fca5a5; font-weight: 700; }
.consecom-control .cs-badge {
  position: absolute !important;
  top: -8px !important;
  right: -6px !important;
  background: #ef4444 !important;
  color: #fff !important;
  font-size: 9px !important;
  font-weight: 700 !important;
  padding: 1px 5px !important;
  border-radius: 999px !important;
  white-space: nowrap !important;
  box-shadow: 0 1px 3px rgba(0,0,0,.25) !important;
}

/* ===== Toast ===== */
.consecom-toast {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%) translateY(-18px);
  z-index: 2147483647;
  padding: 12px 20px;
  background: #160b28;
  color: #e9e4f4;
  border: 1px solid rgba(16, 185, 129, 0.5);
  border-radius: 12px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;
  font-size: 14px;
  font-weight: 600;
  opacity: 0;
  transition: opacity 0.25s, transform 0.25s;
  pointer-events: none;
}
.consecom-toast.cs-warn { border-color: rgba(249, 115, 22, 0.6); }
.consecom-toast.cs-show { opacity: 1; transform: translateX(-50%) translateY(0); }
`;class P{constructor(){this.cfg=null,this.rtChannel=null,this.found=[],this.selected=new Set,this.used=new Set,this.noInterest=new Set,this.scanning=!1,this.bubble=null,this.balloon=null,this.bCount=null,this.listEl=null,this.locEl=null,this.lastQuery="",this.dragging=!1,this.suppressClick=!1,this.debounceUsed=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.checkUsed()},400))}})(),this.debounceScan=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.scan()},350))}})()}async init(){this.cfg=await y(),J(),this.ensureBubble(),this.observeDom(),this.scan("force"),window.addEventListener("click",e=>{var t,n;(t=this.balloon)!=null&&t.classList.contains("open")&&(this.balloon.contains(e.target)||(n=this.bubble)!=null&&n.contains(e.target)||this.toggleBalloon(!1))}),chrome.runtime.onMessage.addListener(e=>{((e==null?void 0:e.type)==="consecom:open"||(e==null?void 0:e.type)==="consecom:ping")&&this.toggleBalloon(!0)}),this.subscribeRealtime()}subscribeRealtime(){var t;(t=this.rtChannel)==null||t.unsubscribe(),this.rtChannel=null;const e=this.cfg?L(this.cfg):null;e&&(this.rtChannel=e.channel("consecom-leads-rt").on("postgres_changes",{event:"*",schema:"public",table:"leads"},()=>this.debounceUsed()).subscribe())}observeDom(){new MutationObserver(()=>this.debounceScan()).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("scroll",()=>this.debounceScan(),{passive:!0})}scan(e="scan"){if(!(this.scanning&&e!=="force")){this.scanning=!0;try{this.syncArea(),this.refreshCards(),this.prune(),this.renderControls(),this.renderBalloonList()}finally{this.scanning=!1}}}syncArea(){var n;const e=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]'),t=((e==null?void 0:e.value)||"").trim();t&&t!==this.lastQuery&&(this.lastQuery=t,this.selected.clear(),this.found=[],this.locEl&&(this.locEl.textContent=t),(n=this.balloon)!=null&&n.classList.contains("open")&&this.renderCardList()),t&&(this.lastQuery=t)}renderControls(){if(this.found.length!==0){for(const e of this.found)if(!(!e.host||!document.body.contains(e.host))){if(e.control&&e.control.isConnected){this.updateControl(e);continue}e.control=this.buildControl(e),this.makeHostSlim(e.host),e.host.appendChild(e.control)}}}makeHostSlim(e){e.classList.contains("consecom-host")||e.classList.add("consecom-host")}toggleSelected(e){this.used.has(e)||this.noInterest.has(e)||(this.selected.has(e)?this.selected.delete(e):this.selected.add(e),this.syncAll())}toggleControl(e){this.toggleSelected(e)}selectAllAvailable(){const e=this.found.filter(o=>!this.used.has(o.key)&&!this.noInterest.has(o.key)),t=Math.min(50,e.length),n=new Set;for(let o=0;o<t;o++)n.add(e[o].key);this.selected=n,this.syncAll(),b(`✅ ${this.selected.size} selecionado(s) (máx. 50 por importação)`)}clearSelection(){this.selected.clear(),this.syncAll()}buildControl(e){const t=document.createElement("div");t.className="consecom-control",t.title=e.lead.name;const n=document.createElement("button");n.type="button",n.className="cs-round cs-select",n.title="Selecionar",n.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),this.toggleControl(e.key)});const o=document.createElement("span");o.className="cs-name",o.textContent=e.lead.name,o.title=e.lead.name;const r=document.createElement("div");r.className="cs-actions";const s=document.createElement("button");s.type="button",s.className="cs-round",s.title="Abrir site",s.innerHTML=S,e.lead.website?s.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):s.disabled=!0;const c=document.createElement("button");c.type="button",c.className="cs-round",c.title="Chamar",c.innerHTML=Z,e.lead.phone?c.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),window.location.href=`tel:${e.lead.phone.replace(/\s+/g,"")}`}):c.disabled=!0,r.append(s,c);const l=document.createElement("span");return l.className="cs-badge",l.textContent="Sem interesse",l.style.display="none",t.append(n,o,r,l),t}updateControl(e){var r,s;const t=(r=e.control)==null?void 0:r.querySelector(".cs-select");if(!t)return;const n=this.noInterest.has(e.key);t.classList.toggle("nointerest",n);const o=(s=e.control)==null?void 0:s.querySelector(".cs-badge");if(o&&(o.style.display=n?"block":"none"),n){t.disabled=!0,t.title="Sem interesse — não importar (6 meses)",t.innerHTML="✕";return}this.used.has(e.key)?(t.classList.add("used"),t.disabled=!0,t.title="Já importado anteriormente",t.innerHTML=_):(t.disabled=!1,t.classList.toggle("on",this.selected.has(e.key)),t.title=this.selected.has(e.key)?"Remover seleção":"Selecionar",t.innerHTML=this.selected.has(e.key)?_:E)}buildBubble(){const e=document.createElement("div");e.className="consecom-bubble",e.title="Vyntra Prospector";const t=document.createElement("span");t.className="consecom-bubble__icon",t.textContent="V";const n=document.createElement("span");return n.className="consecom-bubble__count",n.textContent="0",this.bCount=n,e.append(t,n),this.bubble=e,e.addEventListener("click",()=>{if(this.suppressClick){this.suppressClick=!1;return}this.toggleBalloon()}),this.enableDrag(e),e.style.left=localStorage.getItem("consecom-bubble-x")||"20px",e.style.top=localStorage.getItem("consecom-bubble-top")||"16px",e}ensureBubble(){if(this.bubble&&document.body.contains(this.bubble))return;const e=this.buildBubble();document.body.appendChild(e)}enableDrag(e){let t=0,n=0,o=0,r=0;const s={v:!1},c=d=>{this.dragging=!0,s.v=!1,t=d.clientX,n=d.clientY,o=e.offsetLeft,r=e.offsetTop,e.setPointerCapture(d.pointerId)},l=d=>{if(!this.dragging)return;const u=d.clientX-t,f=d.clientY-n;Math.abs(u)+Math.abs(f)>4&&(s.v=!0);const h=Math.max(0,Math.min(window.innerWidth-60,o+u)),p=Math.max(0,Math.min(window.innerHeight-60,r+f));e.style.left=`${h}px`,e.style.top=`${p}px`},i=d=>{this.dragging&&(e.hasPointerCapture(d.pointerId)&&e.releasePointerCapture(d.pointerId),this.suppressClick=s.v,this.dragging=!1,localStorage.setItem("consecom-bubble-x",e.style.left),localStorage.setItem("consecom-bubble-top",e.style.top))};e.addEventListener("pointerdown",c),e.addEventListener("pointermove",l),e.addEventListener("pointerup",i),e.addEventListener("pointercancel",i)}buildBalloon(){const e=document.createElement("aside");e.className="consecom-balloon";const t=document.createElement("div");t.className="cs-panel__header";const n=document.createElement("div");n.className="cs-panel__logo",n.textContent="V";const o=document.createElement("div");o.className="cs-panel__titles";const r=document.createElement("div");r.className="cs-panel__name",r.textContent="VYNTRA Prospector";const s=document.createElement("div");s.className="cs-panel__tag",s.textContent="Captura de leads do Google Maps",o.append(r,s),t.append(n,o);const c=document.createElement("div");c.className="cs-panel__search";const l=document.createElement("input");l.className="cs-panel__input",l.type="text",l.placeholder="Buscar empresas",l.spellcheck=!1,l.addEventListener("keydown",I=>{var M;if(I.key==="Enter"){const k=l.value.trim();if(!k)return;const v=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]');if(v){const C=(M=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:M.set;C==null||C.call(v,k),v.dispatchEvent(new Event("input",{bubbles:!0})),v.dispatchEvent(new Event("change",{bubbles:!0})),v.focus(),v.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0}))}else this.lastQuery=k,this.selected.clear(),this.found=[],this.scan("force")}});const i=document.createElement("div");i.className="cs-panel__loc",i.innerHTML=ne,this.locEl=document.createElement("span"),this.locEl.textContent="Aguardando busca…",i.append(this.locEl),c.append(l,i);const d=document.createElement("button");d.type="button",d.className="cs-prospect",d.textContent="PROSPECTAR",d.addEventListener("click",()=>this.doProspect(d));const u=document.createElement("div");u.className="cs-panel__list",this.listEl=u;const f=document.createElement("div");f.className="cs-panel__footer";const h=document.createElement("div");h.className="cs-footer__row";const p=document.createElement("button");p.type="button",p.className="cs-footer__btn cs-foot-import",p.innerHTML='<span data-role="import-label">Importar</span>'+oe,p.addEventListener("click",()=>void this.doImport(p));const m=document.createElement("button");m.type="button",m.className="cs-footer__btn cs-foot-all",m.innerHTML="Selecionar todos"+se,m.addEventListener("click",()=>this.selectAllAvailable()),h.append(p,m);const w=document.createElement("div");w.className="cs-footer__row";const g=document.createElement("button");g.type="button",g.className="cs-footer__btn cs-foot-delete",g.innerHTML="Excluir selecionados"+ae,g.addEventListener("click",()=>void this.doDelete(g));const x=document.createElement("button");return x.type="button",x.className="cs-footer__btn cs-foot-config",x.title="Configurar Supabase",x.innerHTML="Configurar"+ee,x.addEventListener("click",()=>void this.promptConfig()),w.append(g,x),f.append(h,w),e.append(t,c,d,u,f),this.balloon=e,e}doProspect(e){const t=e.textContent;e.disabled=!0,e.textContent="VARREVENDO…",window.setTimeout(()=>{this.scan("force");const n=this.selected.size;this.selectAllAvailable(),this.selected.size===n&&b("Nenhuma empresa nova encontrada nesta busca.","warn"),e.textContent=t,e.disabled=!1},50)}renderBalloonList(){if(!this.balloon||!this.listEl)return;const e=this.balloon.querySelector('[data-role="import-label"]');e&&(e.textContent=this.selected.size>0?`Importar (${this.selected.size})`:"Importar"),this.updateCounts(),this.renderCardList()}renderCardList(){if(!this.listEl)return;if(this.found.length===0){this.listEl.innerHTML="";const t=document.createElement("div");t.className="cs-empty",t.textContent="Rode a busca no Google Maps e toque em PROSPECTAR para listar as empresas.",this.listEl.appendChild(t);return}const e=document.createDocumentFragment();for(const t of this.found)e.appendChild(this.buildCard(t));this.listEl.replaceChildren(e)}buildCard(e){const t=document.createElement("div");t.className="cs-pcard",t.dataset.key=e.key;const n=document.createElement("div");n.className="cs-pcard__top";const o=document.createElement("div");o.className="cs-pcard__name",o.textContent=e.lead.name,o.title=e.lead.name;const r=document.createElement("div");r.className="cs-pcard__rating",r.innerHTML=te+(e.lead.rating!=null?e.lead.rating.toFixed(1):"—"),n.append(o,r);const s=A(e.lead),c=document.createElement("div");c.className="cs-pcard__scorebar";const l=document.createElement("div");l.className="cs-pcard__bar";const i=document.createElement("div");i.className="cs-pcard__barfill",i.style.width=`${s.total}%`,l.appendChild(i);const d=document.createElement("div");d.className="cs-pcard__score",d.innerHTML=`${s.total}/100`,c.append(l,d);const u=document.createElement("div");u.className="cs-pcard__badge "+q(s.band),u.textContent=`${U(s.band)} ${s.label}`;const f=document.createElement("div");f.className="cs-pcard__actions";const h=document.createElement("button");h.type="button",h.className="cs-pcard__btn cs-pcard__lead",h.innerHTML=(this.selected.has(e.key)?_:E)+'<span data-role="lead-label">Lead</span>',h.addEventListener("click",()=>{this.used.has(e.key)||this.noInterest.has(e.key)||this.toggleControl(e.key)});const p=document.createElement("button");return p.type="button",p.className="cs-pcard__btn cs-pcard__site",p.title="Abrir site",p.innerHTML=S,e.lead.website?p.addEventListener("click",m=>{m.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):p.disabled=!0,f.append(h,p),t.append(n,c,u,f),this.updateCard(t,e),t}updateCard(e,t){const n=e.querySelector(".cs-pcard__lead");if(!n)return;const o=n.querySelector('[data-role="lead-label"]');if(this.noInterest.has(t.key)){n.classList.add("nointerest"),n.disabled=!0,o&&(o.textContent="Sem interesse");return}if(this.used.has(t.key)){n.classList.add("used"),n.disabled=!0,o&&(o.textContent="Importado");return}n.classList.toggle("on",this.selected.has(t.key)),n.innerHTML=(this.selected.has(t.key)?_:E)+'<span data-role="lead-label">Lead</span>'}syncAll(){this.updateCounts(),this.renderControls(),this.renderBalloonList()}updateCounts(){this.bCount&&(this.bCount.textContent=`${this.selected.size}`),this.listEl&&this.listEl.querySelectorAll(".cs-pcard").forEach(t=>{const n=t.dataset.key,o=n?this.found.find(r=>r.key===n):void 0;o&&this.updateCard(t,o)})}toggleBalloon(e){(!this.balloon||!document.body.contains(this.balloon))&&(this.balloon=this.buildBalloon(),document.body.appendChild(this.balloon));const t=e??!this.balloon.classList.contains("open");this.balloon.classList.toggle("open",t),t&&this.renderBalloonList()}positionBalloon(){}refreshCards(){const e=document.querySelectorAll(V()),t=new Set;for(const n of Array.from(e)){const o=O(n),r=n.href,s=Y(n,o);if(!s)continue;const c=j(r),l=c||r;if(!c&&!r||t.has(l))continue;t.add(l);const i=this.found.find(d=>d.key===l);if(i){i.host=i.host&&document.body.contains(i.host)?i.host:o,i.lead.name=s;continue}this.found.push({lead:this.parseCard(o,s,r,c),host:o,key:l,control:null})}this.checkUsed()}async checkUsed(){const e=this.cfg??await y();if(!e.supabaseUrl||!e.anonKey)return;const t=this.found.map(n=>n.lead.place_id).filter(n=>!!n);if(t.length!==0)try{const n=await fetch(`${e.supabaseUrl}/rest/v1/leads?select=place_id,no_interest_until&place_id=in.(${t.map(encodeURIComponent).join(",")})`,{headers:{apikey:e.anonKey,Authorization:`Bearer ${e.anonKey}`}});if(n.ok){const o=await n.json();this.used=new Set(o.filter(s=>s.place_id).map(s=>s.place_id));const r=Date.now();this.noInterest=new Set(o.filter(s=>s.place_id&&s.no_interest_until&&new Date(s.no_interest_until).getTime()>r).map(s=>s.place_id)),this.syncAll()}}catch{}}prune(){this.found=this.found.filter(e=>e.host&&document.body.contains(e.host))}parseCard(e,t,n,o){const r=((e==null?void 0:e.innerText)||"")??"",s=n.match(/!3d([-\d.]+)!4d([-\d.]+)/);return{name:t,phone:K(e,r),category:X(r,t),website:F(e),address:W(e),city:null,state:null,rating:Q(r),reviews:G(r),latitude:s?parseFloat(s[1]):null,longitude:s?parseFloat(s[2]):null,place_id:o,maps_url:n||null}}async promptConfig(){var n,o;this.cfg=this.cfg??await y();const e=prompt("URL do projeto Supabase:",((n=this.cfg)==null?void 0:n.supabaseUrl)||"");if(e===null)return;const t=prompt("Chave anon (publishable):",((o=this.cfg)==null?void 0:o.anonKey)||"");if(t!==null){if(!e||!t){alert("Informe URL e chave anon.");return}await N({supabaseUrl:e.replace(/\/+$/,""),anonKey:t}),this.cfg={supabaseUrl:e.replace(/\/+$/,""),anonKey:t},this.subscribeRealtime()}}async doImport(e){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const t=this.found.filter(o=>!this.used.has(o.key)&&this.selected.has(o.key)).map(o=>o.lead).slice(0,50);if(t.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const n=e.innerHTML;e.disabled=!0,e.textContent="Importando…";try{let o=0;const r=await T(this.cfg,t,(s,c)=>{o=s,e.textContent=`${s}/${c}…`});e.textContent=r.failed===0?"✓":`${r.ok} ok, ${r.failed} falharam`,r.failed===0?(b(r.ok>0?`✅ ${r.ok} lead(s) importado(s)!`:"Nenhum lead novo para importar."),this.selected.clear()):b(`⚠️ ${r.ok} ok, ${r.failed} falharam`,"warn"),this.checkUsed(),this.syncAll(),setTimeout(()=>{e.innerHTML=n,e.disabled=!1},2e3)}catch(o){e.textContent=`Erro: ${o}`,setTimeout(()=>{e.innerHTML=n,e.disabled=!1},3e3)}}async doDelete(e){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const t=this.found.filter(o=>this.selected.has(o.key)&&o.lead.place_id).map(o=>o.lead.place_id);if(t.length===0){alert("Selecione pelo menos um lead para excluir.");return}if(!confirm(`Excluir ${t.length} lead(s) do banco?`))return;const n=e.innerHTML;e.disabled=!0,e.innerHTML="Excluindo…";try{const o=await B(this.cfg,t);if(o.failed===0){b(`🗑️ ${o.ok} lead(s) excluído(s)!`);for(const r of t)this.used.delete(r);this.selected.clear()}else b(`⚠️ ${o.ok} ok, ${o.failed} falharam ao excluir`,"warn");this.checkUsed(),this.syncAll()}catch(o){b(`Erro ao excluir: ${o}`,"warn")}finally{e.innerHTML=n,e.disabled=!1}}}const z=()=>{new P().init()};typeof window<"u"&&z();function ie(){z()}function V(){return'a[href*="/maps/place/"]'}function j(a){const e=a.match(/(?:^|[?&])place_id=([^&]+)/);return e?decodeURIComponent(e[1]):null}function O(a){let e=a.parentElement;for(let t=0;t<9&&e&&e.tagName!=="BODY"&&e.getAttribute("role")!=="feed";t++){if(e.getAttribute("role")==="article"||e.querySelector('span[aria-label*="stars"], span[aria-label*="avalia"], span[aria-label*="estrela"]')||e.querySelector('a[href*="/maps/place/"]'))return e;e=e.parentElement}return a.closest('div[role="article"], [role="article"]')??a}function Y(a,e){const n=(a.textContent||"").split(/\s+/).filter(Boolean);if(n.length>0&&n.length<14)return n.slice(0,6).join(" ");const o=a.querySelector('h3, [role="heading"], [style*="font"]'),r=((o==null?void 0:o.textContent)||"").trim();return r?r.split(`
`)[0]:e&&(e.textContent||"").trim().split(`
`)[0]||null}function K(a,e){const t=a==null?void 0:a.querySelector('a[href^="tel:"]');if(t)return t.href.replace("tel:","").trim();const n=e.match(/\(\d{2,3}\)\s?\d[\d\s-]{7,}/);return n?n[0].replace(/\s+/g," ").trim():null}function X(a,e){for(const t of a.split(`
`)){const n=t.trim();if(n&&n!==e&&n.length<40&&!/\d/.test(n)&&!n.startsWith("★")&&!/^\d/.test(n))return n}return null}function F(a){if(!a)return null;const e=['a[data-tooltip="Abrir site"]','a[data-tooltip="Website"]','a[aria-label*="Abrir site"]','a[href]:not([href^="tel:"]):not([href*="/maps/place/"]):not([href^="http://www.google.com/maps"])'];for(const o of e){const r=a.querySelector(o),s=r==null?void 0:r.href;if(s&&s.startsWith("http"))return s.split("&place_id")[0]}const t=a.querySelector('a[href^="http"]'),n=t==null?void 0:t.href;return n&&n.startsWith("http")&&!n.includes("/maps/place/")?n.split("&")[0]:null}function W(a){var t;const e=a==null?void 0:a.querySelector('button[data-tooltip="Endereço"], div[class*="address"], span[data-type="address"]');return((t=e==null?void 0:e.textContent)==null?void 0:t.trim())||null}function Q(a){const e=a.match(/([\d.]+)[\s]*[★✩]/);return e?parseFloat(e[1]):null}function G(a){const e=a.match(/\(([\d.,]+)\)/);return e?parseInt(e[1].replace(/[^\d]/g,""),10):null}function J(){if(document.getElementById("consecom-css"))return;const a=document.createElement("style");a.id="consecom-css",a.textContent=D,document.head.appendChild(a)}function b(a,e="ok"){var o;const t="consecom-toast";(o=document.getElementById(t))==null||o.remove();const n=document.createElement("div");n.id=t,n.className="consecom-toast"+(e==="warn"?" cs-warn":""),n.textContent=a,document.body.appendChild(n),window.setTimeout(()=>{n.classList.add("cs-show")},20),window.setTimeout(()=>n.remove(),4e3)}const Z='<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z"/></svg>',S='<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm2.5 16c-.8 1.3-1.6 2-2.5 2s-1.7-.7-2.5-2c-.7-1.2-1.2-2.8-1.4-4.5h7.8c-.2 1.7-.7 3.3-1.4 4.5zM7.8 11.5c.2-1.7.7-3.3 1.4-4.5.8-1.3 1.6-2 2.5-2s1.7.7 2.5 2c.7 1.2 1.2 2.8 1.4 4.5H7.8zM12 4c.5.7.9 1.6 1.2 2.6h-2.4C10.6 5.6 11.2 4.6 12 4zm-3.1 7c-.1.5-.1 1 0 1.5H5.9a8 8 0 0 1 0-3h3c-.1.5-.1 1 0 1.5zm-1.6 3h3c.1 1.5.4 2.9.9 4-.9-.4-1.6-.9-2.3-1.6-.5-.6-1-1.5-1.6-2.4zM15.1 17c.7.7 1.4 1.2 2.3 1.6-.5-1.1-.8-2.5-.9-4h3a8 8 0 0 1-.9 3c-.5.5-1 .9-1.6 1.2-.6.3-1.3.5-1.9.6v-2.4zm3.6-4.5h-3.1c0-.5 0-1 .1-1.5h3a8 8 0 0 1 0 3h-3c0-.5-.1-1-.1-1.5zM7.1 7c-.7-.7-1.4-1.2-2.3-1.6.5 1.1.8 2.5.9 4h-3a8 8 0 0 1 .9-3c.5-.5 1-.9 1.6-1.2.6-.3 1.3-.5 1.9-.6V7zm0 1.5v2.4c.5 0 1 .1 1.5.1h1.6c-.1-1.4-.4-2.7-.9-3.8-.7.3-1.4.8-2.2 1.3zM12 20c-.5-.7-.9-1.6-1.2-2.6h2.4c-.3 1-.9 1.9-1.2 2.6z"/></svg>',_='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',E='<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',ee='<svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm8.9-3.3a7.5 7.5 0 0 0 0-1.5l2-1.6-2-3.4-2.5 1a7.7 7.7 0 0 0-1.7-1L16 1.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.5 7.5 0 0 0 0 1.5l-2 1.6 2 3.4 2.5-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6zM12 16.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>',te='<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.9-5 4.7 1.3 6.8L12 17.8 5.9 20.7l1.3-6.8-5-4.7 6.9-.9z"/></svg>',ne='<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>',oe='<svg viewBox="0 0 24 24"><path d="M11 5h2v7h2l-3 3-3-3h2V5zm-6 12h14v2H5v-2z"/></svg>',se='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',ae='<svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>';export{P as MapsScanner,ie as startConsecomScanner};
