import{g as f,a as h,s as w}from"./config-6cNGcIy7.js";async function C(a,e){const t=f(a);if(!t)return{ok:0,failed:e.length};let n=0,o=0;for(const i of e){const{error:s}=await t.from("leads").delete().eq("place_id",i);s?o++:n++}return{ok:n,failed:o}}async function k(a,e,t){const n=f(a);if(!n)return{ok:0,failed:e.length,firstError:"Configure a URL e a chave anon do Supabase."};let o=null;if(e.length>0){const{data:c,error:r}=await n.from("capture_sessions").insert({imported_by:"extension"}).select("id").single();!r&&c&&(o=c.id)}let i=0,s=0,l;for(let c=0;c<e.length;c++){const r=e[c],d={name:r.name||null,phone:r.phone||null,category:r.category||null,website:r.website||null,address:r.address||null,city:r.city||null,state:r.state||null,rating:r.rating,reviews:r.reviews,latitude:r.latitude,longitude:r.longitude,place_id:r.place_id||null,niche:"maps",session_id:o},{error:u}=await n.from("leads").upsert(d,{onConflict:"place_id",ignoreDuplicates:!1});u?(s++,l||(l=u.message)):i++,t==null||t(c+1,e.length)}return{ok:i,failed:s,firstError:l}}const _=`/* ===== Bolha flutuante Consecom (arrastável) ===== */
.consecom-bubble {
  position: fixed;
  z-index: 2147483647;
  width: 54px;
  height: 54px;
  border-radius: 50%;
  background: linear-gradient(135deg, #4f46e5, #7c3aed);
  color: #fff;
  cursor: grab;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 28px rgba(79, 70, 229, 0.5);
  user-select: none;
  touch-action: none;
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;
}
.consecom-bubble:active { cursor: grabbing; }
.consecom-bubble__icon {
  font-size: 24px;
  font-weight: 700;
  line-height: 1;
}
.consecom-bubble__count {
  position: absolute;
  top: -6px;
  right: -6px;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 999px;
  background: #ef4444;
  border: 2px solid #fff;
  font-size: 11px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
}

/* ===== Painel vertical (sidebar) aberto pela bolha ===== */
.consecom-balloon {
  position: fixed;
  z-index: 2147483646;
  width: 220px;
  opacity: 0;
  transform: translateY(12px) scale(0.95);
  transform-origin: center bottom;
  pointer-events: none;
  transition: opacity 0.18s ease, transform 0.22s cubic-bezier(0.34, 1.56, 0.64, 1);
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;
}
.consecom-balloon.open {
  opacity: 1;
  transform: translateY(0) scale(1);
  pointer-events: auto;
}
.consecom-balloon__panel {
  position: relative;
  background: #ffffff;
  border: 1px solid #e2e3e7;
  border-radius: 14px;
  box-shadow: 0 14px 44px rgba(0, 0, 0, 0.26);
  padding: 8px;
}
.consecom-balloon__tools {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.consecom-balloon__tools .cs-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  color: #fff;
  padding: 11px 12px;
  transition: transform 0.12s, filter 0.15s;
}
.consecom-balloon__tools .cs-btn:hover:not(:disabled) {
  filter: brightness(1.08);
  transform: translateY(-1px);
}
.consecom-balloon__tools .cs-btn:active:not(:disabled) {
  transform: translateY(0);
}
.consecom-balloon__tools .cs-btn:disabled { opacity: 0.55; cursor: default; }
.cs-import { background: linear-gradient(135deg, #6366f1, #7c3aed); }
.cs-selectall { background: linear-gradient(135deg, #22c55e, #16a34a); }
.cs-delete { background: linear-gradient(135deg, #ef4444, #dc2626); }
.cs-config { background: linear-gradient(135deg, #475569, #334155); }
.cs-config svg { width: 16px; height: 16px; fill: currentColor; }
.consecom-balloon__arrow {
  position: absolute;
  bottom: -7px;
  left: 50%;
  width: 14px;
  height: 14px;
  transform: translateX(-50%) rotate(45deg);
  background: #ffffff;
  border-right: 1px solid #e2e3e7;
  border-bottom: 1px solid #e2e3e7;
}

/* bolha no topo com o menu abaixo (quando sem espaço acima) */
.consecom-balloon.above {
  transform-origin: center top;
}
.consecom-balloon.above .consecom-balloon__arrow {
  top: -7px;
  bottom: auto;
  transform: translateX(-50%) rotate(45deg);
  border-right: none;
  border-bottom: none;
  border-left: 1px solid #e2e3e7;
  border-top: 1px solid #e2e3e7;
}

/* ===== Cards nativos enxutos (nome, site, telefone, selecionar) ===== */
.consecom-host {
  position: relative !important;
  min-width: 0 !important;
}
.consecom-host > *:not(.consecom-control) {
  opacity: 0 !important;
  pointer-events: none !important;
  height: 0 !important;
  overflow: hidden !important;
}
.consecom-control {
  position: relative !important;
  z-index: 30 !important;
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  padding: 5px 8px !important;
  background: #fff !important;
  border: 1px solid #eef0f4 !important;
  border-radius: 6px !important;
  box-sizing: border-box !important;
  min-height: 34px !important;
  font-family: 'Segoe UI', Roboto, system-ui, sans-serif !important;
}
.consecom-control .cs-select { flex: 0 0 auto !important; }
.consecom-control .cs-name {
  flex: 1 !important;
  min-width: 0 !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  color: #1f2937 !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}
.consecom-control .cs-actions {
  display: flex !important;
  gap: 4px !important;
  flex: 0 0 auto !important;
}
.consecom-control .cs-round {
  width: 26px !important;
  height: 26px !important;
  border-radius: 50% !important;
  border: none !important;
  cursor: pointer !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 0 !important;
  background: #4f46e5 !important;
  color: #fff !important;
  box-shadow: 0 1px 4px rgba(79, 70, 229, 0.35) !important;
  transition: transform 0.1s, background 0.15s !important;
}
.consecom-control .cs-round svg { width: 13px; height: 13px; fill: #fff; }
.consecom-control .cs-round:hover:not(:disabled) { background: #4338ca; transform: scale(1.08); }
.consecom-control .cs-round:disabled { background: #eef0f4; box-shadow: none; cursor: default; opacity: 0.6; }
.consecom-control .cs-round:disabled svg { fill: #9ca3af; }
.consecom-control .cs-select { background: #fff; border: 2px solid #4f46e5; color: #4f46e5; }
.consecom-control .cs-select svg { fill: #4f46e5; }
.consecom-control .cs-select.on { background: #4f46e5; color: #fff; }
.consecom-control .cs-select.on svg { fill: #fff; }
.consecom-control .cs-select.used { background: #a5b4fc; border-color: #a5b4fc; color: #fff; }
.consecom-control .cs-select.used svg { fill: #fff; }
.consecom-control .cs-select.nointerest { background: #fecaca; border-color: #ef4444; color: #dc2626; font-weight: 700; }
.consecom-control .cs-badge {
  position: absolute !important;
  top: -8px !important;
  right: -6px !important;
  background: #ef4444 !important;
  color: #fff !important;
  font-size: 9px !important;
  font-weight: 700 !important;
  padding: 1px 5px !important;
  border-radius: 999px !important;
  white-space: nowrap !important;
  box-shadow: 0 1px 3px rgba(0,0,0,.25) !important;
}

/* ===== Toast ===== */
.consecom-toast {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%) translateY(-18px);
  z-index: 2147483647;
  padding: 12px 20px;
  background: #11111a;
  color: #e2e8f0;
  border: 1px solid rgba(16, 185, 129, 0.5);
  border-radius: 12px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
  font-family: 'Inter', -apple-system, 'Segoe UI', Roboto, sans-serif;
  font-size: 14px;
  font-weight: 600;
  opacity: 0;
  transition: opacity 0.25s, transform 0.25s;
  pointer-events: none;
}
.consecom-toast.cs-warn { border-color: rgba(249, 115, 22, 0.6); }
.consecom-toast.cs-show { opacity: 1; transform: translateX(-50%) translateY(0); }`;class L{constructor(){this.cfg=null,this.rtChannel=null,this.found=[],this.selected=new Set,this.used=new Set,this.noInterest=new Set,this.scanning=!1,this.bubble=null,this.balloon=null,this.bCount=null,this.lastQuery="",this.dragging=!1,this.suppressClick=!1,this.debounceUsed=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.checkUsed()},400))}})(),this.debounceScan=(()=>{let e=null;return()=>{e||(e=window.setTimeout(()=>{e=null,this.scan()},350))}})()}async init(){this.cfg=await h(),N(),this.ensureBubble(),this.observeDom(),this.scan("force"),window.addEventListener("click",e=>{var t,n;(t=this.balloon)!=null&&t.classList.contains("open")&&(this.balloon.contains(e.target)||(n=this.bubble)!=null&&n.contains(e.target)||this.toggleBalloon(!1))}),this.subscribeRealtime()}subscribeRealtime(){var t;(t=this.rtChannel)==null||t.unsubscribe(),this.rtChannel=null;const e=this.cfg?f(this.cfg):null;e&&(this.rtChannel=e.channel("consecom-leads-rt").on("postgres_changes",{event:"*",schema:"public",table:"leads"},()=>this.debounceUsed()).subscribe())}observeDom(){new MutationObserver(()=>this.debounceScan()).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("scroll",()=>this.debounceScan(),{passive:!0})}scan(e="scan"){if(!(this.scanning&&e!=="force")){this.scanning=!0;try{this.syncArea(),this.refreshCards(),this.prune(),this.renderControls(),this.renderBalloonList()}finally{this.scanning=!1}}}syncArea(){const e=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]'),t=((e==null?void 0:e.value)||"").trim();t&&t!==this.lastQuery&&(this.lastQuery=t,this.selected.clear(),this.found=[]),t&&(this.lastQuery=t)}renderControls(){if(this.found.length!==0){for(const e of this.found)if(!(!e.host||!document.body.contains(e.host))){if(e.control&&e.control.isConnected){this.updateControl(e);continue}e.control=this.buildControl(e),this.makeHostSlim(e.host),e.host.appendChild(e.control)}}}makeHostSlim(e){e.classList.contains("consecom-host")||e.classList.add("consecom-host")}toggleSelected(e){this.used.has(e)||this.noInterest.has(e)||(this.selected.has(e)?this.selected.delete(e):this.selected.add(e),this.syncAll())}toggleControl(e){this.toggleSelected(e)}selectAllAvailable(){const e=this.found.filter(o=>!this.used.has(o.key)&&!this.noInterest.has(o.key)),t=Math.min(50,e.length),n=new Set;for(let o=0;o<t;o++)n.add(e[o].key);this.selected=n,this.syncAll(),p(`✅ ${this.selected.size} selecionado(s) (máx. 50 por importação)`)}clearSelection(){this.selected.clear(),this.syncAll()}buildControl(e){const t=document.createElement("div");t.className="consecom-control",t.title=e.lead.name;const n=document.createElement("button");n.type="button",n.className="cs-round cs-select",n.title="Selecionar",n.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),this.toggleControl(e.key)});const o=document.createElement("span");o.className="cs-name",o.textContent=e.lead.name,o.title=e.lead.name;const i=document.createElement("div");i.className="cs-actions";const s=document.createElement("button");s.type="button",s.className="cs-round",s.title="Abrir site",s.innerHTML=R,e.lead.website?s.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),window.open(e.lead.website,"_blank","noopener,noreferrer")}):s.disabled=!0;const l=document.createElement("button");l.type="button",l.className="cs-round",l.title="Chamar",l.innerHTML=H,e.lead.phone?l.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),window.location.href=`tel:${e.lead.phone.replace(/\s+/g,"")}`}):l.disabled=!0,i.append(s,l);const c=document.createElement("span");return c.className="cs-badge",c.textContent="Sem interesse",c.style.display="none",t.append(n,o,i,c),t}updateControl(e){var i,s;const t=(i=e.control)==null?void 0:i.querySelector(".cs-select");if(!t)return;const n=this.noInterest.has(e.key);t.classList.toggle("nointerest",n);const o=(s=e.control)==null?void 0:s.querySelector(".cs-badge");if(o&&(o.style.display=n?"block":"none"),n){t.disabled=!0,t.title="Sem interesse — não importar (6 meses)",t.innerHTML="✕";return}this.used.has(e.key)?(t.classList.add("used"),t.disabled=!0,t.title="Já importado anteriormente",t.innerHTML=g):(t.disabled=!1,t.classList.toggle("on",this.selected.has(e.key)),t.title=this.selected.has(e.key)?"Remover seleção":"Selecionar",t.innerHTML=this.selected.has(e.key)?g:q)}buildBubble(){const e=document.createElement("div");e.className="consecom-bubble",e.title="Consecom";const t=document.createElement("span");t.className="consecom-bubble__icon",t.textContent="C";const n=document.createElement("span");return n.className="consecom-bubble__count",n.textContent="0",this.bCount=n,e.append(t,n),this.bubble=e,e.addEventListener("click",()=>{if(this.suppressClick){this.suppressClick=!1;return}this.toggleBalloon()}),this.enableDrag(e),e.style.left=localStorage.getItem("consecom-bubble-x")||"20px",e.style.top=localStorage.getItem("consecom-bubble-top")||"16px",e}ensureBubble(){if(this.bubble&&document.body.contains(this.bubble))return;const e=this.buildBubble();document.body.appendChild(e)}enableDrag(e){let t=0,n=0,o=0,i=0;const s={v:!1},l=d=>{this.dragging=!0,s.v=!1,t=d.clientX,n=d.clientY,o=e.offsetLeft,i=e.offsetTop,e.setPointerCapture(d.pointerId)},c=d=>{var b;if(!this.dragging)return;const u=d.clientX-t,m=d.clientY-n;Math.abs(u)+Math.abs(m)>4&&(s.v=!0);const y=Math.max(0,Math.min(window.innerWidth-60,o+u)),v=Math.max(0,Math.min(window.innerHeight-60,i+m));e.style.left=`${y}px`,e.style.top=`${v}px`,(b=this.balloon)!=null&&b.classList.contains("open")&&this.positionBalloon()},r=d=>{this.dragging&&(e.hasPointerCapture(d.pointerId)&&e.releasePointerCapture(d.pointerId),this.suppressClick=s.v,this.dragging=!1,localStorage.setItem("consecom-bubble-x",e.style.left),localStorage.setItem("consecom-bubble-top",e.style.top))};e.addEventListener("pointerdown",l),e.addEventListener("pointermove",c),e.addEventListener("pointerup",r),e.addEventListener("pointercancel",r)}buildBalloon(){const e=document.createElement("aside");e.className="consecom-balloon";const t=document.createElement("div");t.className="consecom-balloon__panel";const n=document.createElement("div");n.className="consecom-balloon__arrow";const o=document.createElement("div");o.className="consecom-balloon__tools";const i=document.createElement("button");i.type="button",i.className="cs-btn cs-import",i.innerHTML='<span data-role="import-label">Importar</span>',i.addEventListener("click",()=>void this.doImport(i));const s=document.createElement("button");s.type="button",s.className="cs-btn cs-selectall",s.textContent="Selecionar todos",s.addEventListener("click",()=>this.selectAllAvailable());const l=document.createElement("button");l.type="button",l.className="cs-btn cs-delete",l.textContent="Excluir selecionados",l.addEventListener("click",()=>void this.doDelete(l));const c=document.createElement("button");return c.type="button",c.className="cs-btn cs-config",c.title="Configurar Supabase",c.innerHTML="<span>Configurar</span>"+D,c.addEventListener("click",()=>void this.promptConfig()),o.append(i,s,l,c),t.appendChild(o),t.appendChild(n),e.appendChild(t),this.balloon=e,e}renderBalloonList(){if(!this.balloon)return;const e=this.balloon.querySelector('[data-role="import-label"]');e&&(e.textContent=this.selected.size>0?`Importar (${this.selected.size})`:"Importar"),this.updateCounts()}syncAll(){this.updateCounts(),this.renderControls(),this.renderBalloonList()}updateCounts(){this.bCount&&(this.bCount.textContent=`${this.selected.size}`)}toggleBalloon(e){(!this.balloon||!document.body.contains(this.balloon))&&(this.balloon=this.buildBalloon(),document.body.appendChild(this.balloon));const t=e??!this.balloon.classList.contains("open");this.balloon.classList.toggle("open",t),t&&this.positionBalloon(),this.renderBalloonList()}positionBalloon(){if(!this.balloon||!this.bubble)return;const e=this.bubble.offsetWidth,t=this.bubble.offsetHeight,n=this.balloon.offsetWidth,o=this.balloon.offsetHeight,i=this.bubble.offsetLeft,s=this.bubble.offsetTop;let l=i+e/2-n/2;l=Math.max(8,Math.min(window.innerWidth-n-8,l));const c=s-o-12>=8;this.balloon.classList.toggle("above",!c);const r=c?s-o-12:s+t+12;this.balloon.style.left=`${l}px`,this.balloon.style.top=`${r}px`}refreshCards(){const e=document.querySelectorAll(S()),t=new Set;for(const n of Array.from(e)){const o=I(n),i=n.href,s=z(n,o);if(!s)continue;const l=E(i),c=l||i;if(!l&&!i||t.has(c))continue;t.add(c);const r=this.found.find(d=>d.key===c);if(r){r.host=r.host&&document.body.contains(r.host)?r.host:o,r.lead.name=s;continue}this.found.push({lead:this.parseCard(o,s,i,l),host:o,key:c,control:null})}this.checkUsed()}async checkUsed(){const e=this.cfg??await h();if(!e.supabaseUrl||!e.anonKey)return;const t=this.found.map(n=>n.lead.place_id).filter(n=>!!n);if(t.length!==0)try{const n=await fetch(`${e.supabaseUrl}/rest/v1/leads?select=place_id,no_interest_until&place_id=in.(${t.map(encodeURIComponent).join(",")})`,{headers:{apikey:e.anonKey,Authorization:`Bearer ${e.anonKey}`}});if(n.ok){const o=await n.json();this.used=new Set(o.filter(s=>s.place_id).map(s=>s.place_id));const i=Date.now();this.noInterest=new Set(o.filter(s=>s.place_id&&s.no_interest_until&&new Date(s.no_interest_until).getTime()>i).map(s=>s.place_id)),this.syncAll()}}catch{}}prune(){this.found=this.found.filter(e=>e.host&&document.body.contains(e.host))}parseCard(e,t,n,o){const i=((e==null?void 0:e.innerText)||"")??"",s=n.match(/!3d([-\d.]+)!4d([-\d.]+)/);return{name:t,phone:M(e,i),category:B(i,t),website:T(e),address:$(e),city:null,state:null,rating:U(i),reviews:A(i),latitude:s?parseFloat(s[1]):null,longitude:s?parseFloat(s[2]):null,place_id:o,maps_url:n||null}}async promptConfig(){var n,o;this.cfg=this.cfg??await h();const e=prompt("URL do projeto Supabase:",((n=this.cfg)==null?void 0:n.supabaseUrl)||"");if(e===null)return;const t=prompt("Chave anon (publishable):",((o=this.cfg)==null?void 0:o.anonKey)||"");if(t!==null){if(!e||!t){alert("Informe URL e chave anon.");return}await w({supabaseUrl:e.replace(/\/+$/,""),anonKey:t}),this.cfg={supabaseUrl:e.replace(/\/+$/,""),anonKey:t},this.subscribeRealtime()}}async doImport(e){if(this.cfg=this.cfg??await h(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const t=this.found.filter(o=>!this.used.has(o.key)&&this.selected.has(o.key)).map(o=>o.lead).slice(0,50);if(t.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const n=e.innerHTML;e.disabled=!0,e.textContent="Importando…";try{let o=0;const i=await k(this.cfg,t,(s,l)=>{o=s,e.textContent=`${s}/${l}…`});e.textContent=i.failed===0?"✓":`${i.ok} ok, ${i.failed} falharam`,i.failed===0?(p(i.ok>0?`✅ ${i.ok} lead(s) importado(s)!`:"Nenhum lead novo para importar."),this.selected.clear()):p(`⚠️ ${i.ok} ok, ${i.failed} falharam`,"warn"),this.checkUsed(),this.syncAll(),setTimeout(()=>{e.innerHTML=n,e.disabled=!1},2e3)}catch(o){e.textContent=`Erro: ${o}`,setTimeout(()=>{e.innerHTML=n,e.disabled=!1},3e3)}}async doDelete(e){if(this.cfg=this.cfg??await h(),!this.cfg||!this.cfg.supabaseUrl||!this.cfg.anonKey){alert("Configure a URL do Supabase e a chave anon primeiro (⚙).");return}const t=this.found.filter(o=>this.selected.has(o.key)&&o.lead.place_id).map(o=>o.lead.place_id);if(t.length===0){alert("Selecione pelo menos um lead para excluir.");return}if(!confirm(`Excluir ${t.length} lead(s) do banco?`))return;const n=e.innerHTML;e.disabled=!0,e.innerHTML="Excluindo…";try{const o=await C(this.cfg,t);if(o.failed===0){p(`🗑️ ${o.ok} lead(s) excluído(s)!`);for(const i of t)this.used.delete(i);this.selected.clear()}else p(`⚠️ ${o.ok} ok, ${o.failed} falharam ao excluir`,"warn");this.checkUsed(),this.syncAll()}catch(o){p(`Erro ao excluir: ${o}`,"warn")}finally{e.innerHTML=n,e.disabled=!1}}}const x=()=>{new L().init()};typeof window<"u"&&x();function j(){x()}function S(){return'a[href*="/maps/place/"]'}function E(a){const e=a.match(/(?:^|[?&])place_id=([^&]+)/);return e?decodeURIComponent(e[1]):null}function I(a){let e=a.parentElement;for(let t=0;t<9&&e&&e.tagName!=="BODY"&&e.getAttribute("role")!=="feed";t++){if(e.getAttribute("role")==="article"||e.querySelector('span[aria-label*="stars"], span[aria-label*="avalia"], span[aria-label*="estrela"]')||e.querySelector('a[href*="/maps/place/"]'))return e;e=e.parentElement}return a.closest('div[role="article"], [role="article"]')??a}function z(a,e){const n=(a.textContent||"").split(/\s+/).filter(Boolean);if(n.length>0&&n.length<14)return n.slice(0,6).join(" ");const o=a.querySelector('h3, [role="heading"], [style*="font"]'),i=((o==null?void 0:o.textContent)||"").trim();return i?i.split(`
`)[0]:e&&(e.textContent||"").trim().split(`
`)[0]||null}function M(a,e){const t=a==null?void 0:a.querySelector('a[href^="tel:"]');if(t)return t.href.replace("tel:","").trim();const n=e.match(/\(\d{2,3}\)\s?\d[\d\s-]{7,}/);return n?n[0].replace(/\s+/g," ").trim():null}function B(a,e){for(const t of a.split(`
`)){const n=t.trim();if(n&&n!==e&&n.length<40&&!/\d/.test(n)&&!n.startsWith("★")&&!/^\d/.test(n))return n}return null}function T(a){if(!a)return null;const e=['a[data-tooltip="Abrir site"]','a[data-tooltip="Website"]','a[aria-label*="Abrir site"]','a[href]:not([href^="tel:"]):not([href*="/maps/place/"]):not([href^="http://www.google.com/maps"])'];for(const o of e){const i=a.querySelector(o),s=i==null?void 0:i.href;if(s&&s.startsWith("http"))return s.split("&place_id")[0]}const t=a.querySelector('a[href^="http"]'),n=t==null?void 0:t.href;return n&&n.startsWith("http")&&!n.includes("/maps/place/")?n.split("&")[0]:null}function $(a){var t;const e=a==null?void 0:a.querySelector('button[data-tooltip="Endereço"], div[class*="address"], span[data-type="address"]');return((t=e==null?void 0:e.textContent)==null?void 0:t.trim())||null}function U(a){const e=a.match(/([\d.]+)[\s]*[★✩]/);return e?parseFloat(e[1]):null}function A(a){const e=a.match(/\(([\d.,]+)\)/);return e?parseInt(e[1].replace(/[^\d]/g,""),10):null}function N(){if(document.getElementById("consecom-css"))return;const a=document.createElement("style");a.id="consecom-css",a.textContent=_,document.head.appendChild(a)}function p(a,e="ok"){var o;const t="consecom-toast";(o=document.getElementById(t))==null||o.remove();const n=document.createElement("div");n.id=t,n.className="consecom-toast"+(e==="warn"?" cs-warn":""),n.textContent=a,document.body.appendChild(n),window.setTimeout(()=>{n.classList.add("cs-show")},20),window.setTimeout(()=>n.remove(),4e3)}const H='<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z"/></svg>',R='<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm2.5 16c-.8 1.3-1.6 2-2.5 2s-1.7-.7-2.5-2c-.7-1.2-1.2-2.8-1.4-4.5h7.8c-.2 1.7-.7 3.3-1.4 4.5zM7.8 11.5c.2-1.7.7-3.3 1.4-4.5.8-1.3 1.6-2 2.5-2s1.7.7 2.5 2c.7 1.2 1.2 2.8 1.4 4.5H7.8zM12 4c.5.7.9 1.6 1.2 2.6h-2.4C10.6 5.6 11.2 4.6 12 4zm-3.1 7c-.1.5-.1 1 0 1.5H5.9a8 8 0 0 1 0-3h3c-.1.5-.1 1 0 1.5zm-1.6 3h3c.1 1.5.4 2.9.9 4-.9-.4-1.6-.9-2.3-1.6-.5-.6-1-1.5-1.6-2.4zM15.1 17c.7.7 1.4 1.2 2.3 1.6-.5-1.1-.8-2.5-.9-4h3a8 8 0 0 1-.9 3c-.5.5-1 .9-1.6 1.2-.6.3-1.3.5-1.9.6v-2.4zm3.6-4.5h-3.1c0-.5 0-1 .1-1.5h3a8 8 0 0 1 0 3h-3c0-.5-.1-1-.1-1.5zM7.1 7c-.7-.7-1.4-1.2-2.3-1.6.5 1.1.8 2.5.9 4h-3a8 8 0 0 1 .9-3c.5-.5 1-.9 1.6-1.2.6-.3 1.3-.5 1.9-.6V7zm0 1.5v2.4c.5 0 1 .1 1.5.1h1.6c-.1-1.4-.4-2.7-.9-3.8-.7.3-1.4.8-2.2 1.3zM12 20c-.5-.7-.9-1.6-1.2-2.6h2.4c-.3 1-.9 1.9-1.2 2.6z"/></svg>',g='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',q='<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',D='<svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm8.9-3.3a7.5 7.5 0 0 0 0-1.5l2-1.6-2-3.4-2.5 1a7.7 7.7 0 0 0-1.7-1L16 1.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.5 7.5 0 0 0 0 1.5l-2 1.6 2 3.4 2.5-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6zM12 16.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>';export{L as MapsScanner,j as startConsecomScanner};
