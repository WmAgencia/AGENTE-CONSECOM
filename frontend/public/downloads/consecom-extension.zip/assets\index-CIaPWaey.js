const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/global-DONg-1Kz.js","assets/config-SYaVBN7W.js"])))=>i.map(i=>d[i]);
import{g as y}from"./config-SYaVBN7W.js";const Y="modulepreload",G=function(r){return"/"+r},q={},T=function(t,e,n){let a=Promise.resolve();if(e&&e.length>0){document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),i=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));a=Promise.allSettled(e.map(l=>{if(l=G(l),l in q)return;q[l]=!0;const p=l.endsWith(".css"),u=p?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${u}`))return;const c=document.createElement("link");if(c.rel=p?"stylesheet":Y,p||(c.as="script"),c.crossOrigin="",c.href=l,i&&c.setAttribute("nonce",i),document.head.appendChild(c),p)return new Promise((d,m)=>{c.addEventListener("load",d),c.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${l}`)))})}))}function o(s){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=s,window.dispatchEvent(i),!i.defaultPrevented)throw s}return a.then(s=>{for(const i of s||[])i.status==="rejected"&&o(i.reason);return t().catch(o)})},Q={maps:!0,webmotors:!0,wepsy:!0};async function K(){try{const r=await chrome.runtime.sendMessage({type:"consecom:api",path:"/api/extension/sites",method:"GET"}),t=(r==null?void 0:r.data)??{};return{maps:t.maps!==!1,webmotors:t.webmotors!==!1,wepsy:t.wepsy!==!1}}catch{return{...Q}}}async function N(r,t,e={}){const n=await y(),a=await chrome.runtime.sendMessage({type:"consecom:api",path:r,method:"POST",headers:e,body:t,extensionKey:n.extensionKey});return(a==null?void 0:a.ok)===!1&&(a==null?void 0:a.status)===403?{ok:!1,status:403,data:{message:"Extensão não vinculada. Baixe novamente a extensão no painel Vyntra."}}:a??{ok:!1,status:0,data:{message:"Sem resposta do background."}}}async function U(r,t){if(t.length===0)return{ok:0,failed:0};const e=await N("/api/extension/delete",{placeIds:t,ownerUserId:r.ownerUserId});if(!e.ok)return{ok:0,failed:t.length};const n=e.data??{};return{ok:Number(n.ok??0),failed:Number(n.failed??0)}}async function X(r){if(!r.extensionKey||!r.ownerUserId)return null;const t=await N("/api/extension/plan",{ownerUserId:r.ownerUserId});if(!t.ok)return null;const e=t.data??{};return typeof e.limited!="boolean"?null:{limited:e.limited,used:Number(e.used??0),limit:Number(e.limit??0),remaining:e.remaining==null?null:Number(e.remaining)}}async function $(r,t,e,n){var p,u,c,d;if(!r.extensionKey||!r.ownerUserId)return{ok:0,failed:t.length,firstError:"Extensão não vinculada a uma conta Vyntra. Baixe novamente a extensão no painel.",errors:[]};const a=t.map(m=>({name:m.name,phone:m.phone??"",category:m.category,website:m.website,address:m.address,city:m.city,state:m.state,rating:m.rating,reviews:m.reviews,latitude:m.latitude,longitude:m.longitude,place_id:m.place_id,instagram:m.instagram,facebook:m.facebook})),o=await N("/api/extension/import-leads",{ownerUserId:r.ownerUserId,leads:a,listName:`Importação ${new Date().toISOString().slice(0,10)}`,source:(n==null?void 0:n.source)??"google_maps",sourceDetail:(n==null?void 0:n.sourceDetail)??"vyntra_prospector",tags:n==null?void 0:n.tags,prospectFilters:n==null?void 0:n.prospectFilters,score:n==null?void 0:n.score,serviceInterest:n==null?void 0:n.serviceInterest,prospectedAt:(n==null?void 0:n.prospectedAt)??new Date().toISOString()});if(!o.ok){const m=o.data??{},h=m.message??m.error??`HTTP ${o.status}`;return console.error("[IMPORT] Backend import failed:",{status:o.status,message:h}),{ok:0,failed:t.length,firstError:h,errors:[],quota:m.quota??null}}const s=o.data??{},i=Number(((p=s.summary)==null?void 0:p.created)??0),l=Number(((u=s.summary)==null?void 0:u.errors)??0);return console.log("[IMPORT] Backend import response:",{status:o.status,ok:i,failed:l}),t.forEach((m,h)=>e==null?void 0:e(h+1,t.length)),{ok:i,failed:l,firstError:typeof((c=s.firstError)==null?void 0:c.body)=="string"?s.firstError.body:void 0,errors:[],quotaCut:Number(((d=s.summary)==null?void 0:d.quotaCut)??0),quota:s.quota??null}}async function j(r,t){if(t.length===0)return{used:[],noInterest:{}};const e=await N("/api/extension/known",{placeIds:t});if(!e.ok)return{used:[],noInterest:{}};const n=e.data??{};return{used:Array.isArray(n.used)?n.used:[],noInterest:n.noInterest??{}}}const J=Object.freeze(Object.defineProperty({__proto__:null,deleteLeads:U,getExtensionSites:K,getPlanQuota:X,importLeads:$,knownPlaceIds:j},Symbol.toStringTag,{value:"Module"}));function z(r){let t=0;r.rating!=null&&r.rating>0&&(t=Math.min(45,Math.round(r.rating/5*45)));let e=0;r.reviews!=null&&r.reviews>0&&(e=Math.min(30,Math.round(Math.log10(r.reviews+1)/Math.log10(1e4)*30)));const n=r.website?10:0,a=r.phone?10:0,o=r.category?5:0,s=Math.max(0,Math.min(100,t+e+n+a+o)),i=tt(s);return{total:s,band:i,label:Z[i],parts:{rating:t,reviews:e,website:n,phone:a,category:o}}}const Z={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Oportunidade média",baixa:"Baixa oportunidade",nenhuma:"Sem dados"};function tt(r){return r>=90?"alta":r>=70?"boa":r>=50?"media":r>=1?"baixa":"nenhuma"}function et(r){return"cs-band-"+r}function St(r,t){return!(t.has("com_whatsapp")&&r.whatsapp===!1||t.has("sem_site")&&r.website||t.has("nota_baixa")&&r.rating!=null&&r.rating>=3.5)}const nt=[{id:"sem_site",label:"Sem site",cat:"site",value:"sem_site",accent:"#f87171"},{id:"alta",label:"Alta oportunidade",cat:"score",value:"alta",accent:"#10b981"},{id:"site_ruim",label:"Site ruim",cat:"site",value:"site_ruim",accent:"#f59e0b"},{id:"poucas_avaliacoes",label:"Poucas avaliações",cat:"qualify",value:"poucas_avaliacoes",accent:"#a855f7"},{id:"nota_baixa",label:"Nota baixa",cat:"qualify",value:"nota_baixa",accent:"#f87171"},{id:"sem_presenca_digital",label:"Sem presença digital",cat:"digital",value:"sem_presenca_digital",accent:"#64748b"},{id:"tem_telefone",label:"Tem telefone",cat:"qualify",value:"tem_telefone",accent:"#22c55e"},{id:"sem_instagram",label:"Sem Instagram",cat:"digital",value:"sem_instagram",accent:"#ec4899"},{id:"sem_whatsapp",label:"Sem WhatsApp",cat:"digital",value:"sem_whatsapp",accent:"#f87171"},{id:"tem_whatsapp",label:"Tem WhatsApp",cat:"digital",value:"tem_whatsapp",accent:"#22c55e"},{id:"tem_site",label:"Tem site",cat:"site",value:"site_bom",accent:"#22c55e"},{id:"boa",label:"Boa oportunidade",cat:"score",value:"boa",accent:"#84cc16"},{id:"media",label:"Média oportunidade",cat:"score",value:"media",accent:"#f59e0b"},{id:"baixa",label:"Baixa oportunidade",cat:"score",value:"baixa",accent:"#f87171"}],at={site:[],digital:[],qualify:[],minRating:null,minReviews:null,scoreBands:[],service:"todos",activeChips:new Set};function F(r,t){if(t.site.length>0&&!ot(r,t.site)||t.digital.length>0&&!rt(r,t.digital)||t.qualify.length>0&&!st(r,t.qualify)||t.minRating!=null&&t.minRating>0&&(r.rating==null||r.rating<t.minRating)||t.minReviews!=null&&t.minReviews>0&&(r.reviews==null||r.reviews<t.minReviews))return!1;if(t.scoreBands.length>0){const e=z(r);if(e.band==="nenhuma"||!t.scoreBands.includes(e.band))return!1}return!0}function ot(r,t){const e=!!r.website;for(const n of t)switch(n){case"sem_site":if(!e)return!0;break;case"site_bom":case"site_profissional":case"site_ruim":case"site_desatualizado":case"site_nao_responsivo":case"site_lento":case"site_amador":case"site_quebrado":case"site_problemas":if(e)return!0;break}return!1}function rt(r,t){const e=!!r.instagram,n=!!r.facebook,a=!!r.phone;for(const o of t)switch(o){case"sem_instagram":if(!e)return!0;break;case"instagram_encontrado":if(e)return!0;break;case"sem_facebook":if(!n)return!0;break;case"sem_presenca_digital":if(!e&&!n&&!a)return!0;break;case"sem_whatsapp":if(!a)return!0;break;case"tem_whatsapp":if(a)return!0;break;case"instagram_pouco_ativo":case"instagram_sem_link_site":if(e)return!0;break}return!1}function st(r,t){for(const e of t)switch(e){case"tem_telefone":if(r.phone)return!0;break;case"tem_site":if(r.website)return!0;break;case"poucas_avaliacoes":if(r.reviews==null||r.reviews<10)return!0;break;case"muitas_avaliacoes":if(r.reviews!=null&&r.reviews>=100)return!0;break;case"nota_baixa":if(r.rating==null||r.rating<4)return!0;break}return!1}function it(r){const t=[],e={sem_site:"Sem site",site_ruim:"Site ruim",site_desatualizado:"Site desatualizado",site_nao_responsivo:"Site não responsivo",site_lento:"Site lento",site_amador:"Site amador",site_quebrado:"Site quebrado",site_problemas:"Site com problemas",site_bom:"Site bom",site_profissional:"Site profissional"},n={sem_instagram:"Sem Instagram",instagram_encontrado:"Instagram encontrado",instagram_pouco_ativo:"Instagram pouco ativo",instagram_sem_link_site:"Instagram sem link para site",sem_facebook:"Sem Facebook",sem_presenca_digital:"Sem presença digital",sem_whatsapp:"Sem WhatsApp",tem_whatsapp:"Tem WhatsApp"},a={tem_telefone:"Tem telefone",poucas_avaliacoes:"Poucas avaliações",nota_baixa:"Nota baixa",muitas_avaliacoes:"Muitas avaliações",tem_site:"Tem site"};for(const s of r.site)t.push(e[s]);for(const s of r.digital)t.push(n[s]);for(const s of r.qualify)t.push(a[s]);r.minRating!=null&&r.minRating>0&&t.push(`${r.minRating.toFixed(1)}+ estrelas`),r.minReviews!=null&&r.minReviews>0&&t.push(`${r.minReviews}+ avaliações`);const o={alta:"Alta oportunidade",boa:"Boa oportunidade",media:"Média oportunidade",baixa:"Baixa oportunidade"};for(const s of r.scoreBands)t.push(o[s]);return t}const ct=`/* ===== Vyntra Prospector — identidade visual do sistema (tema claro, Inter, verde WhatsApp) ===== */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {
  --vy-font: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
  --vy-bg: #ffffff;
  --vy-app: #eef3f1;
  --vy-panel: #ffffff;
  --vy-card: rgba(4, 120, 87, 0.04);
  --vy-card-hover: rgba(4, 120, 87, 0.07);
  --vy-line: #e3e8e6;
  --vy-line-2: #d5ddd9;
  --vy-line-strong: #c3cec9;
  --vy-fg: #10231c;
  --vy-secondary: #1f2b26;
  --vy-muted: #5b6b64;
  --vy-faint: #8a9a93;
  --vy-accent: #059669;
  --vy-accent-600: #047857;
  --vy-accent-700: #065f46;
  --vy-accent-soft: rgba(4, 120, 87, 0.1);
  --vy-danger: #dc2626;
  --vy-danger-soft: rgba(220, 38, 38, 0.08);
  --vy-warn: #d97706;
  --vy-shadow: 0 8px 28px rgba(15, 23, 42, 0.1), 0 2px 6px rgba(15, 23, 42, 0.05);
  --vy-shadow-strong: 0 16px 44px rgba(15, 23, 42, 0.16), 0 4px 10px rgba(15, 23, 42, 0.07);
}

/* ===== Botão flutuante Vyntra (quando painel minimizado) ===== */
.consecom-floatbtn {
  position: fixed;
  z-index: 2147483647;
  width: 48px;
  height: 48px;
  border-radius: 15px;
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  color: #fff;
  cursor: grab;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 12px 32px rgba(4, 120, 87, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.22);
  user-select: none;
  touch-action: none;
  font-family: var(--vy-font);
  font-size: 22px;
  font-weight: 800;
  font-style: italic;
  line-height: 1;
  border: none;
  transition: transform 0.12s, filter 0.15s;
  padding: 0;
}
.consecom-floatbtn:active { cursor: grabbing; }
.consecom-floatbtn:hover { filter: brightness(1.08); transform: translateY(-1px) scale(1.03); }
.consecom-floatbtn {
  opacity: 0;
  transform: scale(0.85);
  transition: opacity 0.16s ease, transform 0.18s ease, filter 0.12s;
  pointer-events: none;
}
.consecom-floatbtn.open {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}

/* ===== Painel flutuante Vyntra (arrastável) ===== */
.consecom-balloon {
  position: fixed;
  z-index: 2147483647;
  top: 20px;
  right: 20px;
  width: 230px;
  max-width: calc(100vw - 24px);
  height: min(660px, calc(100vh - 24px));
  max-height: calc(100vh - 24px);
  min-height: 60px;
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 18px;
  box-shadow: var(--vy-shadow-strong);
  display: flex;
  flex-direction: column;
  opacity: 0;
  transform: translateX(calc(110% + 20px)) scale(0.96);
  pointer-events: none;
  transition: transform 0.18s ease, opacity 0.16s ease;
  font-family: var(--vy-font);
  overflow: hidden;
  color: var(--vy-fg);
}
.consecom-balloon.open {
  opacity: 1;
  transform: translateX(0) scale(1);
  pointer-events: auto;
}

/* ===== Header (grip + logo + título + Conta + fechar) ===== */
.cs-balloon-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 11px;
  border-bottom: 1px solid var(--vy-line);
  cursor: grab;
  flex-shrink: 0;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  background:
    radial-gradient(120% 160% at 100% -20%, rgba(16, 185, 129, 0.16), transparent 55%),
    linear-gradient(135deg, #ffffff, #eef7f2);
  position: relative;
}
.cs-balloon-header::after {
  content: "";
  position: absolute;
  left: 0; right: 0; bottom: -1px;
  height: 2px;
  background: linear-gradient(90deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
}
.cs-balloon-header:active { cursor: grabbing; }
.cs-grip {
  cursor: grab;
  color: var(--vy-faint);
  font-size: 16px;
  letter-spacing: -2px;
  line-height: 1;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  padding: 0 2px;
}
.cs-grip:active { cursor: grabbing; }
.cs-logo {
  width: 26px;
  height: 26px;
  border-radius: 9px;
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 800;
  font-size: 13px;
  font-style: italic;
  box-shadow: 0 4px 12px rgba(4, 120, 87, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.25);
}
.cs-title {
  font-size: 13px;
  font-weight: 800;
  letter-spacing: 0.02em;
  color: var(--vy-fg);
  flex: 1;
  min-width: 0;
}
.cs-head-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}
.cs-icon-btn {
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: transparent;
  border: 1px solid transparent;
  color: var(--vy-muted);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.12s, color 0.12s, border-color 0.12s;
  padding: 0;
}
.cs-icon-btn:hover {
  background: var(--vy-accent-soft);
  color: var(--vy-accent);
  border-color: var(--vy-line-2);
}
.cs-icon-btn svg { width: 14px; height: 14px; fill: currentColor; }

/* ===== Body com scroll interno ===== */
.cs-balloon-body {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  min-height: 0;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: linear-gradient(180deg, #f4f9f6, var(--vy-app));
}
.cs-balloon-body::-webkit-scrollbar { width: 6px; }
.cs-balloon-body::-webkit-scrollbar-thumb { background: var(--vy-line-strong); border-radius: 999px; }

/* ===== Bloco/seção padronizado (header + conteúdo) ===== */
.cs-block {
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 14px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.03);
}
.cs-block__title {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--vy-muted);
}

/* ===== Busca ===== */
.cs-search {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cs-search__fields { display: flex; gap: 6px; }
.cs-search__field { flex: 1; display: flex; flex-direction: column; gap: 3px; }
.cs-search__field--sm { flex: 0 0 56px; }
.cs-search__field > span {
  font-size: 9px;
  font-weight: 700;
  letter-spacing: 0.08em;
  color: var(--vy-muted);
}
.cs-search__input {
  width: 100%;
  box-sizing: border-box;
  padding: 8px 10px;
  background: var(--vy-panel);
  border: 1px solid var(--vy-line-2);
  border-radius: 10px;
  color: var(--vy-fg);
  font-size: 12px;
  font-family: var(--vy-font);
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
}
.cs-search__input::placeholder { color: var(--vy-faint); }
.cs-search__input:focus {
  border-color: var(--vy-accent);
  box-shadow: 0 0 0 3px var(--vy-accent-soft);
}
.cs-search__btn {
  width: 100%;
  padding: 9px 0;
  border: 1px solid var(--vy-line-2);
  border-radius: 999px;
  background: var(--vy-panel);
  color: var(--vy-fg);
  font-family: var(--vy-font);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.04em;
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s, box-shadow 0.15s;
}
.cs-search__btn:hover {
  background: var(--vy-accent-soft);
  border-color: var(--vy-accent);
  color: var(--vy-accent);
  box-shadow: 0 4px 12px rgba(4, 120, 87, 0.12);
}

/* Status de localização (linha auxiliar na busca) */
.cs-loc {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  font-size: 11px;
  color: var(--vy-muted);
  text-align: center;
  padding: 2px 0;
}
.cs-loc svg { width: 12px; height: 12px; fill: currentColor; }

/* ===== Filtros (chips) ===== */
.cs-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}
.cs-chip {
  font-family: var(--vy-font);
  font-size: 10.5px;
  font-weight: 600;
  padding: 5px 9px;
  border-radius: 999px;
  background: var(--vy-panel);
  color: var(--vy-secondary);
  border: 1px solid var(--vy-line-2);
  cursor: pointer;
  transition: background 0.12s, color 0.12s, border-color 0.12s;
  white-space: nowrap;
}
.cs-chip:hover {
  border-color: var(--vy-accent);
  color: var(--vy-accent);
}
.cs-chip--on {
  background: var(--vy-accent) !important;
  color: #fff !important;
  border-color: var(--vy-accent) !important;
}

/* ===== PROSPECTAR (CTA principal) ===== */
.cs-prospect {
  padding: 13px 0;
  border: none;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  color: #fff;
  font-family: var(--vy-font);
  font-size: 14px;
  font-weight: 800;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  cursor: pointer;
  transition: filter 0.15s, transform 0.12s, box-shadow 0.15s;
  box-shadow: 0 6px 18px rgba(4, 120, 87, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.22);
}
.cs-prospect:hover:not(:disabled) {
  filter: brightness(1.06);
  transform: translateY(-1px);
  box-shadow: 0 10px 24px rgba(4, 120, 87, 0.34);
}
.cs-prospect:disabled { opacity: 0.6; cursor: default; transform: none; box-shadow: none; }

/* Ações lado a lado: PROSPECTAR + PARAR */
.cs-prospect-actions {
  display: flex;
  flex-direction: row;
  gap: 6px;
}
.cs-prospect-actions .cs-stop {
  flex: 0 0 auto;
}

/* ===== Área de leads com scroll ===== */
.cs-leads {
  flex: 1;
  min-height: 140px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cs-list {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-right: 2px;
}
.cs-list::-webkit-scrollbar { width: 5px; }
.cs-list::-webkit-scrollbar-thumb { background: var(--vy-line-strong); border-radius: 999px; }

/* Card de lead */
.cs-card,
.cs-pcard {
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 10px;
  padding: 9px 10px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  transition: border-color 0.15s, background 0.15s;
}
.cs-card:hover,
.cs-pcard:hover { border-color: var(--vy-line-strong); }
.cs-card__top,
.cs-pcard__top {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.cs-card__name,
.cs-pcard__name {
  flex: 1;
  min-width: 0;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--vy-fg);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cs-card__badge,
.cs-pcard__badge {
  font-size: 9.5px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 999px;
  letter-spacing: 0.02em;
  white-space: nowrap;
  flex: 0 0 auto;
}
.cs-band-alta { color: var(--vy-accent-700); background: rgba(4, 120, 87, 0.12); border: 1px solid rgba(4, 120, 87, 0.25); }
.cs-band-boa { color: var(--vy-accent-600); background: rgba(4, 120, 87, 0.08); border: 1px solid rgba(4, 120, 87, 0.2); }
.cs-band-media { color: var(--vy-warn); background: rgba(217, 119, 6, 0.1); border: 1px solid rgba(217, 119, 6, 0.25); }
.cs-band-baixa { color: var(--vy-danger); background: var(--vy-danger-soft); border: 1px solid rgba(220, 38, 38, 0.2); }
.cs-band-nenhuma { color: var(--vy-muted); background: rgba(91, 107, 100, 0.08); border: 1px solid var(--vy-line-strong); }

.cs-card__meta,
.cs-pcard__meta {
  font-size: 11px;
  color: var(--vy-muted);
  display: flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cs-card__rating,
.cs-pcard__rating {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  font-size: 11px;
  color: var(--vy-warn);
  font-weight: 700;
}
.cs-card__rating svg,
.cs-pcard__rating svg { width: 11px; height: 11px; fill: currentColor; }

/* Barra de score */
.cs-card__bar,
.cs-pcard__scorebar {
  display: flex;
  align-items: center;
  gap: 8px;
}
.cs-card__btrack,
.cs-pcard__bar {
  flex: 1;
  height: 5px;
  border-radius: 999px;
  background: var(--vy-line);
  overflow: hidden;
}
.cs-card__bfill,
.cs-pcard__barfill {
  height: 100%;
  border-radius: 999px;
  background: var(--vy-accent);
  transition: width 0.4s ease;
}
.cs-card__score,
.cs-pcard__score {
  font-size: 10.5px;
  font-weight: 800;
  color: var(--vy-fg);
  flex: 0 0 auto;
}
.cs-card__score small,
.cs-pcard__score small { color: var(--vy-muted); font-weight: 600; }

/* Ações do card (botão de selecionar como lead) */
.cs-card__actions,
.cs-pcard__actions { display: flex; gap: 6px; margin-top: 1px; }
.cs-card__btn,
.cs-pcard__btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 7px 8px;
  border: none;
  border-radius: 9px;
  font-family: var(--vy-font);
  font-size: 11.5px;
  font-weight: 700;
  cursor: pointer;
  transition: filter 0.12s, background 0.12s;
}
.cs-card__btn svg,
.cs-pcard__btn svg { width: 12px; height: 12px; fill: currentColor; }
.cs-card__lead,
.cs-pcard__lead {
  background: var(--vy-accent);
  color: #fff;
}
.cs-card__lead:hover:not(:disabled),
.cs-pcard__lead:hover:not(:disabled) { filter: brightness(1.06); }
.cs-card__lead.on,
.cs-pcard__lead.on { background: var(--vy-accent-700); }
.cs-card__lead.used,
.cs-pcard__lead.used { background: var(--vy-line); color: var(--vy-muted); cursor: default; }
.cs-card__lead.nointerest,
.cs-pcard__lead.nointerest { background: var(--vy-danger-soft); color: var(--vy-danger); }
.cs-card__site,
.cs-pcard__site {
  background: var(--vy-card);
  color: var(--vy-fg);
}
.cs-card__site:hover:not(:disabled),
.cs-pcard__site:hover:not(:disabled) { background: var(--vy-card-hover); }
.cs-card__site:disabled,
.cs-pcard__site:disabled { opacity: 0.4; cursor: default; }

/* ===== Mini-card CONTA (toggle no header) ===== */
.cs-account {
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 12px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  animation: cs-fadein 0.18s ease;
}
@keyframes cs-fadein { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: none; } }
.cs-account__head {
  display: flex;
  align-items: center;
  gap: 8px;
}
.cs-account__avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--vy-accent-soft);
  color: var(--vy-accent-700);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 14px;
}
.cs-account__head-text { flex: 1; min-width: 0; }
.cs-account__title {
  font-size: 12px;
  font-weight: 700;
  color: var(--vy-fg);
}
.cs-account__sub {
  font-size: 10.5px;
  color: var(--vy-muted);
}
.cs-account__quota {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  color: var(--vy-muted);
  padding-top: 8px;
  border-top: 1px dashed var(--vy-line);
}
.cs-account__quota strong { color: var(--vy-fg); font-weight: 700; }
.cs-account__progress {
  height: 6px;
  border-radius: 999px;
  background: var(--vy-line);
  overflow: hidden;
}
.cs-account__progress-fill {
  height: 100%;
  background: var(--vy-accent);
  border-radius: 999px;
  transition: width 0.4s ease;
}
.cs-account__progress-fill--full { background: var(--vy-danger); }
.cs-account__badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 999px;
  background: var(--vy-accent-soft);
  color: var(--vy-accent-700);
}
.cs-account__badge--off { background: var(--vy-danger-soft); color: var(--vy-danger); }

/* ===== Rodapé do painel ===== */
.cs-balloon-footer {
  border-top: 1px solid var(--vy-line);
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  background: var(--vy-panel);
}
.cs-foot-row { display: flex; gap: 6px; }
.cs-btn {
  border: 1px solid var(--vy-line-2);
  background: var(--vy-panel);
  color: var(--vy-secondary);
  border-radius: 10px;
  padding: 8px 10px;
  font-family: var(--vy-font);
  font-size: 11.5px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s, color 0.12s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  flex: 1;
}
.cs-btn svg { width: 13px; height: 13px; fill: currentColor; }
.cs-btn:hover:not(:disabled) {
  background: var(--vy-accent-soft);
  border-color: var(--vy-accent);
  color: var(--vy-accent);
}
.cs-btn:disabled { opacity: 0.5; cursor: default; }
.cs-btn--primary {
  background: linear-gradient(135deg, var(--vy-accent-600), var(--vy-accent) 60%, #10b981);
  color: #fff;
  border-color: transparent;
  font-weight: 700;
  letter-spacing: 0.03em;
  text-transform: uppercase;
  padding: 11px 12px;
  font-size: 12px;
  box-shadow: 0 6px 18px rgba(4, 120, 87, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.2);
}
.cs-btn--primary:hover:not(:disabled) {
  background: var(--vy-accent-600);
  border-color: var(--vy-accent-600);
  color: #fff;
  filter: brightness(1.02);
}
.cs-btn--danger:hover:not(:disabled) {
  background: var(--vy-danger-soft);
  border-color: var(--vy-danger);
  color: var(--vy-danger);
}

/* ===== Modal de confirmação (Limpar leads) ===== */
.cs-modal {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(15, 23, 42, 0.4);
  backdrop-filter: blur(2px);
  opacity: 0;
  transition: opacity 0.16s ease;
  font-family: var(--vy-font);
}
.cs-modal.cs-open { opacity: 1; }
.cs-modal__card {
  width: min(340px, calc(100vw - 32px));
  background: var(--vy-panel);
  border: 1px solid var(--vy-line);
  border-radius: 14px;
  padding: 18px 16px;
  box-shadow: var(--vy-shadow);
  color: var(--vy-fg);
  transform: translateY(6px);
  transition: transform 0.16s ease;
}
.cs-modal.cs-open .cs-modal__card { transform: translateY(0); }
.cs-modal__title {
  font-size: 14px;
  font-weight: 700;
  color: var(--vy-fg);
  margin-bottom: 6px;
}
.cs-modal__text {
  font-size: 12.5px;
  line-height: 1.55;
  color: var(--vy-muted);
  margin-bottom: 14px;
}
.cs-modal__actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}
.cs-modal__btn {
  border: 1px solid var(--vy-line-2);
  background: var(--vy-panel);
  border-radius: 9px;
  padding: 8px 14px;
  font-family: var(--vy-font);
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.12s, border-color 0.12s;
}
.cs-modal__btn:hover { background: var(--vy-accent-soft); border-color: var(--vy-accent); color: var(--vy-accent); }
.cs-modal__btn--danger { background: var(--vy-accent); color: #fff; border-color: var(--vy-accent); }
.cs-modal__btn--danger:hover { background: var(--vy-accent-600); border-color: var(--vy-accent-600); color: #fff; }

/* ===== Empty state ===== */
.cs-empty {
  text-align: center;
  color: var(--vy-muted);
  font-size: 12px;
  padding: 28px 8px;
  line-height: 1.6;
}
.cs-empty b { color: var(--vy-fg); font-weight: 700; }

/* ===== Toast ===== */
.consecom-toast {
  position: fixed;
  top: 18px;
  left: 50%;
  transform: translateX(-50%) translateY(-18px);
  z-index: 2147483647;
  padding: 10px 16px;
  background: var(--vy-panel);
  color: var(--vy-fg);
  border: 1px solid var(--vy-line);
  border-radius: 12px;
  box-shadow: var(--vy-shadow);
  font-family: var(--vy-font);
  font-size: 13px;
  font-weight: 600;
  opacity: 0;
  transition: opacity 0.25s, transform 0.25s;
  pointer-events: none;
}
.consecom-toast.cs-warn { border-color: var(--vy-warn); color: var(--vy-warn); }
.consecom-toast.cs-show { opacity: 1; transform: translateX(-50%) translateY(0); }

/* ===== Cards nativos enxutos (controles dentro dos cards do Maps) ===== */
.consecom-host {
  position: relative !important;
  min-width: 0 !important;
}
.consecom-host > *:not(.consecom-control) {
  opacity: 0 !important;
  pointer-events: none !important;
  height: 0 !important;
  overflow: hidden !important;
}
.consecom-control {
  position: relative !important;
  z-index: 30 !important;
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  padding: 5px 8px !important;
  background: var(--vy-panel) !important;
  border: 1px solid var(--vy-line) !important;
  border-radius: 8px !important;
  box-sizing: border-box !important;
  min-height: 34px !important;
  font-family: var(--vy-font) !important;
}
.consecom-control .cs-name {
  flex: 1 !important;
  min-width: 0 !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  color: var(--vy-fg) !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}
.consecom-control .cs-actions {
  display: flex !important;
  gap: 4px !important;
  flex: 0 0 auto !important;
}
.consecom-control .cs-round {
  width: 26px !important;
  height: 26px !important;
  border-radius: 50% !important;
  border: none !important;
  cursor: pointer !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 0 !important;
  background: var(--vy-accent) !important;
  color: #fff !important;
  box-shadow: 0 1px 4px rgba(4, 120, 87, 0.3) !important;
  transition: transform 0.1s, background 0.15s !important;
}
.consecom-control .cs-round svg { width: 13px; height: 13px; fill: #fff; }
.consecom-control .cs-round:hover:not(:disabled) { filter: brightness(1.06); transform: scale(1.08); }
.consecom-control .cs-round:disabled { background: var(--vy-line) !important; box-shadow: none !important; cursor: default !important; opacity: 0.6 !important; }
.consecom-control .cs-round:disabled svg { fill: var(--vy-muted); }
.consecom-control .cs-select { background: transparent !important; border: 2px solid var(--vy-accent) !important; color: var(--vy-accent) !important; }
.consecom-control .cs-select svg { fill: var(--vy-accent) !important; }
.consecom-control .cs-select.on { background: var(--vy-accent) !important; color: #fff !important; }
.consecom-control .cs-select.on svg { fill: #fff !important; }
.consecom-control .cs-select.used { background: var(--vy-line) !important; border-color: var(--vy-line) !important; color: var(--vy-muted) !important; }
.consecom-control .cs-select.used svg { fill: var(--vy-muted) !important; }
.consecom-control .cs-select.nointerest { background: var(--vy-danger-soft) !important; border-color: var(--vy-danger) !important; color: var(--vy-danger) !important; font-weight: 700 !important; }
.consecom-control .cs-badge {
  position: absolute !important;
  top: -8px !important;
  right: -6px !important;
  background: var(--vy-accent) !important;
  color: #fff !important;
  font-size: 9px !important;
  font-weight: 700 !important;
  padding: 1px 5px !important;
  border-radius: 999px !important;
  white-space: nowrap !important;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15) !important;
}

/* ===== Helpers legados (mantidos para não quebrar nada) ===== */
.cs-panel__list {
  flex: 1;
  overflow-y: auto;
  padding: 4px 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.cs-panel__list::-webkit-scrollbar { width: 6px; }
.cs-panel__list::-webkit-scrollbar-thumb { background: var(--vy-line-strong); border-radius: 999px; }
.cs-footer__count {
  font-size: 11px;
  color: var(--vy-muted);
  text-align: center;
  padding-bottom: 2px;
  font-family: var(--vy-font);
}
.cs-footer__count b { color: var(--vy-fg); font-weight: 700; }

/* ===== Vyntra Command Surface v2 =====
 * O painel Maps usa uma família de classes própria. Este bloco fecha todos os
 * contratos visuais dessa superfície sem depender do CSS do site hospedeiro. */
:root {
  --vy-ink: #f4faf7;
  --vy-ink-muted: #9db5aa;
  --vy-night: #101a17;
  --vy-night-2: #17231f;
  --vy-night-3: #1e2d28;
  --vy-night-line: rgba(185, 226, 207, 0.14);
  --vy-mint: #5ee6af;
  --vy-mint-strong: #20c98a;
  --vy-mint-dark: #0c6b4c;
}

/* O painel e o launcher agora têm uma superfície própria, independente do
 * reset, fontes e cores do documento aberto. */
.consecom-balloon,
.consecom-floatbtn,
.consecom-balloon *,
.consecom-floatbtn * {
  box-sizing: border-box;
}
.consecom-balloon {
  background: var(--vy-night) !important;
  border: 1px solid var(--vy-night-line) !important;
  color: var(--vy-ink) !important;
  border-radius: 20px !important;
  box-shadow: 0 24px 70px rgba(0, 0, 0, 0.34), 0 3px 12px rgba(0, 0, 0, 0.18) !important;
}
.consecom-floatbtn {
  background: var(--vy-night) !important;
  border: 1px solid rgba(94, 230, 175, 0.55) !important;
  color: var(--vy-mint) !important;
  border-radius: 16px !important;
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.3), 0 0 0 5px rgba(94, 230, 175, 0.08) !important;
}

/* Maps header */
.cs-panel__header {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  gap: 8px !important;
  min-height: 48px !important;
  padding: 10px 12px !important;
  background: linear-gradient(135deg, #15251f, #0f1916) !important;
  border-bottom: 1px solid var(--vy-night-line) !important;
  color: var(--vy-ink) !important;
  flex-shrink: 0 !important;
  cursor: grab !important;
  user-select: none !important;
  touch-action: none !important;
}
.cs-panel__header--slim::before {
  content: 'V';
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 25px;
  height: 25px;
  border-radius: 8px;
  color: #062319;
  background: linear-gradient(135deg, var(--vy-mint), #a5f3d0);
  font: 800 13px/1 var(--vy-font);
  font-style: italic;
  box-shadow: 0 0 18px rgba(94, 230, 175, 0.24);
  margin-right: auto;
}
.cs-panel__grip {
  order: -1;
  color: var(--vy-ink-muted) !important;
  font-size: 15px !important;
  letter-spacing: -2px !important;
  line-height: 1 !important;
  cursor: grab !important;
}
.cs-panel__controls { display: flex !important; gap: 5px !important; }
.cs-panel__btn {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 26px !important;
  height: 26px !important;
  padding: 0 !important;
  border: 1px solid var(--vy-night-line) !important;
  border-radius: 8px !important;
  background: rgba(255, 255, 255, 0.05) !important;
  color: var(--vy-ink-muted) !important;
  cursor: pointer !important;
}
.cs-panel__btn:hover { color: var(--vy-mint) !important; border-color: rgba(94, 230, 175, 0.45) !important; background: rgba(94, 230, 175, 0.1) !important; }

.cs-panel__body {
  min-height: 0 !important;
  flex: 1 !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  display: flex !important;
  flex-direction: column !important;
  gap: 9px !important;
  padding: 10px !important;
  background: radial-gradient(circle at 100% 0, rgba(94, 230, 175, 0.08), transparent 42%), var(--vy-night) !important;
}
.cs-panel__body::-webkit-scrollbar { width: 5px !important; }
.cs-panel__body::-webkit-scrollbar-thumb { background: rgba(157, 181, 170, 0.34) !important; border-radius: 999px !important; }

/* Navegação de fonte: uma barra compacta em vez de botões soltos. */
.cs-sites {
  display: grid !important;
  grid-template-columns: repeat(3, 1fr) !important;
  gap: 4px !important;
  padding: 4px !important;
  background: var(--vy-night-2) !important;
  border: 1px solid var(--vy-night-line) !important;
  border-radius: 12px !important;
}
.cs-site {
  min-width: 0 !important;
  padding: 7px 3px !important;
  border: 0 !important;
  border-radius: 8px !important;
  background: transparent !important;
  color: var(--vy-ink-muted) !important;
  font: 700 8px/1.1 var(--vy-font) !important;
  letter-spacing: .04em !important;
  cursor: pointer !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}
.cs-site:hover { color: var(--vy-ink) !important; background: rgba(255, 255, 255, 0.06) !important; }
.cs-site--active { color: #07251a !important; background: var(--vy-mint) !important; box-shadow: 0 4px 12px rgba(94, 230, 175, 0.18) !important; }

.cs-panel__loc {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 5px !important;
  min-height: 18px !important;
  color: var(--vy-ink-muted) !important;
  font: 500 10px/1.3 var(--vy-font) !important;
  text-align: center !important;
}
.cs-panel__loc svg { width: 12px !important; height: 12px !important; fill: var(--vy-mint) !important; }

/* Reestiliza os blocos shared para o tema Command Surface. */
.consecom-balloon .cs-block,
.consecom-balloon .cs-search,
.consecom-balloon .cs-filters,
.consecom-balloon .cs-result__card {
  background: var(--vy-night-2) !important;
  border: 1px solid var(--vy-night-line) !important;
  border-radius: 13px !important;
  box-shadow: none !important;
}
.consecom-balloon .cs-search { padding: 9px !important; gap: 7px !important; }
.consecom-balloon .cs-search__input {
  background: var(--vy-night-3) !important;
  border-color: var(--vy-night-line) !important;
  color: var(--vy-ink) !important;
  border-radius: 9px !important;
}
.consecom-balloon .cs-search__input::placeholder { color: #789289 !important; }
.consecom-balloon .cs-search__input:focus { border-color: var(--vy-mint) !important; box-shadow: 0 0 0 3px rgba(94, 230, 175, 0.12) !important; }
.consecom-balloon .cs-search__btn,
.consecom-balloon .cs-prospect {
  border: 0 !important;
  border-radius: 9px !important;
  background: var(--vy-mint) !important;
  color: #062319 !important;
  box-shadow: none !important;
  font-weight: 800 !important;
}
.consecom-balloon .cs-search__btn:hover,
.consecom-balloon .cs-prospect:hover:not(:disabled) { background: #86efc1 !important; color: #062319 !important; filter: none !important; }
.consecom-balloon .cs-block__title,
.consecom-balloon .cs-filters__title,
.consecom-balloon .cs-leads__title { color: var(--vy-ink-muted) !important; font: 800 9px/1.2 var(--vy-font) !important; letter-spacing: .12em !important; }
.consecom-balloon .cs-chip { background: transparent !important; border-color: var(--vy-night-line) !important; color: var(--vy-ink-muted) !important; }
.consecom-balloon .cs-chip:hover { color: var(--vy-mint) !important; border-color: rgba(94, 230, 175, 0.45) !important; }
.consecom-balloon .cs-chip--on { background: rgba(94, 230, 175, 0.16) !important; border-color: var(--vy-mint) !important; color: var(--vy-mint) !important; }
.consecom-balloon .cs-card,
.consecom-balloon .cs-pcard { background: var(--vy-night-2) !important; border-color: var(--vy-night-line) !important; border-radius: 11px !important; }
.consecom-balloon .cs-card:hover,
.consecom-balloon .cs-pcard:hover { border-color: rgba(94, 230, 175, 0.48) !important; background: var(--vy-night-3) !important; }
.consecom-balloon .cs-card__name,
.consecom-balloon .cs-pcard__name,
.consecom-balloon .cs-card__score,
.consecom-balloon .cs-pcard__score { color: var(--vy-ink) !important; }
.consecom-balloon .cs-card__meta,
.consecom-balloon .cs-pcard__meta { color: var(--vy-ink-muted) !important; }
.consecom-balloon .cs-card__btrack,
.consecom-balloon .cs-pcard__bar { background: #2b4037 !important; }
.consecom-balloon .cs-card__bfill,
.consecom-balloon .cs-pcard__barfill { background: var(--vy-mint) !important; }

/* Resultados, Alex e área de leads do Maps. */
.cs-leads { min-height: 150px !important; }
.cs-leads__title { padding: 2px 2px 0 !important; }
.cs-result { color: var(--vy-ink) !important; }
.cs-result__big { color: var(--vy-mint) !important; font-weight: 800 !important; }
.cs-result__sub, .cs-result__empty, .cs-alex__msg { color: var(--vy-ink-muted) !important; }
.cs-result__cta { background: var(--vy-mint) !important; color: #062319 !important; border-radius: 9px !important; }
.cs-alex { background: rgba(94, 230, 175, 0.08) !important; border: 1px solid rgba(94, 230, 175, 0.18) !important; border-radius: 11px !important; color: var(--vy-ink) !important; }
.cs-alex__avatar { background: var(--vy-mint) !important; color: #062319 !important; }

/* Rodapé fixo e legível. */
.cs-panel__footer {
  display: flex !important;
  flex-direction: column !important;
  gap: 6px !important;
  padding: 8px !important;
  background: #0c1512 !important;
  border-top: 1px solid var(--vy-night-line) !important;
  flex-shrink: 0 !important;
}
.cs-footer__row { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 6px !important; }
.cs-footer__btn {
  min-height: 30px !important;
  padding: 6px 5px !important;
  border: 1px solid var(--vy-night-line) !important;
  border-radius: 8px !important;
  background: var(--vy-night-2) !important;
  color: var(--vy-ink-muted) !important;
  font: 800 9px/1 var(--vy-font) !important;
  letter-spacing: .04em !important;
  cursor: pointer !important;
}
.cs-footer__btn:hover { color: var(--vy-ink) !important; border-color: rgba(94, 230, 175, 0.45) !important; }
.cs-foot-import { background: var(--vy-mint) !important; border-color: var(--vy-mint) !important; color: #062319 !important; }
.cs-foot-import:hover { background: #86efc1 !important; color: #062319 !important; }
.cs-foot-delete:hover { color: #ff9d9d !important; border-color: rgba(248, 113, 113, 0.5) !important; }
.cs-footer__count { color: var(--vy-ink-muted) !important; }
.cs-footer__count b { color: var(--vy-ink) !important; }

/* Dark mode do popup: o mesmo produto visual da superfície in-page. */
`;class lt{constructor(){this.cfg=null,this.found=[],this.selected=new Set,this.used=new Set,this.noInterest=new Set,this.scanning=!1,this.clearedSession=!1,this.bubble=null,this.balloon=null,this.floatBtn=null,this.headerEl=null,this.listEl=null,this.locEl=null,this.countEl=null,this.lastQuery="",this.filters={...at},this.filtersPanel=null,this.resultPanel=null,this.prospecting=!1,this.prospectCancel=!1,this.lastMatched=[],this.debounceScan=(()=>{let t=null;return()=>{t||(t=window.setTimeout(()=>{t=null,this.scan()},350))}})()}async init(){this.cfg=await y(),_t(),this.observeDom(),this.scan("force"),window.addEventListener("click",t=>{var e,n;(e=this.balloon)!=null&&e.classList.contains("open")&&(this.balloon.contains(t.target)||(n=this.floatBtn)!=null&&n.contains(t.target)||this.toggleBalloon(!1))}),chrome.runtime.onMessage.addListener(t=>{((t==null?void 0:t.type)==="consecom:open"||(t==null?void 0:t.type)==="consecom:ping")&&this.toggleBalloon(!0)}),window.addEventListener("resize",()=>{var t;(t=this.balloon)!=null&&t.classList.contains("open")&&this.clampElement(this.balloon),this.floatBtn&&document.body.contains(this.floatBtn)&&this.clampElement(this.floatBtn)}),this.ensureLauncher()}ensureLauncher(){if(this.balloon&&this.balloon.classList.contains("open")||this.floatBtn&&document.body.contains(this.floatBtn))return;(!this.floatBtn||!document.body.contains(this.floatBtn))&&(this.floatBtn=this.buildFloatBtn(),document.body.appendChild(this.floatBtn));const t=this.readPosition();this.floatBtn.style.right=`${t.right}px`,this.floatBtn.style.top=`${t.top}px`,requestAnimationFrame(()=>{var e;return(e=this.floatBtn)==null?void 0:e.classList.add("open")})}observeDom(){new MutationObserver(()=>this.debounceScan()).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("scroll",()=>this.debounceScan(),{passive:!0})}scan(t="scan"){if(!(this.scanning&&t!=="force")){this.scanning=!0;try{this.syncArea(),this.refreshCards(),this.prune(),this.renderControls(),this.renderBalloonList()}finally{this.scanning=!1}}}syncArea(){var n;const t=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]'),e=((t==null?void 0:t.value)||"").trim();e&&e!==this.lastQuery&&(this.lastQuery=e,this.clearedSession=!1,this.selected.clear(),this.found=[],this.locEl&&(this.locEl.textContent=e),(n=this.balloon)!=null&&n.classList.contains("open")&&this.renderCardList()),e&&(this.lastQuery=e)}renderControls(){}makeHostSlim(t){t.classList.contains("consecom-host")||t.classList.add("consecom-host")}toggleSelected(t){this.used.has(t)||this.noInterest.has(t)||(this.selected.has(t)?this.selected.delete(t):this.selected.add(t),this.syncAll())}toggleControl(t){this.toggleSelected(t)}selectAllAvailable(){const t=this.found.filter(a=>!this.used.has(a.key)&&!this.noInterest.has(a.key)),e=Math.min(50,t.length),n=new Set;for(let a=0;a<e;a++)n.add(t[a].key);this.selected=n,this.syncAll(),g(`✅ ${this.selected.size} selecionado(s) (máx. 50 por importação)`)}clearSelection(){this.selected.clear(),this.syncAll()}buildControl(t){const e=document.createElement("div");e.className="consecom-control",e.title=t.lead.name;const n=document.createElement("button");n.type="button",n.className="cs-round cs-select",n.title="Selecionar",n.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),this.toggleControl(t.key)});const a=document.createElement("span");a.className="cs-name",a.textContent=t.lead.name,a.title=t.lead.name;const o=document.createElement("div");o.className="cs-actions";const s=document.createElement("button");s.type="button",s.className="cs-round",s.title="Abrir site",s.innerHTML=H,t.lead.website?s.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),window.open(t.lead.website,"_blank","noopener,noreferrer")}):s.disabled=!0;const i=document.createElement("button");i.type="button",i.className="cs-round",i.title="Chamar",i.innerHTML=wt,t.lead.phone?i.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),window.location.href=`tel:${t.lead.phone.replace(/\s+/g,"")}`}):i.disabled=!0,o.append(s,i);const l=document.createElement("span");return l.className="cs-badge",l.textContent="Sem interesse",l.style.display="none",e.append(n,a,o,l),e}updateControl(t){var o,s;const e=(o=t.control)==null?void 0:o.querySelector(".cs-select");if(!e)return;const n=this.noInterest.has(t.key);e.classList.toggle("nointerest",n);const a=(s=t.control)==null?void 0:s.querySelector(".cs-badge");if(a&&(a.style.display=n?"block":"none"),n){e.disabled=!0,e.title="Sem interesse — não importar (6 meses)",e.innerHTML="✕";return}this.used.has(t.key)?(e.classList.add("used"),e.disabled=!0,e.title="Já importado anteriormente",e.innerHTML=L):(e.disabled=!1,e.classList.toggle("on",this.selected.has(t.key)),e.title=this.selected.has(t.key)?"Remover seleção":"Selecionar",e.innerHTML=this.selected.has(t.key)?L:R)}ensureBalloon(){if(this.balloon&&document.body.contains(this.balloon)){const e=this.readPosition();this.balloon.style.right=`${e.right}px`,this.balloon.style.top=`${e.top}px`,requestAnimationFrame(()=>{var n;return(n=this.balloon)==null?void 0:n.classList.add("open")});return}this.balloon=this.buildBalloon();const t=this.readPosition();this.balloon.style.right=`${t.right}px`,this.balloon.style.top=`${t.top}px`,document.body.appendChild(this.balloon),this.positionBalloon(),requestAnimationFrame(()=>{var e;return(e=this.balloon)==null?void 0:e.classList.add("open")})}minimizeBalloon(){if(!this.balloon||!this.headerEl)return;this.balloon.classList.remove("open"),this.balloon.style.display="none",this.balloon.dataset.minimized="true",(!this.floatBtn||!document.body.contains(this.floatBtn))&&(this.floatBtn=this.buildFloatBtn(),document.body.appendChild(this.floatBtn));const t=this.readPosition();this.floatBtn.style.right=`${t.right}px`,this.floatBtn.style.top=`${t.top}px`,requestAnimationFrame(()=>{var e;return(e=this.floatBtn)==null?void 0:e.classList.add("open")})}buildFloatBtn(){const t=document.createElement("button");return t.type="button",t.className="consecom-floatbtn",t.title="Abrir Vyntra",t.textContent="V",t.addEventListener("click",()=>{if(t.dataset.dragged==="true"){t.dataset.dragged="false";return}this.restoreBalloon()}),this.enableDrag(t,t),t}restoreBalloon(){this.balloon||(this.balloon=this.buildBalloon(),document.body.appendChild(this.balloon)),this.balloon.style.display="flex",this.balloon.dataset.minimized="false";const t=this.floatBtn?{right:parseFloat(this.floatBtn.style.right)||20,top:parseFloat(this.floatBtn.style.top)||20}:this.readPosition();this.balloon.style.right=`${t.right}px`,this.balloon.style.top=`${t.top}px`,this.clampElement(this.balloon),requestAnimationFrame(()=>{var e;return(e=this.balloon)==null?void 0:e.classList.add("open")}),this.floatBtn&&(this.floatBtn.classList.remove("open"),this.floatBtn.remove(),this.floatBtn=null),this.renderBalloonList()}readPosition(){const t=parseFloat(localStorage.getItem("consecom-float-right")||"20"),e=parseFloat(localStorage.getItem("consecom-float-top")||"20");return{right:Math.max(12,Number.isFinite(t)?t:20),top:Math.max(12,Number.isFinite(e)?e:20)}}savePosition(t){const e=parseFloat(t.style.right)||20,n=parseFloat(t.style.top)||20;localStorage.setItem("consecom-float-right",String(Math.max(12,e))),localStorage.setItem("consecom-float-top",String(Math.max(12,n)))}enableDrag(t,e){let a=!1,o=!1,s=0,i=0,l=0,p=0;const u=m=>{if(m.button!==0||a)return;const h=m.target;if(!(h&&h!==t&&h.closest("button, input, select, textarea, a, .cs-panel__controls, [data-no-drag]"))){m.preventDefault(),a=!0,o=!1,e.dataset.dragged="false",s=m.clientX,i=m.clientY,l=parseFloat(e.style.right)||20,p=parseFloat(e.style.top)||20;try{t.setPointerCapture(m.pointerId)}catch{}}},c=m=>{if(!a)return;const h=m.clientX-s,b=m.clientY-i;Math.abs(h)+Math.abs(b)>3&&(o=!0);const f=Math.max(0,window.innerWidth-12-e.offsetWidth),x=Math.max(0,window.innerHeight-12-e.offsetHeight),E=Math.min(Math.max(0,l-h),f),C=Math.min(Math.max(0,p+b),x);e.style.right=`${E}px`,e.style.top=`${C}px`,e.style.left="",e.style.bottom=""},d=m=>{if(a){a=!1;try{t.hasPointerCapture(m.pointerId)&&t.releasePointerCapture(m.pointerId)}catch{}o&&(e.dataset.dragged="true",this.savePosition(e))}};t.addEventListener("pointerdown",u),t.addEventListener("pointermove",c),t.addEventListener("pointerup",d),t.addEventListener("pointercancel",d),t.addEventListener("lostpointercapture",()=>{a=!1})}doMapsSearch(t){var n;const e=document.querySelector('input#searchboxinput, input[aria-label*="pesquisa"], input[aria-label*="search"]');if(e){const a=(n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:n.set;a==null||a.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus(),e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0}))}else this.lastQuery=t,this.selected.clear(),this.found=[],this.scan("force")}buildBalloon(){const t=document.createElement("aside");t.className="consecom-balloon";const e=document.createElement("div");e.className="cs-panel__header cs-panel__header--slim",this.headerEl=e;const n=document.createElement("div");n.className="cs-panel__grip",n.title="Arrastar painel",n.innerHTML="&#8942;&#8942;";const a=document.createElement("div");a.className="cs-panel__controls";const o=document.createElement("button");o.type="button",o.className="cs-panel__btn",o.title="Minimizar",o.innerHTML='<svg viewBox="0 0 24 24" width="12" height="12"><path fill="currentColor" d="M19 13h-4v4h-2v-4H5v-2h4V7h2v4h4z"/></svg>',o.addEventListener("click",v=>{v.stopPropagation(),this.minimizeBalloon()});const s=document.createElement("button");s.type="button",s.className="cs-panel__btn",s.title="Fechar",s.innerHTML='<svg viewBox="0 0 24 24" width="12" height="12"><path fill="currentColor" d="M18.3 5.71 12 12l6.3 6.29-1 1L12 14l-6.3 6.3-1-1L10.8 12 4.5 5.7l1-1L12 10.8l6.3-6.3z"/></svg>',s.addEventListener("click",v=>{v.stopPropagation(),this.toggleBalloon(!1)}),a.append(o,s),e.append(n,a),this.enableDrag(e,t);const i=document.createElement("div");i.className="cs-panel__body";const l=document.createElement("div");l.className="cs-sites";const p=[{key:"maps",label:"GOOGLE MAPS",active:!0},{key:"webmotors",label:"WEBMOTORS",active:!1},{key:"wepsy",label:"WEPSY",active:!1}];for(const v of p){const k=document.createElement("button");k.type="button",k.className="cs-site",k.dataset.site=v.key,k.textContent=v.label,v.active&&k.classList.add("cs-site--active"),l.appendChild(k)}const u=document.createElement("div");u.className="cs-search";const c=document.createElement("input");c.className="cs-search__input",c.type="text",c.placeholder="Ex.: Psicólogos em Sorocaba",c.spellcheck=!1,c.autocomplete="off";const d=()=>{const v=c.value.trim();v&&this.doMapsSearch(v)};c.addEventListener("keydown",v=>{v.key==="Enter"&&d()});const m=document.createElement("button");m.type="button",m.className="cs-search__btn",m.textContent="PESQUISAR",m.addEventListener("click",d);const h=document.createElement("div");h.className="cs-panel__loc",h.innerHTML=Et,this.locEl=document.createElement("span"),this.locEl.textContent="Aguardando busca…",h.append(this.locEl),u.append(c,m,h);const b=this.buildFiltersPanel();this.filtersPanel=b;const f=document.createElement("button");f.type="button",f.className="cs-prospect",f.textContent="PROSPECTAR",f.addEventListener("click",()=>void this.runProspect(f));const x=document.createElement("div");x.className="cs-result",x.style.display="none",this.resultPanel=x;const E=document.createElement("div");E.className="cs-leads";const C=document.createElement("div");C.className="cs-leads__title",C.textContent="AREA DE LEADS E SCROLL";const P=document.createElement("div");P.className="cs-panel__list",this.listEl=P,E.append(C,x,P),i.append(l,u,b,f,E);const A=document.createElement("div");A.className="cs-panel__footer";const B=document.createElement("div");B.className="cs-footer__count",this.countEl=B;const M=document.createElement("div");M.className="cs-footer__row";const _=document.createElement("button");_.type="button",_.className="cs-footer__btn cs-foot-delete",_.textContent="EXCLUIR",_.addEventListener("click",()=>void this.doDelete(_));const S=document.createElement("button");S.type="button",S.className="cs-footer__btn cs-foot-clear",S.textContent="LIMPAR",S.addEventListener("click",()=>void this.confirmClear()),M.append(_,S);const w=document.createElement("button");return w.type="button",w.className="cs-footer__btn cs-foot-import cs-import",w.textContent="IMPORTAR LEADS",w.addEventListener("click",()=>void this.doImport(w)),A.append(B,M,w),t.append(e,i,A),this.balloon=t,t}async runProspect(t){if(!this.prospecting){this.prospecting=!0,this.prospectCancel=!1,this.clearedSession=!1,t.disabled=!0;try{await this.runProspectStages(t),this.scan("force"),this.readFiltersFromPanel();const{matched:e,novoCount:n,existenteCount:a}=this.applyAutomaticSelection();this.renderResult(e,n,a),this.renderBalloonList()}catch(e){g(`Erro na prospecção: ${e}`,"warn")}finally{t.textContent="PROSPECTAR",t.disabled=!1,this.prospecting=!1}}}async runProspectStages(t){const e=[["Coletando resultados",320],["Aprofundando a busca",340],["Carregando mais empresas",360],["Calculando oportunidades",380]];for(const[n,a]of e){if(this.prospectCancel)break;const o=this.found.length;t.textContent=o>0?`PROSPECTANDO… ${o} resultados`:"PROSPECTANDO…",this.updateProspectProgress(),await this.scrollAndCollect(),await I(a),this.updateProspectProgress()}}async scrollAndCollect(){const t=Array.from(document.querySelectorAll(O()));if(t.length===0)return;const e=D(t[0]),n=e?pt(e):null;if(!n)return;const a=this.found.length,o=Math.min(600,n.offsetHeight||400);n.scrollBy({top:o,behavior:"smooth"}),await I(340),this.scan("force"),this.found.length===a&&(n.scrollBy({top:o,behavior:"smooth"}),await I(340),this.scan("force"))}updateProspectProgress(){if(!this.resultPanel)return;const t=this.found.length,e=document.createElement("div");e.className="cs-result__progress",e.textContent=`Coletados: ${t}`,this.resultPanel.replaceChildren(e),this.resultPanel.style.display="block"}applyAutomaticSelection(){const e=this.found.filter(a=>!this.used.has(a.key)&&!this.noInterest.has(a.key)).filter(a=>F(a.lead,this.filters));this.lastMatched=e,this.selected.clear();for(const a of e)this.selected.add(a.key);const n=this.found.filter(a=>this.used.has(a.key)&&F(a.lead,this.filters));return{matched:e,novoCount:e.length,existenteCount:n.length}}buildFiltersPanel(){const t=document.createElement("div");t.className="cs-filters";const e=document.createElement("div");e.className="cs-filters__title",e.textContent="Encontrar oportunidades",t.appendChild(e);const n=document.createElement("div");n.className="cs-chips";for(const c of nt){const d=document.createElement("button");d.type="button",d.className="cs-chip",d.dataset.id=c.id,d.dataset.cat=c.cat,d.dataset.value=c.value,d.dataset.accent=c.accent??"#059669",d.textContent=c.label,d.addEventListener("click",()=>{this.filters.activeChips.has(c.id)?this.filters.activeChips.delete(c.id):this.filters.activeChips.add(c.id),d.classList.toggle("cs-chip--on"),this.syncChipsFromState(d,c.accent)}),this.syncChipsFromState(d,c.accent),n.appendChild(d)}t.appendChild(n);const a=document.createElement("div");a.className="cs-adv";const o=document.createElement("label");o.className="cs-adv__item";const s=document.createElement("span");s.textContent="Nota mín.";const i=document.createElement("select");i.dataset.cat="minRating";for(const c of[0,4,4.5,4.8]){const d=document.createElement("option");d.value=String(c),d.textContent=c===0?"Qualquer":`${c.toFixed(1)}+`,i.appendChild(d)}o.append(s,i);const l=document.createElement("label");l.className="cs-adv__item";const p=document.createElement("span");p.textContent="Avaliações mín.";const u=document.createElement("select");u.dataset.cat="minReviews";for(const c of[0,10,50,100,500]){const d=document.createElement("option");d.value=String(c),d.textContent=c===0?"Qualquer":`${c}+`,u.appendChild(d)}return l.append(p,u),a.append(o,l),t.appendChild(a),t.appendChild(this.buildServiceGroup()),t}syncChipsFromState(t,e){t.classList.contains("cs-chip--on")?(t.style.borderColor=e??"#059669",t.style.background=`${e??"#059669"}22`,t.style.color="#fff"):(t.style.borderColor="",t.style.background="",t.style.color="")}buildServiceGroup(){const t=document.createElement("div");t.className="cs-fgroup cs-fgroup--svc";const e=document.createElement("div");e.className="cs-fgroup__h",e.textContent="SERVIÇO / NECESSIDADE",t.appendChild(e);const n=document.createElement("div");n.className="cs-radio";const a=[{id:"todos",label:"Todos"},{id:"site",label:"Site"},{id:"sistema",label:"Sistema"},{id:"trafego",label:"Tráfego pago"},{id:"automacao",label:"Automação"},{id:"presenca",label:"Presença digital"}];for(const o of a){const s=document.createElement("label");s.className="cs-radio__item";const i=document.createElement("input");i.type="radio",i.name="cs-service",i.value=o.id,i.dataset.cat="service",o.id==="todos"&&(i.checked=!0);const l=document.createElement("span");l.textContent=o.label,s.append(i,l),n.appendChild(s)}return t.appendChild(n),t}readFiltersFromPanel(){if(!this.filtersPanel)return;const t=[],e=[],n=[],a=[];this.filtersPanel.querySelectorAll(".cs-chip.cs-chip--on").forEach(c=>{const d=c.dataset.cat,m=c.dataset.value;!d||!m||(d==="site"?t.push(m):d==="digital"?e.push(m):d==="score"?a.push(m):d==="qualify"&&n.push(m))});let o=null,s=null;const i=this.filtersPanel.querySelector("select[data-cat=minRating]");i&&(o=parseFloat(i.value)||null);const l=this.filtersPanel.querySelector("select[data-cat=minReviews]");l&&(s=parseInt(l.value,10)||null);let p="todos";const u=this.filtersPanel.querySelector("input[name=cs-service]:checked");u&&(p=u.value),this.filters={site:t,digital:e,qualify:n,minRating:o,minReviews:s,scoreBands:a,service:p,activeChips:this.filters.activeChips}}renderResult(t,e,n){if(!this.resultPanel)return;const a=this.found.length,o=document.createElement("div");o.className="cs-result__card";const s=document.createElement("div");s.className="cs-result__head";const i=document.createElement("div");i.className="cs-result__big",i.textContent=`${e}`;const l=document.createElement("div");l.className="cs-result__sub",l.textContent=e===1?"oportunidade encontrada":"oportunidades encontradas",s.append(i,l),o.appendChild(s);const p=document.createElement("div");p.className="cs-result__stats";const u=document.createElement("div");u.innerHTML=`<span>${a}</span> analisadas`;const c=document.createElement("div");if(c.innerHTML=`<span>${e}</span> selecionadas automaticamente`,p.append(u,c),n>0){const d=document.createElement("div");d.className="cs-result__dup",d.innerHTML=`⚠ ${n} já existem na Vyntra`,p.appendChild(d)}if(o.appendChild(p),t.length>0){const d=this.buildAlexHint(t);o.appendChild(d)}if(e>0){const d=document.createElement("button");d.type="button",d.className="cs-result__cta";const m=n>0?`${e} NOVOS`:`${e} LEADS`;d.textContent=n>0?`IMPORTAR ${e} NOVOS`:`IMPORTAR ${e} LEADS`,d.addEventListener("click",()=>void this.doProspectImport(d,t,m)),o.appendChild(d)}else{const d=document.createElement("div");d.className="cs-result__empty",d.textContent="Nenhuma empresa corresponde aos critérios. Ajuste os filtros e tente novamente.",o.appendChild(d)}this.resultPanel.replaceChildren(o),this.resultPanel.style.display="block"}buildAlexHint(t){const e=document.createElement("div");e.className="cs-alex";const n=document.createElement("div");n.className="cs-alex__avatar",n.textContent="🤖";const a=document.createElement("div");a.className="cs-alex__body";const o=document.createElement("div");o.className="cs-alex__name",o.textContent="Alex";const s=document.createElement("div");s.className="cs-alex__msg";const i=t.filter(u=>z(u.lead).band==="alta").length,p=t.filter(u=>!u.lead.website).length>=t.length/2?"sem site ou com presença digital fraca":"com boa avaliação e presença consolidada";return s.textContent=`Encontrei ${t.length} empresas que parecem boas oportunidades para prospecção.`+(i>0?` ${i} delas possuem alta oportunidade.`:"")+` A maior oportunidade está em empresas ${p}.`,a.append(o,s),e.append(n,a),e}async doProspectImport(t,e,n){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const a=e.map(s=>s.lead).slice(0,50);if(a.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const o=t.textContent;t.disabled=!0;try{const s=["Google Maps"],i=this.filters.service!=="todos"?`Interesse: ${this.serviceLabel(this.filters.service)}`:null,p={source:"google_maps",sourceDetail:"vyntra_prospector",tags:i?[...s,i]:s,prospectFilters:this.filtersToSnapshot(),prospectedAt:new Date().toISOString()};let u=0;const c=await $(this.cfg,a,(d,m)=>{u=d;const h=Math.round(d/m*100);t.textContent=`Importando… ${h}%`},p);console.log("[IMPORT] Resultado completo:",{ok:c.ok,failed:c.failed,firstError:c.firstError,errors:c.errors}),this.renderProspectReport({analyzed:this.found.length,opportunities:e.length,imported:c.ok,failed:c.failed,alreadyExists:this.countAlreadyExists(e),filtersText:it(this.filters)}),t.textContent=c.failed===0?`✓ ${c.ok} LEADS IMPORTADOS`:`${c.ok} ok, ${c.failed} falharam`,c.failed===0?(g(`✅ ${c.ok} lead(s) importado(s)!`),this.selected.clear()):g(`⚠️ ${c.ok} ok, ${c.failed} falharam${c.firstError?`: ${c.firstError}`:""}`,"warn"),this.checkUsed(),this.syncAll()}catch(s){t.textContent=`Erro: ${s}`,g(`Erro ao importar: ${s}`,"warn")}finally{setTimeout(()=>{t.textContent=o,t.disabled=!1},4e3)}}countAlreadyExists(t){return t.filter(e=>this.used.has(e.key)).length}serviceLabel(t){return{todos:"Todos",site:"Site",sistema:"Sistema",trafego:"Tráfego pago",automacao:"Automação",presenca:"Presença digital"}[t]}filtersToSnapshot(){return{site:this.filters.site,digital:this.filters.digital,minRating:this.filters.minRating,minReviews:this.filters.minReviews,scoreBands:this.filters.scoreBands,service:this.filters.service,query:this.lastQuery,at:new Date().toISOString()}}renderProspectReport(t){if(!this.resultPanel)return;const e=document.createElement("div");e.className="cs-result__card cs-result__report";const n=document.createElement("div");n.className="cs-result__head cs-result__head--ok";const a=document.createElement("div");a.className="cs-result__title",a.textContent="PROSPECÇÃO CONCLUÍDA",n.appendChild(a),e.appendChild(n);const o=[`${t.analyzed} empresas analisadas`,`${t.opportunities} oportunidades encontradas`,`${t.imported} novos leads importados`,t.failed>0?`${t.failed} com erro`:null,t.alreadyExists>0?`${t.alreadyExists} já estavam na Vyntra`:null].filter(Boolean),s=document.createElement("ul");s.className="cs-result__lines";for(const l of o){const p=document.createElement("li");p.textContent=l,s.appendChild(p)}if(e.appendChild(s),t.filtersText.length>0){const l=document.createElement("div");l.className="cs-result__crit",l.innerHTML='<div class="cs-result__crit-h">Critérios:</div>';const p=document.createElement("div");p.className="cs-result__tags";for(const u of t.filtersText){const c=document.createElement("span");c.className="cs-result__chip",c.textContent=`✓ ${u}`,p.appendChild(c)}l.appendChild(p),e.appendChild(l)}const i=document.createElement("button");i.type="button",i.className="cs-result__cta cs-result__cta--ghost",i.textContent="VER LEADS",i.addEventListener("click",()=>this.renderBalloonList()),e.appendChild(i),this.resultPanel.replaceChildren(e),this.resultPanel.style.display="block"}doProspect(t){this.runProspect(t)}renderBalloonList(){!this.balloon||!this.listEl||(this.updateCounts(),this.renderCardList())}renderCardList(){if(!this.listEl)return;if(this.found.length===0){this.listEl.innerHTML="";const e=document.createElement("div");e.className="cs-empty",this.clearedSession?e.innerHTML='<span class="cs-empty__icon">✓</span><b>0 leads capturados</b> · <b>0 leads selecionados</b><br/>Sessão limpa. Inicie uma nova busca e toque em PROSPECTAR para capturar novamente.':e.innerHTML="<b>0 leads capturados</b> · <b>0 leads selecionados</b><br/>Rode a busca no Google Maps e toque em PROSPECTAR para listar as empresas.",this.listEl.appendChild(e);return}const t=document.createDocumentFragment();for(const e of this.found)t.appendChild(this.buildCard(e));this.listEl.replaceChildren(t)}buildCard(t){const e=document.createElement("div");e.className="cs-pcard",e.dataset.key=t.key;const n=z(t.lead),a=document.createElement("div");a.className="cs-pcard__top";const o=document.createElement("div");o.className="cs-pcard__name",o.textContent=t.lead.name,o.title=t.lead.name;const s=document.createElement("div");s.className="cs-pcard__badge "+et(n.band),s.textContent=n.label,a.append(o,s);const i=document.createElement("div");i.className="cs-pcard__meta";const l=[];if(t.lead.address){const f=document.createElement("span");f.textContent=t.lead.address.split(",")[0],l.push(f)}if(t.lead.phone){const f=document.createElement("span");f.textContent=t.lead.phone,l.push(f)}if(t.lead.rating!=null){const f=document.createElement("span");f.className="cs-pcard__rating",f.innerHTML=kt+t.lead.rating.toFixed(1),l.push(f)}for(let f=0;f<l.length;f++)f>0&&i.appendChild(document.createTextNode(" • ")),i.appendChild(l[f]);l.length===0&&(i.textContent="—");const p=document.createElement("div");p.className="cs-pcard__scorebar";const u=document.createElement("div");u.className="cs-pcard__bar";const c=document.createElement("div");c.className="cs-pcard__barfill",c.style.width=`${n.total}%`,u.appendChild(c);const d=document.createElement("div");d.className="cs-pcard__score",d.innerHTML=`${n.total}<small>/100</small>`,p.append(u,d);const m=document.createElement("div");m.className="cs-pcard__actions";const h=document.createElement("button");h.type="button",h.className="cs-pcard__btn cs-pcard__lead",h.innerHTML=(this.selected.has(t.key)?L:R)+'<span data-role="lead-label">Lead</span>',h.addEventListener("click",()=>{this.used.has(t.key)||this.noInterest.has(t.key)||this.toggleControl(t.key)});const b=document.createElement("button");return b.type="button",b.className="cs-pcard__btn cs-pcard__site",b.title="Abrir site",b.innerHTML=H,t.lead.website?b.addEventListener("click",f=>{f.stopPropagation(),window.open(t.lead.website,"_blank","noopener,noreferrer")}):b.disabled=!0,m.append(h,b),e.append(a,i,p,m),this.updateCard(e,t),e}updateCard(t,e){const n=t.querySelector(".cs-pcard__lead");if(!n)return;const a=n.querySelector('[data-role="lead-label"]');if(this.noInterest.has(e.key)){n.classList.add("nointerest"),n.disabled=!0,a&&(a.textContent="Sem interesse");return}if(this.used.has(e.key)){n.classList.add("used"),n.disabled=!0,a&&(a.textContent="Importado");return}n.classList.toggle("on",this.selected.has(e.key)),n.innerHTML=(this.selected.has(e.key)?L:R)+'<span data-role="lead-label">Lead</span>'}syncAll(){this.updateCounts(),this.renderControls(),this.renderBalloonList()}updateCounts(){if(!this.listEl)return;if(this.listEl.querySelectorAll(".cs-pcard").forEach(e=>{const n=e.dataset.key,a=n?this.found.find(o=>o.key===n):void 0;a&&this.updateCard(e,a)}),this.countEl){const e=this.found.length,n=this.selected.size;this.countEl.innerHTML=`<b>${e}</b> capturados · <b>${n}</b> selecionados`}}toggleBalloon(t){var n;if(t&&this.floatBtn){this.restoreBalloon();return}const e=t??!((n=this.balloon)!=null&&n.classList.contains("open"));if(!this.balloon||!document.body.contains(this.balloon)){e&&this.ensureBalloon();return}this.balloon.classList.toggle("open",e),e?this.renderBalloonList():this.ensureLauncher()}clampElement(t){if(!document.body.contains(t))return;const e=12,n=t.offsetWidth||0,a=t.offsetHeight||0,o=Math.max(0,window.innerWidth-e-n),s=Math.max(0,window.innerHeight-e-a),i=parseFloat(t.style.right),l=parseFloat(t.style.top);if(!Number.isFinite(i)||!Number.isFinite(l))return;const p=Math.min(Math.max(0,i),o),u=Math.min(Math.max(0,l),s);(p!==i||u!==l)&&(t.style.right=`${p}px`,t.style.top=`${u}px`,t.style.left="",t.style.bottom="",this.savePosition(t))}positionBalloon(){if(!this.balloon)return;const t=this.readPosition();this.balloon.style.right=`${Math.max(12,t.right)}px`,this.balloon.style.top=`${Math.max(12,t.top)}px`,this.clampElement(this.balloon)}refreshCards(){if(this.clearedSession)return;const t=document.querySelectorAll(O()),e=new Set;for(const n of Array.from(t)){const a=D(n),o=n.href,s=mt(n,a);if(!s)continue;const i=dt(o),l=i||o;if(!i&&!o||e.has(l))continue;e.add(l);const p=this.found.find(u=>u.key===l);if(p){p.host=p.host&&document.body.contains(p.host)?p.host:a,p.lead.name=s;continue}this.found.push({lead:this.parseCard(a,s,o,i),host:a,key:l,control:null})}this.checkUsed()}async checkUsed(){const t=this.cfg??await y();if(!t.extensionKey||!t.ownerUserId)return;const e=this.found.map(n=>n.lead.place_id).filter(n=>!!n);if(e.length!==0)try{const n=await j(t,e);this.used=new Set(n.used);const a=Date.now();this.noInterest=new Set(Object.entries(n.noInterest).filter(([,o])=>o&&new Date(o).getTime()>a).map(([o])=>o)),this.syncAll()}catch{}}prune(){this.found=this.found.filter(t=>t.host&&document.body.contains(t.host))}parseCard(t,e,n,a){const o=((t==null?void 0:t.innerText)||"")??"",s=n.match(/!3d([-\d.]+)!4d([-\d.]+)/);return{name:e,phone:ut(t,o),category:ft(o,e),website:ht(t),address:bt(t),city:null,state:null,rating:yt(o),reviews:xt(o),latitude:s?parseFloat(s[1]):null,longitude:s?parseFloat(s[2]):null,place_id:a,instagram:vt(t),facebook:gt(t)}}async promptConfig(){const t=this.cfg??await y();alert(t.extensionKey&&t.ownerUserId?"Extensão vinculada à sua conta Vyntra ✓":"Esta extensão não está vinculada a uma conta. Baixe novamente a extensão no painel Vyntra.")}async doImport(t){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const e=this.found.filter(a=>!this.used.has(a.key)&&this.selected.has(a.key)).map(a=>a.lead).slice(0,50);if(e.length===0){alert("Nenhuma empresa nova selecionada para importar.");return}const n=t.innerHTML;t.disabled=!0,t.textContent="Importando…";try{let a=0;const o=await $(this.cfg,e,(s,i)=>{a=s,t.textContent=`${s}/${i}…`});console.log("[IMPORT] Resultado completo:",{ok:o.ok,failed:o.failed,firstError:o.firstError,errors:o.errors}),t.textContent=o.failed===0?"✓":`${o.ok} ok, ${o.failed} falharam`,o.failed===0?(g(o.ok>0?`✅ ${o.ok} lead(s) importado(s)!`:"Nenhum lead novo para importar."),this.selected.clear()):g(`⚠️ ${o.ok} ok, ${o.failed} falharam${o.firstError?`: ${o.firstError}`:""}`,"warn"),this.checkUsed(),this.syncAll(),setTimeout(()=>{t.innerHTML=n,t.disabled=!1},2e3)}catch(a){t.textContent=`Erro: ${a}`,setTimeout(()=>{t.innerHTML=n,t.disabled=!1},3e3)}}async doDelete(t){if(this.cfg=this.cfg??await y(),!this.cfg||!this.cfg.extensionKey||!this.cfg.ownerUserId){alert("Baixe novamente a extensão no painel Vyntra para vincular à sua conta.");return}const e=this.found.filter(a=>this.selected.has(a.key)&&a.lead.place_id).map(a=>a.lead.place_id);if(e.length===0){alert("Selecione pelo menos um lead para excluir.");return}if(!confirm(`Excluir ${e.length} lead(s) do banco?`))return;const n=t.innerHTML;t.disabled=!0,t.innerHTML="Excluindo…";try{const a=await U(this.cfg,e);if(a.failed===0){g(`🗑️ ${a.ok} lead(s) excluído(s)!`);for(const o of e)this.used.delete(o);this.selected.clear()}else g(`⚠️ ${a.ok} ok, ${a.failed} falharam ao excluir`,"warn");this.checkUsed(),this.syncAll()}catch(a){g(`Erro ao excluir: ${a}`,"warn")}finally{t.innerHTML=n,t.disabled=!1}}confirmClear(){return new Promise(t=>{const e=document.createElement("div");e.className="cs-modal";const n=document.createElement("div");n.className="cs-modal__card";const a=document.createElement("div");a.className="cs-modal__title",a.textContent="Limpar leads capturados";const o=document.createElement("div");o.className="cs-modal__text",o.textContent="Tem certeza que deseja remover todos os leads capturados desta sessão? Leads já importados para o VYNTRA não serão afetados.";const s=document.createElement("div");s.className="cs-modal__actions";const i=document.createElement("button");i.type="button",i.className="cs-modal__btn cs-modal__btn--ghost",i.textContent="Cancelar",i.addEventListener("click",()=>{e.remove(),t()});const l=document.createElement("button");l.type="button",l.className="cs-modal__btn cs-modal__btn--danger",l.textContent="Limpar leads",l.addEventListener("click",()=>{e.remove(),this.clearLocal(),t()}),s.append(i,l),n.append(a,o,s),e.append(n),document.body.appendChild(e),requestAnimationFrame(()=>e.classList.add("cs-open"))})}clearLocal(){this.clearedSession=!0,this.found=[],this.selected.clear(),this.lastMatched=[],this.resultPanel&&(this.resultPanel.style.display="none"),this.syncAll(),g("✓ Leads removidos")}}const V=()=>{const r=window.location.hostname,t=window.location.href,e=/(^|\.)google\.(com|com\.br|[a-z.]+)\/maps\//.test(t)||r.startsWith("maps.google");!e&&!(()=>{const a=r.toLowerCase();return!!(/(^|\.)wepsy\.com\.br$/.test(a)||/(^|\.)webmotors\.com\.br$/.test(a))})()||(typeof document<"u"&&T(async()=>{const{detectWelcomeSite:a,showWelcome:o}=await import("./welcome-Bio4P_8f.js");return{detectWelcomeSite:a,showWelcome:o}},[]).then(({detectWelcomeSite:a,showWelcome:o})=>{const s=a(r,t);s&&s!=="global"&&o(s)}),T(()=>Promise.resolve().then(()=>J),void 0).then(async({getExtensionSites:a})=>{const o=await a();if(e){if(o.maps===!1)return;new lt().init()}else T(async()=>{const{GlobalScanner:s}=await import("./global-DONg-1Kz.js");return{GlobalScanner:s}},__vite__mapDeps([0,1])).then(({GlobalScanner:s})=>{new s().init()})}))};typeof window<"u"&&V();function Lt(){V()}function O(){return'a[href*="/maps/place/"]'}function dt(r){const t=r.match(/(?:^|[?&])place_id=([^&]+)/);return t?decodeURIComponent(t[1]):null}function D(r){let t=r.parentElement;for(let e=0;e<9&&t&&t.tagName!=="BODY"&&t.getAttribute("role")!=="feed";e++){if(t.getAttribute("role")==="article"||t.querySelector('span[aria-label*="stars"], span[aria-label*="avalia"], span[aria-label*="estrela"]')||t.querySelector('a[href*="/maps/place/"]'))return t;t=t.parentElement}return r.closest('div[role="article"], [role="article"]')??r}function pt(r){let t=r.parentElement;for(;t&&t.tagName!=="BODY"&&t.tagName!=="HTML";){const e=getComputedStyle(t);if(["auto","scroll"].includes(e.overflowY)||e.overflowY==="clip"&&["auto","scroll"].includes(e.overflow))return t;t=t.parentElement}return document.scrollingElement}function mt(r,t){const n=(r.textContent||"").split(/\s+/).filter(Boolean);if(n.length>0&&n.length<14)return n.slice(0,6).join(" ");const a=r.querySelector('h3, [role="heading"], [style*="font"]'),o=((a==null?void 0:a.textContent)||"").trim();return o?o.split(`
`)[0]:t&&(t.textContent||"").trim().split(`
`)[0]||null}function ut(r,t){const e=r==null?void 0:r.querySelector('a[href^="tel:"]');if(e)return e.href.replace("tel:","").trim();const n=t.match(/\(\d{2,3}\)\s?\d[\d\s-]{7,}/);return n?n[0].replace(/\s+/g," ").trim():null}function ft(r,t){for(const e of r.split(`
`)){const n=e.trim();if(n&&n!==t&&n.length<40&&!/\d/.test(n)&&!n.startsWith("★")&&!/^\d/.test(n))return n}return null}function ht(r){if(!r)return null;const t=['a[data-tooltip="Abrir site"]','a[data-tooltip="Website"]','a[aria-label*="Abrir site"]','a[href]:not([href^="tel:"]):not([href*="/maps/place/"]):not([href^="http://www.google.com/maps"])'];for(const a of t){const o=r.querySelector(a),s=o==null?void 0:o.href;if(s&&s.startsWith("http"))return s.split("&place_id")[0]}const e=r.querySelector('a[href^="http"]'),n=e==null?void 0:e.href;return n&&n.startsWith("http")&&!n.includes("/maps/place/")?n.split("&")[0]:null}function bt(r){var e;const t=r==null?void 0:r.querySelector('button[data-tooltip="Endereço"], div[class*="address"], span[data-type="address"]');return((e=t==null?void 0:t.textContent)==null?void 0:e.trim())||null}function vt(r){if(!r)return null;const t=['a[data-tooltip*="Instagram" i]','a[aria-label*="Instagram" i]','a[href*="instagram.com/"]','a[href*="instagram.com"]'];for(const a of t){const o=r.querySelector(a),s=o==null?void 0:o.href;if(s&&/instagram\.com/i.test(s))return W(s)}const n=(r.innerText||"").match(/instagram\.com\/[A-Za-z0-9_.\-]+/i);return n?`https://www.${n[0].toLowerCase()}`:null}function gt(r){if(!r)return null;const t=['a[data-tooltip*="Facebook" i]','a[aria-label*="Facebook" i]','a[href*="facebook.com/"]','a[href*="fb.com/"]'];for(const e of t){const n=r.querySelector(e),a=n==null?void 0:n.href;if(a&&/facebook\.com|fb\.com/i.test(a))return W(a)}return null}function W(r){try{const t=new URL(r);return`${t.protocol}//${t.host}${t.pathname.replace(/\/$/,"")}`}catch{return r.split("?")[0]}}function yt(r){const t=r.match(/([\d.]+)[\s]*[★✩]/);return t?parseFloat(t[1]):null}function xt(r){const t=r.match(/\(([\d.,]+)\)/);return t?parseInt(t[1].replace(/[^\d]/g,""),10):null}function _t(){if(document.getElementById("consecom-css"))return;const r=document.createElement("style");r.id="consecom-css",r.textContent=ct,document.head.appendChild(r)}function g(r,t="ok"){var a;const e="consecom-toast";(a=document.getElementById(e))==null||a.remove();const n=document.createElement("div");n.id=e,n.className="consecom-toast"+(t==="warn"?" cs-warn":""),n.textContent=r,document.body.appendChild(n),window.setTimeout(()=>{n.classList.add("cs-show")},20),window.setTimeout(()=>n.remove(),4e3)}function I(r){return new Promise(t=>window.setTimeout(t,r))}const wt='<svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z"/></svg>',H='<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm2.5 16c-.8 1.3-1.6 2-2.5 2s-1.7-.7-2.5-2c-.7-1.2-1.2-2.8-1.4-4.5h7.8c-.2 1.7-.7 3.3-1.4 4.5zM7.8 11.5c.2-1.7.7-3.3 1.4-4.5.8-1.3 1.6-2 2.5-2s1.7.7 2.5 2c.7 1.2 1.2 2.8 1.4 4.5H7.8zM12 4c.5.7.9 1.6 1.2 2.6h-2.4C10.6 5.6 11.2 4.6 12 4zm-3.1 7c-.1.5-.1 1 0 1.5H5.9a8 8 0 0 1 0-3h3c-.1.5-.1 1 0 1.5zm-1.6 3h3c.1 1.5.4 2.9.9 4-.9-.4-1.6-.9-2.3-1.6-.5-.6-1-1.5-1.6-2.4zM15.1 17c.7.7 1.4 1.2 2.3 1.6-.5-1.1-.8-2.5-.9-4h3a8 8 0 0 1-.9 3c-.5.5-1 .9-1.6 1.2-.6.3-1.3.5-1.9.6v-2.4zm3.6-4.5h-3.1c0-.5 0-1 .1-1.5h3a8 8 0 0 1 0 3h-3c0-.5-.1-1-.1-1.5zM7.1 7c-.7-.7-1.4-1.2-2.3-1.6.5 1.1.8 2.5.9 4h-3a8 8 0 0 1 .9-3c.5-.5 1-.9 1.6-1.2.6-.3 1.3-.5 1.9-.6V7zm0 1.5v2.4c.5 0 1 .1 1.5.1h1.6c-.1-1.4-.4-2.7-.9-3.8-.7.3-1.4.8-2.2 1.3zM12 20c-.5-.7-.9-1.6-1.2-2.6h2.4c-.3 1-.9 1.9-1.2 2.6z"/></svg>',L='<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',R='<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',kt='<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.9-5 4.7 1.3 6.8L12 17.8 5.9 20.7l1.3-6.8-5-4.7 6.9-.9z"/></svg>',Et='<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>';export{lt as M,X as a,$ as b,I as c,Lt as d,K as g,_t as i,St as r,g as s};
