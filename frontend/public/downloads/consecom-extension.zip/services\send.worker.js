/**
 * Consecom auto-send worker.
 *
 * Polls Supabase (via service role) for pending `send_runs` and delivers the
 * campaign message sequence to each lead on schedule:
 *
 *   - Reads pending/running `send_runs`.
 *   - When `next_send_at <= now`, pops the next `queue_message` and sends it
 *     (text via sendText, media via sendMedia).
 *   - Advances `current_position`, sets the gap `+delay_seconds` into
 *     `next_send_at`.
 *   - On completion marks the run `done` and the lead status `enviado`.
 *
 * Uses the Supabase REST API with the service role key (bypasses RLS).
 * Does not store secrets; reads them from env via the config module.
 */
import { getSupabaseProspeccaoConfig, getEnv } from '../config/env.js';
import { getLogger } from '../utils/logger.js';
import { sendText, sendMedia } from './evolution.service.js';
import { loadAgentName, formatAgentSignature } from './supabase.leads.js';
import { loadCampaignStrategies, pickStrategyForLead, loadStrategiesByIds, } from './strategy.service.js';
const TICK_MS = Number(getEnv().CONSECOM_WORKER_TICK_MS ?? 5000);
/** Substitutes dynamic placeholders ({nome_empresa}, {telefone}, ...) in a string. */
function applyPlaceholders(input, lead) {
    const values = {
        nome_empresa: lead.name ?? '',
        telefone: lead.phone ?? '',
        cidade: lead.city ?? '',
        estado: lead.state ?? '',
        endereco: lead.address ?? '',
        categoria: lead.category ?? '',
        site: lead.website ?? '',
        nicho: lead.niche ?? '',
        avaliacao: lead.rating != null ? String(lead.rating) : '',
        avaliacoes: lead.reviews != null ? String(lead.reviews) : '',
    };
    return input.replace(/\{(\w+)\}/g, (match, key) => values[key] !== undefined ? values[key] : match);
}
export class SendWorker {
    url;
    key;
    timer = null;
    busy = false;
    started = false;
    constructor() {
        const c = getSupabaseProspeccaoConfig();
        this.url = c.url;
        this.key = c.serviceRoleKey;
    }
    headers(json = false) {
        return json
            ? { apikey: this.key, Authorization: `Bearer ${this.key}`, 'Content-Type': 'application/json' }
            : { apikey: this.key, Authorization: `Bearer ${this.key}` };
    }
    async getLead(leadId) {
        const r = await fetch(`${this.url}/rest/v1/leads?id=eq.${leadId}&select=*`, {
            headers: this.headers(),
        });
        if (!r.ok)
            return null;
        const rows = (await r.json());
        return rows[0] ?? null;
    }
    async getPendingRuns() {
        // Só dispara campanhas em andamento (status 'em_progresso'). Assim,
        // campanhas "prontas" ficam enfileiradas e uma dispara por vez.
        const r = await fetch(`${this.url}/rest/v1/send_runs?select=id,campaign_id,lead_id,status,current_position,next_send_at,campaign:campaigns!inner(status)&campaign.status=eq.em_progresso&status=in.("pending","running")&order=created_at.asc`, { headers: this.headers() });
        if (!r.ok)
            return [];
        const rows = (await r.json());
        return rows;
    }
    async getQueueMessages(campaignId) {
        const r = await fetch(`${this.url}/rest/v1/queue_messages?campaign_id=eq.${campaignId}&select=*&order=position.asc`, { headers: this.headers() });
        if (!r.ok)
            return [];
        return (await r.json());
    }
    async patchSendRun(runId, patch) {
        await fetch(`${this.url}/rest/v1/send_runs?id=eq.${runId}`, {
            method: 'PATCH',
            headers: this.headers(true),
            body: JSON.stringify(patch),
        });
    }
    /** Soma +1 no campo de sucesso/falha da campanha (contagem agregada). */
    async bumpCampaign(campaignId, field) {
        const r = await fetch(`${this.url}/rest/v1/campaigns?id=eq.${campaignId}&select=${field},fail_count,success_count`, { headers: this.headers() });
        if (!r.ok)
            return;
        const rows = (await r.json());
        const row = rows[0];
        if (!row)
            return;
        const nextSuccess = field === 'success_count' ? row.success_count + 1 : row.success_count;
        const nextFail = field === 'fail_count' ? row.fail_count + 1 : row.fail_count;
        await fetch(`${this.url}/rest/v1/campaigns?id=eq.${campaignId}`, {
            method: 'PATCH',
            headers: this.headers(true),
            body: JSON.stringify({ success_count: nextSuccess, fail_count: nextFail }),
        });
    }
    async updateLeadStatus(leadId, status) {
        await fetch(`${this.url}/rest/v1/leads?id=eq.${leadId}`, {
            method: 'PATCH',
            headers: this.headers(true),
            body: JSON.stringify({ status, last_message_sent: new Date().toISOString() }),
        });
        await fetch(`${this.url}/rest/v1/lead_status_history`, {
            method: 'POST',
            headers: this.headers(true),
            body: JSON.stringify({ lead_id: leadId, status }),
        });
    }
    async patchLeadStrategy(leadId, strategyId) {
        await fetch(`${this.url}/rest/v1/leads?id=eq.${leadId}`, {
            method: 'PATCH',
            headers: this.headers(true),
            body: JSON.stringify({ strategy_id: strategyId }),
        });
    }
    async processRun(run) {
        const log = getLogger();
        const msgs = await this.getQueueMessages(run.campaign_id);
        if (msgs.length === 0) {
            await this.patchSendRun(run.id, { status: 'done', current_position: 0 });
            return;
        }
        const position = run.current_position;
        const next = msgs[position];
        if (!next) {
            await this.patchSendRun(run.id, { status: 'done', current_position: position });
            await this.updateLeadStatus(run.lead_id, 'enviado');
            log.info({ runId: run.id, leadId: run.lead_id }, 'send-worker: run done');
            return;
        }
        const lead = await this.getLead(run.lead_id);
        if (!lead) {
            log.warn({ runId: run.id, leadId: run.lead_id }, 'send-worker: lead not found, failing');
            await this.patchSendRun(run.id, { status: 'failed', current_position: position });
            return;
        }
        const phone = lead.phone;
        if (!phone) {
            log.warn({ runId: run.id, leadId: run.lead_id }, 'send-worker: no phone, failing');
            await this.patchSendRun(run.id, { status: 'failed', current_position: position });
            return;
        }
        // Estratégia: na 1ª mensagem do lead, garante um strategy_id sorteado pela
        // campanha (A/B) e, quando a estratégia define uma first_message, usa-a no
        // lugar da mensagem 1 da sequência. Demais mensagens seguem o template.
        let strategyText = next.text ?? '';
        let strategyKind = next.kind;
        let strategyMediaUrl = next.media_url;
        let strategyCaption = next.media_caption;
        try {
            const links = await loadCampaignStrategies(run.campaign_id);
            const chosen = pickStrategyForLead(links, lead.strategy_id ?? null);
            if (chosen && chosen !== lead.strategy_id) {
                await this.patchLeadStrategy(run.lead_id, chosen);
            }
            if (chosen && position === 0) {
                const strategies = await loadStrategiesByIds([chosen]);
                const st = strategies[0];
                if (st?.first_message && st.first_message.trim().length > 0) {
                    strategyText = st.first_message.trim();
                    strategyKind = 'text';
                    strategyMediaUrl = null;
                    strategyCaption = null;
                    log.info({ runId: run.id, strategy: st.code }, 'send-worker: using strategy first_message');
                }
            }
        }
        catch (err) {
            log.warn({ runId: run.id, err: err instanceof Error ? err.message : 'unknown' }, 'send-worker: strategy assignment failed; continuing with default sequence');
        }
        log.info({ runId: run.id, position, kind: next.kind, phone }, 'send-worker: sending');
        const agentName = await loadAgentName();
        let ok;
        if (strategyKind === 'text' && strategyText) {
            ok = (await sendText({ to: phone, text: formatAgentSignature(applyPlaceholders(strategyText, lead), agentName) })).ok;
        }
        else if (strategyMediaUrl) {
            const mediaUrl = strategyMediaUrl.startsWith('http')
                ? strategyMediaUrl
                : `${this.url}/storage/v1/object/public/${strategyMediaUrl.replace(/^\/+/, '')}`;
            ok = (await sendMedia({
                to: phone,
                kind: strategyKind,
                media: mediaUrl,
                caption: strategyCaption
                    ? formatAgentSignature(applyPlaceholders(strategyCaption, lead), agentName)
                    : undefined,
                mimetype: guessMimetype(mediaUrl, strategyKind),
                filename: basename(mediaUrl),
            })).ok;
        }
        else {
            ok = false;
        }
        if (!ok) {
            log.warn({ runId: run.id, position, kind: next.kind }, 'send-worker: send failed');
            await this.patchSendRun(run.id, { status: 'failed', current_position: position });
            await this.bumpCampaign(run.campaign_id, 'fail_count');
            return;
        }
        const delayMs = (next.delay_seconds ?? 0) * 1000;
        const newPosition = position + 1;
        const nextAt = new Date(Date.now() + Math.max(0, delayMs)).toISOString();
        const done = newPosition >= msgs.length;
        await this.patchSendRun(run.id, {
            status: done ? 'done' : 'running',
            current_position: newPosition,
            next_send_at: done ? null : nextAt,
            last_sent_at: new Date().toISOString(),
        });
        if (done) {
            await this.updateLeadStatus(run.lead_id, 'enviado');
            await this.bumpCampaign(run.campaign_id, 'success_count');
            log.info({ runId: run.id, leadId: run.lead_id }, 'send-worker: sequence done');
        }
    }
    /**
       * Lê a configuração do agente (presentation/remarketing) de agent_settings.
       * Retorna valores default quando vazio ou indisponível.
       */
    async getAgentSettings() {
        const r = await fetch(`${this.url}/rest/v1/agent_settings?select=key,value`, { headers: this.headers() });
        if (!r.ok)
            return {};
        const rows = (await r.json());
        const map = {};
        for (const row of rows)
            map[row.key] = row.value;
        return map;
    }
    /**
     * Remarketing automático: leads no estado "enviado" (campanha concluída,
     * sem resposta do lead) que estão há mais de `remarket_days` dias recebem
     * novamente a `remarket_message` e passam a "remarketing". Reenvia apenas
     * uma vez: o campo remarket_at guarda quando o reenvio foi feito.
     */
    async processRemarketing() {
        const log = getLogger();
        const settings = await this.getAgentSettings();
        const active = settings.remarket_active === true;
        const days = Number(settings.remarket_days) || 1;
        const message = settings.remarket_message || 'E aí, tudo certo? Te chamei ontem sobre uma oportunidade. Quer que eu detalhe?';
        const cutoff = new Date(Date.now() - days * 24 * 3600 * 1000).toISOString();
        // Leads "enviado" sem resposta, cujo last_message_sent passou do cutoff e
        // que ainda não receberam o reenvio de remarketing (remarket_at nulo).
        const r = await fetch(`${this.url}/rest/v1/leads?select=id,phone,name,city,website,category,niche,rating,reviews,address,state&status=eq.enviado&last_message_sent=lte.${encodeURIComponent(cutoff)}&remarket_at=is.null`, { headers: this.headers() });
        if (!r.ok)
            return;
        const leads = (await r.json());
        if (leads.length === 0)
            return;
        if (!active) {
            log.info({ candidates: leads.length }, 'send-worker: remarketing disabled, skipping');
            return;
        }
        for (const lead of leads) {
            if (!lead.phone)
                continue;
            const body = applyPlaceholders(message, lead);
            const agentName = await loadAgentName();
            const finalText = formatAgentSignature(body, agentName);
            const ok = (await sendText({ to: lead.phone, text: finalText })).ok;
            if (!ok) {
                log.warn({ leadId: lead.id, phone: lead.phone }, 'send-worker: remarketing send failed');
                continue;
            }
            await fetch(`${this.url}/rest/v1/leads?id=eq.${lead.id}`, {
                method: 'PATCH',
                headers: this.headers(true),
                body: JSON.stringify({
                    status: 'remarketing',
                    remarket_at: new Date().toISOString(),
                    last_message_sent: new Date().toISOString(),
                }),
            });
            await fetch(`${this.url}/rest/v1/lead_status_history`, {
                method: 'POST',
                headers: this.headers(true),
                body: JSON.stringify({ lead_id: lead.id, status: 'remarketing', notes: null }),
            });
            log.info({ leadId: lead.id }, 'send-worker: remarketing sent');
        }
    }
    async tick() {
        if (this.busy)
            return;
        this.busy = true;
        try {
            const runs = await this.getPendingRuns();
            const now = Date.now();
            for (const run of runs) {
                const due = !run.next_send_at || new Date(run.next_send_at).getTime() <= now;
                if (!due)
                    continue;
                try {
                    await this.processRun(run);
                }
                catch (e) {
                    const log = getLogger();
                    log.error({ runId: run.id, err: e instanceof Error ? e.message : e }, 'send-worker: run crashed');
                    await this.patchSendRun(run.id, { status: 'failed' });
                }
            }
            await this.processRemarketing();
        }
        finally {
            this.busy = false;
        }
    }
    start() {
        if (this.started)
            return;
        this.started = true;
        const log = getLogger();
        log.info({ tickMs: TICK_MS }, 'send-worker: started');
        this.timer = setInterval(() => void this.tick(), TICK_MS);
    }
    stop() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        this.started = false;
    }
}
function guessMimetype(url, kind) {
    const m = url.toLowerCase().match(/\.(\w+)(\?|$)/);
    const ext = m ? m[1] : '';
    if (kind === 'audio')
        return 'audio/mpeg';
    if (kind === 'video')
        return 'video/mp4';
    if (kind === 'image')
        return `${ext === 'png' ? 'image/png' : 'image/jpeg'}`;
    if (kind === 'document') {
        const map = {
            pdf: 'application/pdf',
            doc: 'application/msword',
            docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            xls: 'application/vnd.ms-excel',
            xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ppt: 'application/vnd.ms-powerpoint',
            pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        };
        return map[ext] ?? 'application/octet-stream';
    }
    return undefined;
}
function basename(url) {
    try {
        return url.split('/').pop()?.split('?')[0] ?? 'arquivo';
    }
    catch {
        return 'arquivo';
    }
}
//# sourceMappingURL=send.worker.js.map